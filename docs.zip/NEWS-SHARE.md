# Planning Link Preview untuk News Share

## Tujuan

Saat link berita dibagikan ke WhatsApp, Facebook, X, Telegram, LinkedIn, atau platform lain, preview harus menampilkan:

1. **Gambar berita**
2. **Judul berita**
3. **Caption atau ringkasan berita**
4. **Nama website GenBI Provinsi Jambi**
5. **URL canonical berbasis slug**

Preview ini dibuat dengan meta tag **Open Graph** dan **Twitter Card**. Open Graph dipakai agar halaman web bisa tampil sebagai objek kaya saat dibagikan, termasuk title, description, image, dan URL. ([ogp.me][1]) Facebook juga menyebut crawler akan menebak title, description, dan image jika Open Graph tidak tersedia, jadi sebaiknya kita kontrol sendiri lewat meta tag. ([Facebook Developers][2])

---

# 1. Output yang Diinginkan

Contoh saat link dibagikan:

```txt
Talkshow Siginjai Fest 2026 Dorong Generasi Muda Berkarya
Talkshow Siginjai Fest 2026 digelar untuk mendorong generasi muda muslim agar kreatif, produktif, dan memahami ekonomi syariah.
genbijambi.com
[Preview image berita]
```

---

# 2. Data yang Dipakai dari Database

Sumber utama: `tbl_news`

| Kebutuhan Preview | Kolom Database                  | Fallback                                |
| ----------------- | ------------------------------- | --------------------------------------- |
| URL berita        | `slug`                          | `news_id` untuk redirect legacy         |
| Title preview     | `news_title`                    | `meta_title` jika diisi                 |
| Caption preview   | `news_content_short`            | `meta_description` atau potongan konten |
| Image preview     | `photo`                         | `banner`, lalu default OG image         |
| Published time    | `published_at` atau `news_date` | `created_at`                            |
| Modified time     | `updated_at`                    | `published_at`                          |
| Category          | relasi `tbl_category`           | `Berita GenBI`                          |
| Author            | `contributor_pewarta`           | `GenBI Provinsi Jambi`                  |
| Editor            | `contributor_editor`            | kosong                                  |

---

# 3. Meta Tag Wajib di News Detail

Setiap halaman detail berita harus punya meta tag di dalam `<head>`.

## 3.1 Basic SEO

```html
<title><?= e($metaTitle) ?></title>
<meta name="description" content="<?= e($metaDescription) ?>">
<link rel="canonical" href="<?= e($canonicalUrl) ?>">
<meta name="robots" content="index, follow">
```

## 3.2 Open Graph

```html
<meta property="og:type" content="article">
<meta property="og:site_name" content="GenBI Provinsi Jambi">
<meta property="og:title" content="<?= e($ogTitle) ?>">
<meta property="og:description" content="<?= e($ogDescription) ?>">
<meta property="og:url" content="<?= e($canonicalUrl) ?>">
<meta property="og:image" content="<?= e($ogImage) ?>">
<meta property="og:image:secure_url" content="<?= e($ogImage) ?>">
<meta property="og:image:type" content="<?= e($ogImageType) ?>">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="<?= e($ogImageAlt) ?>">
<meta property="article:published_time" content="<?= e($publishedIso) ?>">
<meta property="article:modified_time" content="<?= e($modifiedIso) ?>">
<meta property="article:section" content="<?= e($categoryName) ?>">
```

## 3.3 Twitter Card atau X Card

```html
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?= e($ogTitle) ?>">
<meta name="twitter:description" content="<?= e($ogDescription) ?>">
<meta name="twitter:image" content="<?= e($ogImage) ?>">
<meta name="twitter:image:alt" content="<?= e($ogImageAlt) ?>">
```

Gunakan `summary_large_image` agar preview gambar tampil besar di platform yang mendukung kartu besar.

---

# 4. Image Preview Rule

## Ukuran ideal

Gunakan gambar **1200 x 630 px** untuk preview sosial. Ini rasio umum yang aman untuk Facebook, WhatsApp, LinkedIn, Telegram, dan X.

## Format

Prioritas:

1. JPG
2. PNG
3. WebP

Untuk kompatibilitas luas, gunakan JPG untuk OG image utama.

## File size

Target aman:

```txt
100 KB sampai 500 KB
```

Jangan terlalu besar. WhatsApp dan beberapa platform bisa gagal menampilkan preview jika gambar terlalu berat. Meta WhatsApp docs menjelaskan preview memakai `og:description` untuk deskripsi, dan link preview mengambil metadata dari halaman. ([Facebook Developers][3])

## URL gambar harus absolut

Benar:

```html
<meta property="og:image" content="https://genbijambi.com/uploads/news/news-2026-siginjai.jpg">
```

Salah:

```html
<meta property="og:image" content="/uploads/news/news-2026-siginjai.jpg">
```

---

# 5. Fallback Image

Jika berita tidak punya `photo` dan `banner`, pakai default image.

```txt
/public/uploads/default-og-genbi.jpg
```

## Default image harus berisi:

* Logo GenBI
* Tulisan “GenBI Provinsi Jambi”
* Background biru bersih
* Rasio 1200 x 630 px

## Logic fallback

```php
if (!empty($news['photo'])) {
    $ogImage = asset_url('uploads/news/' . $news['photo']);
} elseif (!empty($news['banner'])) {
    $ogImage = asset_url('uploads/news/' . $news['banner']);
} else {
    $ogImage = asset_url('uploads/default-og-genbi.jpg');
}
```

---

# 6. Backend Service yang Dibutuhkan

Buat service khusus:

```txt
app/Services/SeoService.php
```

## Method

```php
SeoService::forNews(array $news, ?array $category = null): array
SeoService::absoluteUrl(string $path): string
SeoService::imageUrl(?string $path, string $fallback): string
SeoService::cleanDescription(?string $text, int $limit = 160): string
SeoService::isoDate(?string $date): string
```

## Output SeoService

```php
return [
    'title' => $title,
    'description' => $description,
    'canonical' => $canonicalUrl,
    'og_title' => $title,
    'og_description' => $description,
    'og_image' => $imageUrl,
    'og_image_type' => $imageType,
    'og_image_alt' => $imageAlt,
    'published_iso' => $publishedIso,
    'modified_iso' => $modifiedIso,
    'category_name' => $categoryName,
];
```

---

# 7. Controller Flow News Detail

Route:

```txt
GET /news/{slug}
```

Flow:

```txt
1. Ambil news berdasarkan slug.
2. Jika tidak ditemukan, cek legacy ID route.
3. Jika status bukan published, tampilkan 404.
4. Ambil kategori berita.
5. Ambil artikel terkait.
6. Ambil komentar approved.
7. Generate SEO data lewat SeoService.
8. Render view news detail.
```

Pseudo:

```php
public function show(string $slug): void
{
    $news = $this->newsModel->findPublishedBySlug($slug);

    if (!$news) {
        $this->abort(404);
    }

    $category = $this->categoryModel->findById($news['category_id']);
    $related = $this->newsModel->related($news['news_id'], $news['category_id'], 4);
    $comments = $this->commentModel->approvedForNews($news['news_id']);

    $seo = $this->seoService->forNews($news, $category);

    $this->view('public/news-detail', [
        'news' => $news,
        'category' => $category,
        'related' => $related,
        'comments' => $comments,
        'seo' => $seo,
    ]);
}
```

---

# 8. View Integration

Di layout public:

```php
<head>
  <?php if (!empty($seo)): ?>
    <?php include view_path('partials/meta-news.php'); ?>
  <?php else: ?>
    <?php include view_path('partials/meta-default.php'); ?>
  <?php endif; ?>
</head>
```

Buat partial:

```txt
app/Views/partials/meta-news.php
```

Isi:

```php
<title><?= e($seo['title']) ?></title>
<meta name="description" content="<?= e($seo['description']) ?>">
<link rel="canonical" href="<?= e($seo['canonical']) ?>">
<meta name="robots" content="index, follow">

<meta property="og:type" content="article">
<meta property="og:site_name" content="GenBI Provinsi Jambi">
<meta property="og:title" content="<?= e($seo['og_title']) ?>">
<meta property="og:description" content="<?= e($seo['og_description']) ?>">
<meta property="og:url" content="<?= e($seo['canonical']) ?>">
<meta property="og:image" content="<?= e($seo['og_image']) ?>">
<meta property="og:image:secure_url" content="<?= e($seo['og_image']) ?>">
<meta property="og:image:type" content="<?= e($seo['og_image_type']) ?>">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="<?= e($seo['og_image_alt']) ?>">

<meta property="article:published_time" content="<?= e($seo['published_iso']) ?>">
<meta property="article:modified_time" content="<?= e($seo['modified_iso']) ?>">
<meta property="article:section" content="<?= e($seo['category_name']) ?>">

<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?= e($seo['og_title']) ?>">
<meta name="twitter:description" content="<?= e($seo['og_description']) ?>">
<meta name="twitter:image" content="<?= e($seo['og_image']) ?>">
<meta name="twitter:image:alt" content="<?= e($seo['og_image_alt']) ?>">
```

---

# 9. Share Button di News Detail

## Tombol yang disediakan

| Platform  | URL                                                       |
| --------- | --------------------------------------------------------- |
| WhatsApp  | `https://wa.me/?text={title}%20{url}`                     |
| Facebook  | `https://www.facebook.com/sharer/sharer.php?u={url}`      |
| X         | `https://twitter.com/intent/tweet?url={url}&text={title}` |
| Copy Link | JavaScript Clipboard API                                  |

## Contoh view

```php
<section class="news-share">
  <h2>Bagikan artikel ini</h2>

  <a href="https://wa.me/?text=<?= urlencode($news['news_title'] . ' ' . $seo['canonical']) ?>" target="_blank" rel="noopener">
    WhatsApp
  </a>

  <a href="https://www.facebook.com/sharer/sharer.php?u=<?= urlencode($seo['canonical']) ?>" target="_blank" rel="noopener">
    Facebook
  </a>

  <a href="https://twitter.com/intent/tweet?url=<?= urlencode($seo['canonical']) ?>&text=<?= urlencode($news['news_title']) ?>" target="_blank" rel="noopener">
    X
  </a>

  <button type="button" data-copy-link="<?= e($seo['canonical']) ?>">
    Copy Link
  </button>
</section>
```

Catatan: tombol share hanya membuka compose share. Preview tetap diambil dari meta tag halaman detail.

---

# 10. Cache dan Refresh Preview

## Masalah umum

Setelah meta tag diperbaiki, Facebook atau WhatsApp kadang masih menampilkan preview lama karena cache crawler.

## Solusi

1. Pastikan meta tag sudah benar.
2. Test URL dengan Facebook Sharing Debugger.
3. Klik scrape again.
4. Test di WhatsApp dengan URL yang benar-benar canonical.
5. Pastikan gambar tidak diblok `robots.txt`.
6. Pastikan gambar bisa diakses tanpa login.

Facebook menyediakan Sharing Debugger untuk melihat preview dan debug masalah Open Graph tag. ([Facebook Developers][4]) Meta juga menyarankan debugger untuk refresh konten yang sudah pernah discrape. ([Facebook Developers][5])

---

# 11. Testing Checklist

## Test HTML head

* [ ] `og:title` muncul.
* [ ] `og:description` muncul.
* [ ] `og:image` muncul.
* [ ] `og:url` muncul.
* [ ] `twitter:card` muncul.
* [ ] `canonical` muncul.
* [ ] Semua URL absolut.
* [ ] Tidak ada HTML entity rusak.
* [ ] Caption tidak lebih dari 160 sampai 200 karakter.

## Test gambar

* [ ] Gambar bisa dibuka langsung di browser.
* [ ] Gambar tidak butuh login.
* [ ] Gambar pakai HTTPS.
* [ ] Ukuran minimal 1200 x 630 px untuk hasil optimal.
* [ ] File tidak terlalu berat.
* [ ] `og:image:type` sesuai file.
* [ ] Fallback image tersedia.

## Test platform

* [ ] Facebook Sharing Debugger.
* [ ] WhatsApp personal chat.
* [ ] WhatsApp group.
* [ ] Telegram.
* [ ] X Card Validator atau test post.
* [ ] LinkedIn post inspector.
* [ ] Browser mobile.

## Test route

* [ ] `/news/{slug}` punya preview benar.
* [ ] `/news/id/{id}` redirect ke slug.
* [ ] Link share memakai slug, bukan ID.
* [ ] Draft news tidak bisa dibagikan publik.
* [ ] Archived news tidak tampil publik.
* [ ] Deleted news 404.

---

# 12. Acceptance Criteria

Fitur dianggap selesai jika:

1. Link berita memakai format slug.
2. Saat link berita dibagikan, preview menampilkan gambar berita.
3. Preview menampilkan judul berita.
4. Preview menampilkan News Short Content sebagai caption.
5. Jika gambar berita kosong, default OG image tampil.
6. Artikel terkait tetap memakai gambar di kiri.
7. Share button memakai URL canonical.
8. Facebook Sharing Debugger membaca semua OG tag tanpa error.
9. WhatsApp menampilkan preview gambar, title, dan caption.
10. Semua halaman news detail punya canonical URL.
11. Admin bisa mengatur:

    * News title
    * News short content
    * Featured photo
    * Banner
    * Meta title
    * Meta description
12. Backend tetap men-sanitize dan re-validate semua input.

---

# 13. Urutan Implementasi

## Phase 1: Database dan Model

1. Pastikan `tbl_news.slug` sudah ada.
2. Pastikan `tbl_news.news_content_short` tersedia.
3. Pastikan `tbl_news.photo` dan `tbl_news.banner` dipakai konsisten.
4. Tambahkan method `findPublishedBySlug()`.
5. Tambahkan method `related()`.

## Phase 2: SEO Service

1. Buat `SeoService`.
2. Buat helper `absolute_url()`.
3. Buat helper `asset_url()`.
4. Buat helper `clean_description()`.
5. Buat fallback default OG image.

## Phase 3: News Detail View

1. Tambahkan partial `meta-news.php`.
2. Inject `$seo` dari controller.
3. Update layout `<head>`.
4. Pastikan canonical pakai slug.
5. Pastikan share button pakai canonical.

## Phase 4: Admin News

1. Pastikan News Title field terpisah.
2. Pastikan News Short Content field terpisah.
3. Pastikan Featured Photo dipakai untuk OG image.
4. Pastikan Banner menjadi fallback image.
5. Tambahkan preview kecil untuk social card di admin.

## Phase 5: Testing

1. Test view source.
2. Test Facebook Sharing Debugger.
3. Test WhatsApp.
4. Test Telegram.
5. Test fallback image.
6. Test cache refresh.

---

# 14. Bonus: Social Preview di Admin

Tambahkan panel kecil di sidebar Add/Edit News:

```txt
Social Preview
[Image]
News title
News short content
genbijambi.com
```

Data live dari:

* News Title
* News Short Content
* Featured Photo

Manfaat:

* Admin bisa tahu tampilan share sebelum publish.
* Mengurangi risiko caption kosong.
* Mengurangi risiko salah gambar.

---

# 15. Ringkasan Teknis

Yang perlu dibuat:

```txt
app/Services/SeoService.php
app/Views/partials/meta-news.php
app/Views/partials/meta-default.php
app/Controllers/Public/NewsController.php
app/Models/News.php
public/uploads/default-og-genbi.jpg
```

Yang perlu dipastikan:

```txt
tbl_news.slug
tbl_news.news_title
tbl_news.news_content_short
tbl_news.photo
tbl_news.banner
tbl_news.meta_title
tbl_news.meta_description
tbl_news.contributor_redaksi
tbl_news.contributor_pewarta
tbl_news.contributor_editor
```

Formula preview:

```txt
Preview title:
meta_title jika ada, selain itu news_title

Preview caption:
meta_description jika ada, selain itu news_content_short

Preview image:
photo jika ada, jika tidak banner, jika tidak default-og-genbi.jpg

Preview URL:
https://genbijambi.com/news/{slug}
```

[1]: https://ogp.me/?utm_source=chatgpt.com "The Open Graph protocol"
[2]: https://developers.facebook.com/docs/sharing/webmasters/?utm_source=chatgpt.com "Webmasters - Sharing - Meta for Developers - Facebook"
[3]: https://developers.facebook.com/documentation/business-messaging/whatsapp/link-previews/?utm_source=chatgpt.com "Link previews - Meta for Developers - Facebook"
[4]: https://developers.facebook.com/tools/debug/?utm_source=chatgpt.com "Sharing Debugger - Meta for Developers - Facebook"
[5]: https://developers.facebook.com/docs/sharing/best-practices/?utm_source=chatgpt.com "Best Practices - Sharing - Meta for Developers - Facebook"
