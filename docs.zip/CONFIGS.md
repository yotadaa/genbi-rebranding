# Blueprint SEO Crawlability GenBI Jambi

Tujuannya: website mudah dicrawl, halaman penting cepat ditemukan, halaman admin tidak ikut terindeks, dan struktur konten jelas untuk search engine.

Rujukan utama: Google menjelaskan bahwa `robots.txt` dipakai untuk mengatur URL yang boleh dicrawl, tetapi bukan mekanisme untuk menyembunyikan halaman dari indeks. Untuk halaman yang benar-benar tidak boleh muncul di hasil pencarian, gunakan `noindex` atau proteksi login. ([Google for Developers][1]) Sitemap membantu search engine menemukan halaman penting, termasuk informasi `lastmod`, gambar, video, dan news. Namun sitemap tidak menjamin semua URL akan diindeks. ([Google for Developers][2])

---

# 1. Target SEO Teknis

## Halaman yang harus terindeks

| Tipe halaman                    |                            Status index | Alasan                                             |
| ------------------------------- | --------------------------------------: | -------------------------------------------------- |
| Homepage                        |                                   Index | Halaman utama brand                                |
| About                           |                                   Index | Profil organisasi                                  |
| Team                            |                                   Index | Direktori organisasi                               |
| Prestasi                        |                                   Index | Pencapaian organisasi                              |
| News list                       |                                   Index | Hub berita                                         |
| News detail                     |                                   Index | Konten artikel utama                               |
| Event list                      |                                   Index | Agenda publik                                      |
| Event detail                    |                                   Index | Detail agenda                                      |
| Contact                         |                                   Index | Alamat dan kontak resmi                            |
| Search page                     |                                 Noindex | Biasanya menghasilkan halaman tipis dan duplikatif |
| Admin login                     |                                 Noindex | Bukan halaman publik                               |
| Admin dashboard dan semua admin |             Noindex dan login protected | Area internal                                      |
| Prestasi submit token           |                                 Noindex | Form private berbasis token                        |
| API endpoint                    |                    Noindex atau blocked | Bukan halaman konten                               |
| Upload asset                    | Boleh dicrawl jika dipakai dalam konten | Gambar artikel perlu bisa ditemukan                |

---

# 2. File SEO yang Perlu Dibuat

```txt
/public/robots.txt
/public/sitemap.xml
/public/sitemap-pages.xml
/public/sitemap-news.xml
/public/sitemap-events.xml
/public/sitemap-prestasi.xml
/public/sitemap-images.xml
/public/manifest.webmanifest
/public/browserconfig.xml
/public/favicon.ico
```

Opsional:

```txt
/public/sitemap-video.xml
/public/feed.xml
/public/news-feed.xml
/public/llms.txt
```

---

# 3. robots.txt

## Tujuan

`robots.txt` memberi arahan crawl. Jangan pakai robots.txt untuk menyembunyikan data sensitif. Halaman admin tetap harus diproteksi login dan diberi `noindex`. Google menyebut `robots.txt` tidak dibuat untuk menjaga halaman agar tidak muncul di Google. ([Google for Developers][1])

## Isi yang disarankan

Gunakan domain final website.

```txt
User-agent: *
Allow: /

# Admin dan area internal
Disallow: /admin/
Disallow: /login
Disallow: /logout
Disallow: /profile
Disallow: /settings

# Endpoint sistem
Disallow: /api/
Disallow: /ajax/
Disallow: /storage/
Disallow: /vendor/
Disallow: /database/
Disallow: /app/
Disallow: /bootstrap/
Disallow: /routes/

# Form token private
Disallow: /prestasi/submit/
Disallow: /token/
Disallow: /*?token=

# Query dan hasil pencarian internal
Disallow: /search?
Disallow: /*?q=
Disallow: /*?keyword=
Disallow: /*?page=*
Disallow: /*?sort=
Disallow: /*?filter=

# Jangan block asset publik
Allow: /assets/
Allow: /uploads/
Allow: /public/uploads/

# Sitemap index
Sitemap: https://genbijambi.com/sitemap.xml
```

## Catatan penting

Jangan `Disallow: /uploads/` karena gambar berita, event, prestasi, dan team perlu bisa dicrawl. Google mendukung image sitemap dan gambar pada halaman dapat dibantu dengan sitemap gambar. ([Google for Developers][3])

---

# 4. Meta Robots per Halaman

## Default public page

```html
<meta name="robots" content="index, follow">
```

## Admin dan halaman private

```html
<meta name="robots" content="noindex, nofollow">
```

## Search internal

```html
<meta name="robots" content="noindex, follow">
```

## Token form prestasi

```html
<meta name="robots" content="noindex, nofollow">
```

Google mendukung meta robots untuk kontrol index per halaman dan `X-Robots-Tag` untuk resource non-HTML. ([Google for Developers][4])

---

# 5. X-Robots-Tag Header

Tambahkan untuk endpoint yang bukan halaman publik.

## Admin

```apache
<IfModule mod_headers.c>
  <LocationMatch "^/admin/">
    Header set X-Robots-Tag "noindex, nofollow"
  </LocationMatch>
</IfModule>
```

## API

```apache
<IfModule mod_headers.c>
  <LocationMatch "^/api/">
    Header set X-Robots-Tag "noindex, nofollow"
  </LocationMatch>
</IfModule>
```

## File internal jika pernah terekspos

```apache
<IfModule mod_headers.c>
  <FilesMatch "\.(json|log|sql|env|bak|zip)$">
    Header set X-Robots-Tag "noindex, nofollow, nosnippet"
  </FilesMatch>
</IfModule>
```

---

# 6. Sitemap Strategy

## Kenapa pakai sitemap index

Karena website punya beberapa tipe konten:

1. Static pages
2. News
3. Event
4. Prestasi
5. Images
6. Video opsional

Sitemap index memudahkan pemisahan dan maintenance. Google mendukung sitemap index untuk mengelola banyak sitemap. ([Google for Developers][5])

---

# 7. sitemap.xml

File ini menjadi index dari semua sitemap.

```xml
<?xml version="1.0" encoding="UTF-8"?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <sitemap>
    <loc>https://genbijambi.com/sitemap-pages.xml</loc>
    <lastmod>2026-05-06</lastmod>
  </sitemap>
  <sitemap>
    <loc>https://genbijambi.com/sitemap-news.xml</loc>
    <lastmod>2026-05-06</lastmod>
  </sitemap>
  <sitemap>
    <loc>https://genbijambi.com/sitemap-events.xml</loc>
    <lastmod>2026-05-06</lastmod>
  </sitemap>
  <sitemap>
    <loc>https://genbijambi.com/sitemap-prestasi.xml</loc>
    <lastmod>2026-05-06</lastmod>
  </sitemap>
  <sitemap>
    <loc>https://genbijambi.com/sitemap-images.xml</loc>
    <lastmod>2026-05-06</lastmod>
  </sitemap>
</sitemapindex>
```

---

# 8. sitemap-pages.xml

Berisi halaman statis utama.

```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://genbijambi.com/</loc>
    <lastmod>2026-05-06</lastmod>
    <changefreq>weekly</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>https://genbijambi.com/about</loc>
    <lastmod>2026-05-06</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://genbijambi.com/team</loc>
    <lastmod>2026-05-06</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://genbijambi.com/prestasi</loc>
    <lastmod>2026-05-06</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://genbijambi.com/news</loc>
    <lastmod>2026-05-06</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
  <url>
    <loc>https://genbijambi.com/event</loc>
    <lastmod>2026-05-06</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://genbijambi.com/contact</loc>
    <lastmod>2026-05-06</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>
</urlset>
```

---

# 9. sitemap-news.xml

Berisi semua berita published.

## Aturan

| Field                   | Sumber database                  |
| ----------------------- | -------------------------------- |
| `loc`                   | `/news/{slug}`                   |
| `lastmod`               | `updated_at` atau `published_at` |
| `image:loc`             | `photo` atau `banner`            |
| `image:caption`         | `news_title`                     |
| `news:title`            | `news_title`                     |
| `news:publication_date` | `published_at` atau `news_date`  |

Google punya format khusus untuk News sitemap, terutama untuk artikel berita dan publikasi. ([Google for Developers][6])

## Contoh

```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset
  xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
  xmlns:news="http://www.google.com/schemas/sitemap-news/0.9"
  xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">

  <url>
    <loc>https://genbijambi.com/news/talkshow-siginjai-fest-2026-dorong-generasi-muda-berkarya</loc>
    <lastmod>2026-04-30T10:00:00+07:00</lastmod>
    <news:news>
      <news:publication>
        <news:name>GenBI Provinsi Jambi</news:name>
        <news:language>id</news:language>
      </news:publication>
      <news:publication_date>2026-04-30T10:00:00+07:00</news:publication_date>
      <news:title>Talkshow Siginjai Fest 2026 Dorong Generasi Muda Berkarya</news:title>
    </news:news>
    <image:image>
      <image:loc>https://genbijambi.com/public/uploads/news-100.jpg</image:loc>
      <image:caption>Talkshow Siginjai Fest 2026</image:caption>
    </image:image>
  </url>

</urlset>
```

Catatan: jika situs belum masuk Google News, sitemap news tetap boleh direncanakan, tetapi sitemap umum tetap wajib.

---

# 10. sitemap-events.xml

Berisi event published.

```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset
  xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
  xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">

  <url>
    <loc>https://genbijambi.com/event/genbi-peka-2026</loc>
    <lastmod>2026-05-06</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
    <image:image>
      <image:loc>https://genbijambi.com/public/uploads/event/genbi-peka.jpg</image:loc>
      <image:caption>GenBI PEKA 2026</image:caption>
    </image:image>
  </url>

</urlset>
```

---

# 11. sitemap-prestasi.xml

Berisi halaman detail prestasi.

```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset
  xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
  xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">

  <url>
    <loc>https://genbijambi.com/prestasi/juara-1-karya-tulis-ilmiah-naac-week-2025</loc>
    <lastmod>2026-05-06</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
    <image:image>
      <image:loc>https://genbijambi.com/uploads/prestasi/naac-week-2025.webp</image:loc>
      <image:caption>Juara 1 Karya Tulis Ilmiah NAAC Week 2025</image:caption>
    </image:image>
  </url>

</urlset>
```

---

# 12. sitemap-images.xml

Berisi gambar penting yang ingin ikut dipahami oleh search engine.

## Sumber gambar

| Modul    | Gambar                                |
| -------- | ------------------------------------- |
| News     | `photo`, `banner`, image di Editor.js |
| Event    | `photo`, `banner`                     |
| Prestasi | `photo`, `certificate_photo`          |
| Team     | foto anggota                          |
| Gallery  | foto galeri                           |
| Slider   | gambar hero                           |

Google mendukung image sitemap untuk memberi informasi gambar yang ada di halaman. ([Google for Developers][3])

```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset
  xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
  xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">

  <url>
    <loc>https://genbijambi.com/news/talkshow-siginjai-fest-2026-dorong-generasi-muda-berkarya</loc>
    <image:image>
      <image:loc>https://genbijambi.com/public/uploads/news-100.jpg</image:loc>
      <image:title>Talkshow Siginjai Fest 2026</image:title>
      <image:caption>Dokumentasi kegiatan Siginjai Fest 2026 GenBI Provinsi Jambi</image:caption>
    </image:image>
  </url>

</urlset>
```

---

# 13. sitemap-video.xml

Karena landing page punya video YouTube embed, siapkan sitemap video jika video menjadi konten penting.

Google menyebut video sitemap membantu Google menemukan dan memahami konten video pada halaman. ([Google for Developers][7])

```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset
  xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
  xmlns:video="http://www.google.com/schemas/sitemap-video/1.1">

  <url>
    <loc>https://genbijambi.com/</loc>
    <video:video>
      <video:thumbnail_loc>https://img.youtube.com/vi/ashD1p7d29s/hqdefault.jpg</video:thumbnail_loc>
      <video:title>Profil GenBI Provinsi Jambi</video:title>
      <video:description>Video profil dan kegiatan GenBI Provinsi Jambi.</video:description>
      <video:player_loc>https://www.youtube.com/embed/ashD1p7d29s</video:player_loc>
      <video:publication_date>2026-05-06T08:00:00+07:00</video:publication_date>
      <video:family_friendly>yes</video:family_friendly>
    </video:video>
  </url>

</urlset>
```

Jika hanya satu video di homepage, sitemap video opsional. Tapi tetap bagus untuk future proof.

---

# 14. Canonical URL

Setiap halaman public harus punya canonical URL. Google menjelaskan canonical dipakai untuk memilih URL representatif dari konten yang sama atau mirip. ([Google for Developers][8])

## Home

```html
<link rel="canonical" href="https://genbijambi.com/">
```

## News detail

```html
<link rel="canonical" href="https://genbijambi.com/news/talkshow-siginjai-fest-2026-dorong-generasi-muda-berkarya">
```

## Legacy ID page

Untuk route lama:

```txt
/news/id/100
```

Jangan canonical ke dirinya sendiri. Redirect 301 ke slug:

```txt
/news/talkshow-siginjai-fest-2026-dorong-generasi-muda-berkarya
```

---

# 15. Meta Title dan Meta Description

## Template title

| Halaman     | Format title                                |                          |
| ----------- | ------------------------------------------- | ------------------------ |
| Home        | `GenBI Provinsi Jambi                       | Generasi Baru Indonesia` |
| About       | `Tentang GenBI Provinsi Jambi`              |                          |
| Team        | `Pengurus dan Anggota GenBI Provinsi Jambi` |                          |
| Prestasi    | `Prestasi GenBI Provinsi Jambi`             |                          |
| News list   | `Berita GenBI Provinsi Jambi`               |                          |
| News detail | `{news_title}                               | GenBI Provinsi Jambi`    |
| Event       | `Agenda GenBI Provinsi Jambi`               |                          |
| Contact     | `Kontak GenBI Provinsi Jambi`               |                          |

## Template description

News detail:

```html
<meta name="description" content="{news_short_content}">
```

Prestasi detail:

```html
<meta name="description" content="{description}">
```

Homepage:

```html
<meta name="description" content="Website resmi GenBI Provinsi Jambi yang menampilkan profil organisasi, kegiatan, berita, prestasi, agenda, dan informasi komunitas penerima beasiswa Bank Indonesia.">
```

---

# 16. Open Graph dan Twitter Card

Semua halaman penting harus punya preview saat dibagikan.

```html
<meta property="og:type" content="website">
<meta property="og:site_name" content="GenBI Provinsi Jambi">
<meta property="og:title" content="GenBI Provinsi Jambi">
<meta property="og:description" content="Profil, kegiatan, berita, prestasi, dan agenda GenBI Provinsi Jambi.">
<meta property="og:url" content="https://genbijambi.com/">
<meta property="og:image" content="https://genbijambi.com/public/uploads/slider-1.png">

<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="GenBI Provinsi Jambi">
<meta name="twitter:description" content="Profil, kegiatan, berita, prestasi, dan agenda GenBI Provinsi Jambi.">
<meta name="twitter:image" content="https://genbijambi.com/public/uploads/slider-1.png">
```

Untuk news detail:

```html
<meta property="og:type" content="article">
<meta property="article:published_time" content="{published_at_iso}">
<meta property="article:modified_time" content="{updated_at_iso}">
<meta property="article:section" content="{category_name}">
```

---

# 17. Structured Data JSON-LD

Structured data membantu Google memahami konteks halaman. Untuk GenBI, gunakan minimal `Organization`, `WebSite`, `BreadcrumbList`, `Article`, `Event`, dan `ImageObject`. Google menyebut Organization structured data membantu Google memahami detail organisasi dan logo. ([Google for Developers][9]) Article structured data membantu Google memahami artikel, gambar, dan tanggal artikel. ([Google for Developers][10]) Breadcrumb structured data membantu Google memahami posisi halaman dalam struktur situs. ([Google for Developers][11])

---

## 17.1 Organization schema

Pasang di homepage dan layout public.

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "GenBI Provinsi Jambi",
  "url": "https://genbijambi.com/",
  "logo": "https://genbijambi.com/public/uploads/logo.png",
  "email": "genbijambibi@gmail.com",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "Jl. A Yani No.14, Telanaipura",
    "addressLocality": "Kota Jambi",
    "addressRegion": "Jambi",
    "postalCode": "36361",
    "addressCountry": "ID"
  },
  "sameAs": [
    "https://www.instagram.com/genbijambi",
    "https://www.youtube.com/@genbijambi"
  ]
}
</script>
```

---

## 17.2 WebSite schema

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebSite",
  "name": "GenBI Provinsi Jambi",
  "url": "https://genbijambi.com/",
  "potentialAction": {
    "@type": "SearchAction",
    "target": "https://genbijambi.com/search?q={search_term_string}",
    "query-input": "required name=search_term_string"
  }
}
</script>
```

Jika halaman `/search` diberi `noindex`, tetap boleh ada search action selama hasil pencarian memang bisa dipakai pengguna. Namun jangan masukkan halaman search result ke sitemap.

---

## 17.3 BreadcrumbList schema

Untuk news detail:

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "Beranda",
      "item": "https://genbijambi.com/"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "Berita",
      "item": "https://genbijambi.com/news"
    },
    {
      "@type": "ListItem",
      "position": 3,
      "name": "Talkshow Siginjai Fest 2026 Dorong Generasi Muda Berkarya",
      "item": "https://genbijambi.com/news/talkshow-siginjai-fest-2026-dorong-generasi-muda-berkarya"
    }
  ]
}
</script>
```

---

## 17.4 Article schema untuk news detail

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "NewsArticle",
  "headline": "Talkshow Siginjai Fest 2026 Dorong Generasi Muda Berkarya",
  "description": "Talkshow Siginjai Fest 2026 digelar untuk mendorong generasi muda agar lebih kreatif, produktif, dan memahami ekonomi syariah.",
  "image": [
    "https://genbijambi.com/public/uploads/news-100.jpg"
  ],
  "datePublished": "2026-04-30T10:00:00+07:00",
  "dateModified": "2026-04-30T10:00:00+07:00",
  "author": [
    {
      "@type": "Person",
      "name": "Nama Pewarta"
    }
  ],
  "editor": {
    "@type": "Person",
    "name": "Nama Editor"
  },
  "publisher": {
    "@type": "Organization",
    "name": "GenBI Provinsi Jambi",
    "logo": {
      "@type": "ImageObject",
      "url": "https://genbijambi.com/public/uploads/logo.png"
    }
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://genbijambi.com/news/talkshow-siginjai-fest-2026-dorong-generasi-muda-berkarya"
  }
}
</script>
```

---

## 17.5 Event schema

Untuk detail event.

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Event",
  "name": "GenBI PEKA 2026",
  "startDate": "2026-05-20T09:00:00+07:00",
  "endDate": "2026-05-20T12:00:00+07:00",
  "eventAttendanceMode": "https://schema.org/OfflineEventAttendanceMode",
  "eventStatus": "https://schema.org/EventScheduled",
  "location": {
    "@type": "Place",
    "name": "Kota Jambi",
    "address": {
      "@type": "PostalAddress",
      "addressLocality": "Jambi",
      "addressCountry": "ID"
    }
  },
  "image": [
    "https://genbijambi.com/uploads/events/genbi-peka-2026.webp"
  ],
  "description": "Agenda sosial dan edukasi GenBI Provinsi Jambi.",
  "organizer": {
    "@type": "Organization",
    "name": "GenBI Provinsi Jambi",
    "url": "https://genbijambi.com/"
  }
}
</script>
```

---

# 18. Favicon dan App Icons

Google memberi panduan agar favicon bisa tampil di hasil pencarian dengan menambahkan `<link rel="icon">` pada halaman utama. ([Google for Developers][12])

```html
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" href="/icon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
<link rel="manifest" href="/manifest.webmanifest">
```

## manifest.webmanifest

```json
{
  "name": "GenBI Provinsi Jambi",
  "short_name": "GenBI Jambi",
  "description": "Website resmi GenBI Provinsi Jambi.",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#f8fafc",
  "theme_color": "#1d4ed8",
  "icons": [
    {
      "src": "/icon-192.png",
      "sizes": "192x192",
      "type": "image/png"
    },
    {
      "src": "/icon-512.png",
      "sizes": "512x512",
      "type": "image/png"
    }
  ]
}
```

---

# 19. RSS atau Atom Feed

RSS berguna untuk berita terbaru dan mudah dibaca aggregator.

## feed.xml

```xml
<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0">
  <channel>
    <title>Berita GenBI Provinsi Jambi</title>
    <link>https://genbijambi.com/news</link>
    <description>Berita terbaru GenBI Provinsi Jambi</description>
    <language>id-ID</language>
    <lastBuildDate>Wed, 06 May 2026 10:00:00 +0700</lastBuildDate>

    <item>
      <title>Talkshow Siginjai Fest 2026 Dorong Generasi Muda Berkarya</title>
      <link>https://genbijambi.com/news/talkshow-siginjai-fest-2026-dorong-generasi-muda-berkarya</link>
      <guid>https://genbijambi.com/news/talkshow-siginjai-fest-2026-dorong-generasi-muda-berkarya</guid>
      <pubDate>Thu, 30 Apr 2026 10:00:00 +0700</pubDate>
      <description>Talkshow Siginjai Fest 2026 digelar untuk mendorong generasi muda.</description>
    </item>
  </channel>
</rss>
```

Tambahkan di `<head>`:

```html
<link rel="alternate" type="application/rss+xml" title="Berita GenBI Provinsi Jambi" href="https://genbijambi.com/feed.xml">
```

---

# 20. Dynamic Generator dari Backend

Karena backend pakai pure PHP MVC, sitemap sebaiknya digenerate otomatis dari database.

## Route generator

| Route                   | Controller                 | Fungsi             |
| ----------------------- | -------------------------- | ------------------ |
| `/sitemap.xml`          | SitemapController@index    | Sitemap index      |
| `/sitemap-pages.xml`    | SitemapController@pages    | Static pages       |
| `/sitemap-news.xml`     | SitemapController@news     | News published     |
| `/sitemap-events.xml`   | SitemapController@events   | Event published    |
| `/sitemap-prestasi.xml` | SitemapController@prestasi | Prestasi published |
| `/sitemap-images.xml`   | SitemapController@images   | Gambar penting     |
| `/feed.xml`             | FeedController@news        | RSS berita         |

## Controller response header

```php
header('Content-Type: application/xml; charset=UTF-8');
```

## Query news sitemap

```sql
SELECT news_id, slug, news_title, news_content_short, photo, banner, news_date, published_at, updated_at
FROM tbl_news
WHERE status = 'published'
  AND published = 1
  AND deleted_at IS NULL
ORDER BY COALESCE(published_at, news_date) DESC
LIMIT 1000;
```

---

# 21. URL dan Slug Policy

## Aturan URL

| Konten          | Format URL                         |
| --------------- | ---------------------------------- |
| News list       | `/news`                            |
| News detail     | `/news/{slug}`                     |
| Legacy news ID  | `/news/id/{id}` lalu redirect 301  |
| Prestasi list   | `/prestasi`                        |
| Prestasi detail | `/prestasi/{slug}`                 |
| Event list      | `/event`                           |
| Event detail    | `/event/{slug}` atau `/event/{id}` |
| Team            | `/team`                            |

## Slug

* Lowercase.
* Gunakan tanda hubung.
* Hapus simbol aneh.
* Unik per tabel.
* Jangan berubah otomatis saat edit title.
* Jika title berubah besar, admin bisa klik “Regenerate slug”.

## Redirect lama ke baru

```txt
/news-detail.php?id=100
/news/id/100
```

Harus redirect 301 ke:

```txt
/news/talkshow-siginjai-fest-2026-dorong-generasi-muda-berkarya
```

---

# 22. Internal Linking

## Dari homepage

Link ke:

* About
* Program Utama
* BPI
* Agenda Utama
* Latest News
* Contact

## Dari news detail

Link ke:

* Category page
* Artikel terkait
* News list
* Event terkait jika ada
* Profil organisasi

## Dari prestasi detail

Link ke:

* Prestasi list
* Team page
* News terkait jika ada

Internal link yang jelas membantu crawler menemukan halaman penting. Google menyebut sitemap membantu, tetapi internal linking tetap penting agar halaman dapat ditemukan dari navigasi dan link di situs. ([Google for Developers][2])

---

# 23. Pagination SEO

## News pagination

Gunakan URL:

```txt
/news/page/2
```

Lebih bersih daripada:

```txt
/news?page=2
```

Jika tetap memakai query string, jangan block semua `?page=` kalau halaman pagination ingin dicrawl.

Rekomendasi untuk GenBI:

* Crawl halaman `/news` utama.
* Index halaman detail news.
* Pagination boleh `index, follow` jika kontennya unik.
* Jangan masukkan pagination ke sitemap kecuali diperlukan.

## Filter category

Gunakan route bersih:

```txt
/news/category/bank-indonesia
```

Lebih baik daripada:

```txt
/news?category=bank-indonesia
```

---

# 24. Halaman yang Harus `noindex`

| Halaman                    | Cara                                      |
| -------------------------- | ----------------------------------------- |
| `/admin/*`                 | Login + `X-Robots-Tag: noindex, nofollow` |
| `/login`                   | `noindex, nofollow`                       |
| `/search?q=`               | `noindex, follow`                         |
| `/prestasi/submit/{token}` | `noindex, nofollow`                       |
| `/api/*`                   | `X-Robots-Tag: noindex, nofollow`         |
| Preview draft              | `noindex, nofollow`                       |
| Draft news                 | Jangan punya route public                 |
| Comment POST endpoint      | Jangan bisa diakses GET                   |
| Upload private file        | Jangan taruh di public                    |

---

# 25. robots.txt untuk Staging

Jika ada staging domain, block total.

```txt
User-agent: *
Disallow: /
```

Dan tetap tambah header:

```apache
Header set X-Robots-Tag "noindex, nofollow"
```

Jangan pernah gunakan konfigurasi staging di production.

---

# 26. Checklist Implementasi SEO

## Crawl control

* [ ] `robots.txt` tersedia di root.
* [ ] `robots.txt` mencantumkan sitemap.
* [ ] Admin diblok crawl.
* [ ] API diblok crawl.
* [ ] Token form diblok crawl.
* [ ] Upload gambar publik tidak diblok.

## Sitemap

* [ ] `sitemap.xml` sebagai sitemap index.
* [ ] `sitemap-pages.xml` untuk halaman statis.
* [ ] `sitemap-news.xml` untuk berita.
* [ ] `sitemap-events.xml` untuk agenda.
* [ ] `sitemap-prestasi.xml` untuk prestasi.
* [ ] `sitemap-images.xml` untuk gambar penting.
* [ ] Sitemap hanya memuat URL canonical.
* [ ] Sitemap tidak memuat admin, search, token, API, draft.
* [ ] `lastmod` memakai `updated_at` valid.

## Meta

* [ ] Semua public page punya title unik.
* [ ] Semua public page punya meta description.
* [ ] Semua public page punya canonical.
* [ ] News detail punya Open Graph.
* [ ] Prestasi detail punya Open Graph.
* [ ] Event detail punya Open Graph.
* [ ] Admin punya noindex.
* [ ] Search punya noindex.

## Structured data

* [ ] Homepage punya Organization schema.
* [ ] Homepage punya WebSite schema.
* [ ] Semua detail page punya BreadcrumbList.
* [ ] News detail punya NewsArticle schema.
* [ ] Event detail punya Event schema.
* [ ] Prestasi detail bisa memakai Article atau CreativeWork schema.
* [ ] Logo schema memakai logo resmi.
* [ ] Structured data valid di Rich Results Test.

## URL

* [ ] News memakai slug.
* [ ] ID lama redirect ke slug.
* [ ] URL lowercase.
* [ ] Tidak ada duplicate URL.
* [ ] HTTP redirect ke HTTPS.
* [ ] Non-www dan www dipilih salah satu.
* [ ] Trailing slash konsisten.

## Performance crawl

* [ ] CSS dan JS tidak diblok.
* [ ] Gambar punya `alt`.
* [ ] Gambar punya ukuran.
* [ ] Lazy loading untuk gambar non-hero.
* [ ] Hero image diprioritaskan.
* [ ] 404 valid untuk halaman tidak ada.
* [ ] 301 untuk URL lama.
* [ ] 500 tidak bocorkan error detail.

---

# 27. Priority Plan

## P0

1. `robots.txt`
2. `sitemap.xml`
3. Canonical URL
4. Noindex admin, API, token form
5. Redirect ID news ke slug

## P1

1. Sitemap news, event, prestasi
2. Open Graph
3. Structured data Organization, WebSite, NewsArticle
4. RSS feed

## P2

1. Image sitemap
2. Video sitemap
3. Breadcrumb schema lengkap
4. Search Console submission
5. Monitoring indexing

---

# 28. Search Console Setup

Langkah setelah deploy:

1. Verifikasi domain di Google Search Console.
2. Submit `sitemap.xml`.
3. Cek halaman yang excluded.
4. Cek Coverage.
5. Cek Page indexing.
6. Cek Enhancements untuk structured data.
7. Pakai URL Inspection untuk homepage, news detail, prestasi detail.
8. Request indexing untuk halaman penting.

Google menyebut sitemap bisa disubmit lewat Search Console atau dicantumkan di `robots.txt`; submit sitemap adalah hint, bukan jaminan crawl atau index. ([Google for Developers][13])

[1]: https://developers.google.com/search/docs/crawling-indexing/robots/intro?utm_source=chatgpt.com "Robots.txt Introduction and Guide | Google Search Central"
[2]: https://developers.google.com/search/docs/crawling-indexing/sitemaps/overview?utm_source=chatgpt.com "What Is a Sitemap | Google Search Central | Documentation"
[3]: https://developers.google.com/search/docs/crawling-indexing/sitemaps/image-sitemaps?utm_source=chatgpt.com "Image Sitemaps | Google Search Central | Documentation"
[4]: https://developers.google.com/search/docs/crawling-indexing/robots-meta-tag?utm_source=chatgpt.com "Robots Meta Tags Specifications | Google Search Central"
[5]: https://developers.google.com/search/docs/crawling-indexing/sitemaps/large-sitemaps?utm_source=chatgpt.com "Manage Your Sitemaps With Sitemap Index Files"
[6]: https://developers.google.com/search/docs/crawling-indexing/sitemaps/news-sitemap?utm_source=chatgpt.com "Create a News Sitemap | Google Search Central"
[7]: https://developers.google.com/search/docs/crawling-indexing/sitemaps/video-sitemaps?utm_source=chatgpt.com "Video Sitemaps and Examples | Google Search Central"
[8]: https://developers.google.com/search/docs/crawling-indexing/canonicalization?utm_source=chatgpt.com "What is URL Canonicalization | Google Search Central"
[9]: https://developers.google.com/search/docs/appearance/structured-data/organization?utm_source=chatgpt.com "Organization Schema Markup | Google Search Central"
[10]: https://developers.google.com/search/docs/appearance/structured-data/article?utm_source=chatgpt.com "Learn About Article Schema Markup | Google Search Central"
[11]: https://developers.google.com/search/docs/appearance/structured-data/breadcrumb?utm_source=chatgpt.com "How To Add Breadcrumb (BreadcrumbList) Markup"
[12]: https://developers.google.com/search/docs/appearance/favicon-in-search?utm_source=chatgpt.com "Define Website Favicon for Search Results"
[13]: https://developers.google.com/search/docs/crawling-indexing/sitemaps/build-sitemap?utm_source=chatgpt.com "Build and Submit a Sitemap | Google Search Central"
