# Blueprint Integrasi Backend GenBI Jambi

**Pure PHP MVC, no Laravel, no framework berat**

Blueprint ini memakai pola **Model View Controller** dengan PHP murni. Struktur tetap rapi, aman, dan mudah dikembangkan. Database utama tetap memakai `genc1357_genbijambi`.

Catatan penting: jangan hard-code password database di file project. Simpan di `.env` atau file config lokal yang tidak masuk Git.

---

# 1. Tujuan Integrasi

## Target utama

1. Menghubungkan HTML static v3 atau versi revisi ke backend PHP.
2. Memakai database yang sudah ada.
3. Menambahkan migrasi baru tanpa merusak data lama.
4. Membuat struktur MVC rapi.
5. Membuat sistem auth admin yang aman.
6. Membuat semua input divalidasi dan disanitasi di backend.
7. Menambahkan comment section yang terikat ke berita.
8. Menambahkan `slug` ke `tbl_news`.
9. Menambahkan kolom contributor untuk berita:

   * Redaksi
   * Pewarta
   * Editor
10. ID berita tetap dipakai, tetapi URL publik pindah ke slug.
11. Membuat modul prestasi lengkap.
12. Membuat token input prestasi satu kali pakai.
13. Membuat admin comment moderation.
14. Membuat routing publik dan admin yang jelas.
15. Menjaga share dan comment section news detail dalam satu kolom.
16. Memastikan admin sidebar mobile fixed, tidak bergeser karena scroll halaman.
17. Memastikan modal Team Member dan Prestasi fixed di viewport, bukan turun ke bawah konten.

---

# 2. Prinsip Arsitektur

## Pola utama

```txt
Request
  -> public/index.php
  -> Router
  -> Middleware
  -> Controller
  -> Model
  -> Database
  -> View
  -> Response
```

## Karakter sistem

* Pure PHP.
* Tidak memakai Laravel.
* Tidak memakai CodeIgniter.
* Tidak memakai framework MVC.
* Boleh memakai Composer untuk library kecil.
* Routing dibuat sendiri.
* Model dibuat manual.
* Query database memakai PDO prepared statement.
* View memakai file PHP biasa.
* Session auth memakai PHP session dengan konfigurasi ketat.
* CSRF token wajib untuk semua form POST, PUT, PATCH, DELETE.
* Validasi wajib di backend.
* Sanitasi wajib di backend.

---

# 3. Struktur Folder Project

```txt
genbi-cms/
├── app/
│   ├── Config/
│   │   ├── App.php
│   │   ├── Database.php
│   │   └── Security.php
│   │
│   ├── Core/
│   │   ├── App.php
│   │   ├── Router.php
│   │   ├── Controller.php
│   │   ├── Model.php
│   │   ├── View.php
│   │   ├── Request.php
│   │   ├── Response.php
│   │   ├── Session.php
│   │   ├── Validator.php
│   │   ├── Sanitizer.php
│   │   ├── Csrf.php
│   │   ├── Auth.php
│   │   ├── Upload.php
│   │   ├── Paginator.php
│   │   └── Slugger.php
│   │
│   ├── Middleware/
│   │   ├── AuthMiddleware.php
│   │   ├── GuestMiddleware.php
│   │   ├── CsrfMiddleware.php
│   │   ├── RoleMiddleware.php
│   │   └── ThrottleMiddleware.php
│   │
│   ├── Controllers/
│   │   ├── Public/
│   │   │   ├── HomeController.php
│   │   │   ├── AboutController.php
│   │   │   ├── NewsController.php
│   │   │   ├── EventController.php
│   │   │   ├── TeamController.php
│   │   │   ├── PrestasiController.php
│   │   │   ├── ContactController.php
│   │   │   ├── SearchController.php
│   │   │   └── CommentController.php
│   │   │
│   │   ├── Admin/
│   │   │   ├── AuthController.php
│   │   │   ├── DashboardController.php
│   │   │   ├── SettingsController.php
│   │   │   ├── PageController.php
│   │   │   ├── LanguageController.php
│   │   │   ├── CategoryController.php
│   │   │   ├── NewsController.php
│   │   │   ├── NewsCommentController.php
│   │   │   ├── EventController.php
│   │   │   ├── TeamMemberController.php
│   │   │   ├── SliderController.php
│   │   │   ├── PhotoGalleryController.php
│   │   │   ├── FeatureController.php
│   │   │   ├── WhyChooseController.php
│   │   │   ├── FaqController.php
│   │   │   ├── SocialMediaController.php
│   │   │   ├── PrestasiController.php
│   │   │   └── PrestasiTokenController.php
│   │   │
│   │   └── Api/
│   │       ├── UploadController.php
│   │       ├── EditorImageController.php
│   │       ├── NewsSearchController.php
│   │       └── CommentController.php
│   │
│   ├── Models/
│   │   ├── User.php
│   │   ├── Setting.php
│   │   ├── PageHome.php
│   │   ├── PageAbout.php
│   │   ├── PageNews.php
│   │   ├── PageEvent.php
│   │   ├── PageTeam.php
│   │   ├── PageContact.php
│   │   ├── Language.php
│   │   ├── Category.php
│   │   ├── News.php
│   │   ├── NewsComment.php
│   │   ├── Event.php
│   │   ├── TeamMember.php
│   │   ├── Slider.php
│   │   ├── Photo.php
│   │   ├── Feature.php
│   │   ├── WhyChoose.php
│   │   ├── Faq.php
│   │   ├── SocialMedia.php
│   │   ├── Prestasi.php
│   │   ├── PrestasiToken.php
│   │   ├── AuditLog.php
│   │   └── UploadFile.php
│   │
│   ├── Services/
│   │   ├── AuthService.php
│   │   ├── NewsService.php
│   │   ├── CommentService.php
│   │   ├── PrestasiService.php
│   │   ├── UploadService.php
│   │   ├── SeoService.php
│   │   ├── EditorSanitizerService.php
│   │   ├── TokenService.php
│   │   └── AuditService.php
│   │
│   └── Views/
│       ├── layouts/
│       │   ├── public.php
│       │   ├── admin.php
│       │   └── auth.php
│       │
│       ├── partials/
│       │   ├── public-header.php
│       │   ├── public-footer.php
│       │   ├── admin-sidebar.php
│       │   ├── admin-topbar.php
│       │   ├── flash.php
│       │   ├── pagination.php
│       │   └── modal-confirm.php
│       │
│       ├── public/
│       ├── admin/
│       └── errors/
│
├── bootstrap/
│   └── app.php
│
├── database/
│   ├── migrations/
│   ├── seeds/
│   └── migrate.php
│
├── public/
│   ├── index.php
│   ├── assets/
│   │   ├── css/
│   │   ├── js/
│   │   ├── images/
│   │   └── vendor/
│   └── uploads/
│       ├── news/
│       ├── events/
│       ├── team/
│       ├── prestasi/
│       ├── gallery/
│       └── editor/
│
├── routes/
│   ├── web.php
│   ├── admin.php
│   └── api.php
│
├── storage/
│   ├── logs/
│   ├── cache/
│   └── sessions/
│
├── vendor/
├── .env
├── .env.example
├── composer.json
└── README.md
```

---

# 4. Konfigurasi Database

## `.env.example`

```env
APP_ENV=local
APP_URL=http://127.0.0.1:8000

DB_HOST=127.0.0.1
DB_PORT=3306
DB_NAME=genc1357_genbijambi
DB_USER=root
DB_PASS=

SESSION_NAME=GENBISESSID
SESSION_SECURE=false
SESSION_SAMESITE=Lax

UPLOAD_MAX_MB=5
```

## `app/Config/Database.php`

```php
<?php

namespace App\Config;

final class Database
{
    public static function config(): array
    {
        return [
            'host' => $_ENV['DB_HOST'],
            'port' => $_ENV['DB_PORT'],
            'name' => $_ENV['DB_NAME'],
            'user' => $_ENV['DB_USER'],
            'pass' => $_ENV['DB_PASS'],
            'charset' => 'utf8mb4',
        ];
    }
}
```

## Koneksi PDO wajib memakai prepared statement

```php
$pdo = new PDO(
    "mysql:host={$host};port={$port};dbname={$db};charset=utf8mb4",
    $user,
    $pass,
    [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]
);
```

---

# 5. Strategi Database

Database sekarang punya dua pola:

## 1. Tabel lama

Contoh:

```txt
tbl_news
tbl_category
tbl_event
tbl_team_member
tbl_settings
tbl_page_home
tbl_page_about
tbl_page_contact
tbl_feature
tbl_why_choose
tbl_faq
tbl_photo
tbl_social
tbl_user
```

## 2. Tabel baru atau semi-modern

Contoh:

```txt
news
teams
users
komsats
divisis
images
pewartas
news_pewarta
sessions
```

## Keputusan blueprint

Untuk fase integrasi ini:

1. **Pakai tabel `tbl_*` sebagai sumber utama CMS lama.**
2. Tambahkan kolom baru ke `tbl_news`.
3. Tambahkan tabel baru untuk komentar berita.
4. Tambahkan tabel baru untuk prestasi.
5. Tambahkan tabel token sekali pakai untuk input prestasi.
6. Tambahkan tabel audit log.
7. Jangan hapus tabel `news`, `teams`, atau `users`.
8. Nantinya bisa dibuat migrasi tahap dua untuk unify ke tabel modern.

Alasan:

* Admin existing masih mengarah ke `tbl_*`.
* Public page lama masih memakai ID dari `tbl_news`.
* Permintaan spesifik menyebut `tbl_news`, bukan tabel `news`.
* Perubahan ini lebih aman dan cepat.

---

# 6. Migrasi Database

## 6.1. Buat tabel migrasi untuk pure PHP

Jika tabel `migrations` sudah ada, gunakan tabel itu. Kalau belum ada, buat:

```sql
CREATE TABLE IF NOT EXISTS migrations (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  migration VARCHAR(255) NOT NULL,
  batch INT NOT NULL,
  executed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

---

## 6.2. Migrasi `tbl_news`

Tambahkan slug dan contributor.

```sql
ALTER TABLE tbl_news
  ADD COLUMN slug VARCHAR(255) NULL AFTER news_id,
  ADD COLUMN contributor_redaksi VARCHAR(120) NULL AFTER comment,
  ADD COLUMN contributor_pewarta VARCHAR(120) NULL AFTER contributor_redaksi,
  ADD COLUMN contributor_editor VARCHAR(120) NULL AFTER contributor_pewarta,
  ADD COLUMN content_json LONGTEXT NULL AFTER news_content,
  ADD COLUMN status ENUM('draft','published','archived') NOT NULL DEFAULT 'published' AFTER published,
  ADD COLUMN published_at DATETIME NULL AFTER status,
  ADD COLUMN created_at DATETIME NULL AFTER published_at,
  ADD COLUMN updated_at DATETIME NULL AFTER created_at,
  ADD COLUMN deleted_at DATETIME NULL AFTER updated_at;
```

Buat index:

```sql
ALTER TABLE tbl_news
  ADD UNIQUE KEY uq_tbl_news_slug (slug),
  ADD INDEX idx_tbl_news_category_id (category_id),
  ADD INDEX idx_tbl_news_date (news_date),
  ADD INDEX idx_tbl_news_status (status),
  ADD INDEX idx_tbl_news_published (published);
```

Generate slug untuk data lama:

```sql
UPDATE tbl_news
SET slug = LOWER(
  TRIM(
    BOTH '-' FROM
    REPLACE(
      REPLACE(
        REPLACE(news_title, ' ', '-'),
      '.', ''),
    ',', '')
  )
)
WHERE slug IS NULL OR slug = '';
```

Catatan: slug tetap harus dibersihkan lagi dari PHP karena SQL sederhana di atas belum menangani semua karakter.

---

## 6.3. Tambahkan tabel komentar berita

Jangan pakai `tbl_comment` untuk komentar berita. Tabel `tbl_comment` saat ini lebih cocok sebagai konfigurasi script Facebook comment. Buat tabel baru:

```sql
CREATE TABLE tbl_news_comment (
  comment_id INT NOT NULL AUTO_INCREMENT,
  news_id INT NOT NULL,
  parent_id INT NULL,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL,
  website VARCHAR(180) NULL,
  content TEXT NOT NULL,
  status ENUM('pending','approved','rejected','spam') NOT NULL DEFAULT 'pending',
  ip_address VARCHAR(45) NULL,
  user_agent VARCHAR(255) NULL,
  moderated_by INT NULL,
  moderated_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NULL,
  deleted_at DATETIME NULL,
  PRIMARY KEY (comment_id),
  INDEX idx_news_comment_news_id (news_id),
  INDEX idx_news_comment_parent_id (parent_id),
  INDEX idx_news_comment_status (status),
  INDEX idx_news_comment_created_at (created_at),
  CONSTRAINT fk_news_comment_news
    FOREIGN KEY (news_id) REFERENCES tbl_news(news_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

---

## 6.4. Tambahkan tabel prestasi

```sql
CREATE TABLE tbl_prestasi (
  prestasi_id INT NOT NULL AUTO_INCREMENT,
  title VARCHAR(255) NOT NULL,
  slug VARCHAR(255) NOT NULL,
  category VARCHAR(100) NOT NULL,
  year INT NOT NULL,
  member_name VARCHAR(120) NOT NULL,
  institution VARCHAR(120) NULL,
  description TEXT NOT NULL,
  detail LONGTEXT NULL,
  photo VARCHAR(120) NULL,
  certificate_photo VARCHAR(120) NULL,
  status ENUM('draft','published','archived') NOT NULL DEFAULT 'published',
  is_featured TINYINT(1) NOT NULL DEFAULT 0,
  meta_title VARCHAR(255) NULL,
  meta_keyword TEXT NULL,
  meta_description TEXT NULL,
  created_by INT NULL,
  updated_by INT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NULL,
  deleted_at DATETIME NULL,
  PRIMARY KEY (prestasi_id),
  UNIQUE KEY uq_tbl_prestasi_slug (slug),
  INDEX idx_tbl_prestasi_category (category),
  INDEX idx_tbl_prestasi_year (year),
  INDEX idx_tbl_prestasi_status (status),
  INDEX idx_tbl_prestasi_featured (is_featured)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

---

## 6.5. Tambahkan token input prestasi satu kali pakai

Token tidak boleh disimpan dalam bentuk plain text. Simpan hash.

```sql
CREATE TABLE tbl_prestasi_submission_token (
  token_id INT NOT NULL AUTO_INCREMENT,
  token_hash CHAR(64) NOT NULL,
  label VARCHAR(120) NULL,
  intended_for VARCHAR(120) NULL,
  max_uses TINYINT UNSIGNED NOT NULL DEFAULT 1,
  used_count TINYINT UNSIGNED NOT NULL DEFAULT 0,
  expires_at DATETIME NULL,
  used_at DATETIME NULL,
  created_by INT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  revoked_at DATETIME NULL,
  PRIMARY KEY (token_id),
  UNIQUE KEY uq_prestasi_token_hash (token_hash),
  INDEX idx_prestasi_token_expires_at (expires_at),
  INDEX idx_prestasi_token_used_at (used_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

---

## 6.6. Tambahkan submission log prestasi

```sql
CREATE TABLE tbl_prestasi_submission (
  submission_id INT NOT NULL AUTO_INCREMENT,
  token_id INT NOT NULL,
  prestasi_id INT NULL,
  submitter_name VARCHAR(120) NOT NULL,
  submitter_email VARCHAR(120) NOT NULL,
  payload_json LONGTEXT NOT NULL,
  ip_address VARCHAR(45) NULL,
  user_agent VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (submission_id),
  INDEX idx_prestasi_submission_token_id (token_id),
  INDEX idx_prestasi_submission_prestasi_id (prestasi_id),
  CONSTRAINT fk_prestasi_submission_token
    FOREIGN KEY (token_id) REFERENCES tbl_prestasi_submission_token(token_id)
    ON DELETE CASCADE,
  CONSTRAINT fk_prestasi_submission_prestasi
    FOREIGN KEY (prestasi_id) REFERENCES tbl_prestasi(prestasi_id)
    ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

---

## 6.7. Tambahkan kolom team member

```sql
ALTER TABLE tbl_team_member
  ADD COLUMN komisariat ENUM('Universitas Jambi','UIN Sultan Thaha','Alumni') NULL AFTER designation,
  ADD COLUMN divisi VARCHAR(120) NULL AFTER komisariat,
  ADD COLUMN jabatan VARCHAR(120) NULL AFTER divisi,
  ADD COLUMN divisi_lain VARCHAR(120) NULL AFTER jabatan,
  ADD COLUMN tahun INT NULL AFTER divisi_lain,
  ADD COLUMN status ENUM('active','inactive','alumni') NOT NULL DEFAULT 'active' AFTER tahun,
  ADD COLUMN created_at DATETIME NULL,
  ADD COLUMN updated_at DATETIME NULL,
  ADD COLUMN deleted_at DATETIME NULL;
```

---

## 6.8. Tambahkan audit log

```sql
CREATE TABLE tbl_audit_log (
  audit_id BIGINT NOT NULL AUTO_INCREMENT,
  user_id INT NULL,
  action VARCHAR(80) NOT NULL,
  entity_type VARCHAR(80) NOT NULL,
  entity_id VARCHAR(80) NULL,
  old_data LONGTEXT NULL,
  new_data LONGTEXT NULL,
  ip_address VARCHAR(45) NULL,
  user_agent VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (audit_id),
  INDEX idx_audit_user_id (user_id),
  INDEX idx_audit_entity (entity_type, entity_id),
  INDEX idx_audit_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

---

## 6.9. Perbaiki `tbl_user` untuk auth aman

Password saat ini `varchar(60)`. Untuk `password_hash()`, panjang aman adalah 255.

```sql
ALTER TABLE tbl_user
  MODIFY password VARCHAR(255) NOT NULL,
  ADD COLUMN remember_token_hash CHAR(64) NULL AFTER token,
  ADD COLUMN last_login_at DATETIME NULL AFTER status,
  ADD COLUMN last_login_ip VARCHAR(45) NULL AFTER last_login_at,
  ADD COLUMN failed_login_count INT NOT NULL DEFAULT 0 AFTER last_login_ip,
  ADD COLUMN locked_until DATETIME NULL AFTER failed_login_count;
```

---

# 7. Migration Runner

## Command

```bash
php database/migrate.php
```

## Struktur file migration

```txt
database/migrations/
├── 2026_05_06_000001_alter_tbl_news_add_slug_contributors.php
├── 2026_05_06_000002_create_tbl_news_comment.php
├── 2026_05_06_000003_create_tbl_prestasi.php
├── 2026_05_06_000004_create_tbl_prestasi_submission_token.php
├── 2026_05_06_000005_create_tbl_prestasi_submission.php
├── 2026_05_06_000006_alter_tbl_team_member_add_org_fields.php
├── 2026_05_06_000007_create_tbl_audit_log.php
└── 2026_05_06_000008_alter_tbl_user_security.php
```

## Format migration

```php
<?php

return [
    'up' => function (PDO $db) {
        $db->exec("ALTER TABLE tbl_news ADD COLUMN slug VARCHAR(255) NULL AFTER news_id");
    },

    'down' => function (PDO $db) {
        $db->exec("ALTER TABLE tbl_news DROP COLUMN slug");
    },
];
```

---

# 8. Routing Public

## Route publik utama

| Method | Route                  | Controller                | Action     | Fungsi                |
| ------ | ---------------------- | ------------------------- | ---------- | --------------------- |
| GET    | `/`                    | Public/HomeController     | index      | Landing page          |
| GET    | `/about`               | Public/AboutController    | index      | Profil organisasi     |
| GET    | `/team`                | Public/TeamController     | index      | Direktori anggota     |
| GET    | `/team/{id}`           | Public/TeamController     | show       | Detail anggota        |
| GET    | `/prestasi`            | Public/PrestasiController | index      | Daftar prestasi       |
| GET    | `/prestasi/{slug}`     | Public/PrestasiController | show       | Detail prestasi       |
| GET    | `/prestasi/submit/{token}` | Public/PrestasiController | submissionForm | Form prestasi token |
| POST   | `/prestasi/submit/{token}` | Public/PrestasiController | submitWithToken | Submit prestasi token |
| GET    | `/news`                | Public/NewsController     | index      | Daftar berita         |
| GET    | `/news/{slug}`         | Public/NewsController     | show       | Detail berita by slug |
| GET    | `/news/id/{id}`        | Public/NewsController     | legacyShow | Redirect id ke slug   |
| GET    | `/event`               | Public/EventController    | index      | Daftar event          |
| GET    | `/event/{id}`          | Public/EventController    | show       | Detail event          |
| GET    | `/contact`             | Public/ContactController  | index      | Kontak                |
| POST   | `/contact`             | Public/ContactController  | send       | Kirim pesan           |
| GET    | `/search`              | Public/SearchController   | index      | Search website        |
| POST   | `/news/{slug}/comment` | Public/CommentController  | store      | Submit komentar       |

## Detail route news

### Route baru

```txt
/news/talkshow-siginjai-fest-2026-dorong-generasi-muda-berkarya
```

### Route lama tetap didukung

```txt
/news-detail.php?id=100
/news/id/100
```

### Flow legacy

```txt
User buka /news/id/100
  -> cari tbl_news.news_id = 100
  -> ambil slug
  -> 301 redirect ke /news/{slug}
```

Jika slug belum ada:

```txt
generate slug
update tbl_news.slug
redirect ke slug baru
```

## Layout detail news

Urutan konten detail berita wajib satu kolom:

```txt
Article header
Featured image
Article content
Share section
Comment section
Related articles
```

Share section dan comment section tidak boleh dibuat sebagai dua kolom sejajar. Tujuannya agar alur baca tetap jelas di desktop dan mobile.

---

# 9. Routing Admin

Semua route admin lewat middleware `AuthMiddleware`.

## Auth

| Method | Route             | Controller           | Action         | Middleware            |
| ------ | ----------------- | -------------------- | -------------- | --------------------- |
| GET    | `/admin/login`    | Admin/AuthController | showLogin      | guest                 |
| POST   | `/admin/login`    | Admin/AuthController | login          | guest, csrf, throttle |
| POST   | `/admin/logout`   | Admin/AuthController | logout         | auth, csrf            |
| GET    | `/admin/profile`  | Admin/AuthController | profile        | auth                  |
| POST   | `/admin/profile`  | Admin/AuthController | updateProfile  | auth, csrf            |
| POST   | `/admin/password` | Admin/AuthController | updatePassword | auth, csrf            |

## Dashboard

| Method | Route              | Controller                | Action |
| ------ | ------------------ | ------------------------- | ------ |
| GET    | `/admin`           | Admin/DashboardController | index  |
| GET    | `/admin/dashboard` | Admin/DashboardController | index  |

## Settings

| Method | Route                     | Controller               | Action        |
| ------ | ------------------------- | ------------------------ | ------------- |
| GET    | `/admin/settings`         | Admin/SettingsController | edit          |
| POST   | `/admin/settings/logo`    | Admin/SettingsController | updateLogo    |
| POST   | `/admin/settings/favicon` | Admin/SettingsController | updateFavicon |
| POST   | `/admin/settings/topbar`  | Admin/SettingsController | updateTopbar  |
| POST   | `/admin/settings/footer`  | Admin/SettingsController | updateFooter  |
| POST   | `/admin/settings/email`   | Admin/SettingsController | updateEmail   |
| POST   | `/admin/settings/banner`  | Admin/SettingsController | updateBanner  |
| POST   | `/admin/settings/sidebar` | Admin/SettingsController | updateSidebar |
| POST   | `/admin/settings/color`   | Admin/SettingsController | updateColor   |

## Page CMS

| Method | Route                   | Controller           | Action          |
| ------ | ----------------------- | -------------------- | --------------- |
| GET    | `/admin/page`           | Admin/PageController | index           |
| POST   | `/admin/page/home`      | Admin/PageController | updateHome      |
| POST   | `/admin/page/about`     | Admin/PageController | updateAbout     |
| POST   | `/admin/page/faq`       | Admin/PageController | updateFaq       |
| POST   | `/admin/page/service`   | Admin/PageController | updateService   |
| POST   | `/admin/page/news`      | Admin/PageController | updateNews      |
| POST   | `/admin/page/event`     | Admin/PageController | updateEvent     |
| POST   | `/admin/page/contact`   | Admin/PageController | updateContact   |
| POST   | `/admin/page/search`    | Admin/PageController | updateSearch    |
| POST   | `/admin/page/terms`     | Admin/PageController | updateTerms     |
| POST   | `/admin/page/privacy`   | Admin/PageController | updatePrivacy   |
| POST   | `/admin/page/team`      | Admin/PageController | updateTeam      |
| POST   | `/admin/page/portfolio` | Admin/PageController | updatePortfolio |

## Language

| Method | Route             | Controller               | Action |
| ------ | ----------------- | ------------------------ | ------ |
| GET    | `/admin/language` | Admin/LanguageController | index  |
| POST   | `/admin/language` | Admin/LanguageController | update |

## Category

| Method | Route                         | Controller               | Action  |
| ------ | ----------------------------- | ------------------------ | ------- |
| GET    | `/admin/category`             | Admin/CategoryController | index   |
| GET    | `/admin/category/create`      | Admin/CategoryController | create  |
| POST   | `/admin/category`             | Admin/CategoryController | store   |
| GET    | `/admin/category/{id}/edit`   | Admin/CategoryController | edit    |
| POST   | `/admin/category/{id}`        | Admin/CategoryController | update  |
| POST   | `/admin/category/{id}/delete` | Admin/CategoryController | destroy |

## News

| Method | Route                        | Controller           | Action    |
| ------ | ---------------------------- | -------------------- | --------- |
| GET    | `/admin/news`                | Admin/NewsController | index     |
| GET    | `/admin/news/create`         | Admin/NewsController | create    |
| POST   | `/admin/news`                | Admin/NewsController | store     |
| GET    | `/admin/news/{id}/edit`      | Admin/NewsController | edit      |
| POST   | `/admin/news/{id}`           | Admin/NewsController | update    |
| POST   | `/admin/news/{id}/delete`    | Admin/NewsController | destroy   |
| POST   | `/admin/news/{id}/publish`   | Admin/NewsController | publish   |
| POST   | `/admin/news/{id}/archive`   | Admin/NewsController | archive   |
| POST   | `/admin/news/{id}/duplicate` | Admin/NewsController | duplicate |

## News comment moderation

| Method | Route                               | Controller                  | Action     |
| ------ | ----------------------------------- | --------------------------- | ---------- |
| GET    | `/admin/news-comments`              | Admin/NewsCommentController | index      |
| GET    | `/admin/news-comments/{id}`         | Admin/NewsCommentController | show       |
| POST   | `/admin/news-comments/{id}/approve` | Admin/NewsCommentController | approve    |
| POST   | `/admin/news-comments/{id}/reject`  | Admin/NewsCommentController | reject     |
| POST   | `/admin/news-comments/{id}/spam`    | Admin/NewsCommentController | markSpam   |
| POST   | `/admin/news-comments/{id}/delete`  | Admin/NewsCommentController | destroy    |
| POST   | `/admin/news-comments/bulk`         | Admin/NewsCommentController | bulkAction |

## Event

| Method | Route                      | Controller            | Action  |
| ------ | -------------------------- | --------------------- | ------- |
| GET    | `/admin/event`             | Admin/EventController | index   |
| GET    | `/admin/event/create`      | Admin/EventController | create  |
| POST   | `/admin/event`             | Admin/EventController | store   |
| GET    | `/admin/event/{id}/edit`   | Admin/EventController | edit    |
| POST   | `/admin/event/{id}`        | Admin/EventController | update  |
| POST   | `/admin/event/{id}/delete` | Admin/EventController | destroy |

## Team Member

| Method | Route                            | Controller                 | Action  |
| ------ | -------------------------------- | -------------------------- | ------- |
| GET    | `/admin/team-member`             | Admin/TeamMemberController | index   |
| GET    | `/admin/team-member/create`      | Admin/TeamMemberController | create  |
| POST   | `/admin/team-member`             | Admin/TeamMemberController | store   |
| GET    | `/admin/team-member/{id}/edit`   | Admin/TeamMemberController | edit    |
| POST   | `/admin/team-member/{id}`        | Admin/TeamMemberController | update  |
| POST   | `/admin/team-member/{id}/delete` | Admin/TeamMemberController | destroy |

## Slider

| Method | Route                       | Controller             | Action  |
| ------ | --------------------------- | ---------------------- | ------- |
| GET    | `/admin/slider`             | Admin/SliderController | index   |
| GET    | `/admin/slider/create`      | Admin/SliderController | create  |
| POST   | `/admin/slider`             | Admin/SliderController | store   |
| GET    | `/admin/slider/{id}/edit`   | Admin/SliderController | edit    |
| POST   | `/admin/slider/{id}`        | Admin/SliderController | update  |
| POST   | `/admin/slider/{id}/delete` | Admin/SliderController | destroy |

## Prestasi

| Method | Route                          | Controller               | Action  |
| ------ | ------------------------------ | ------------------------ | ------- |
| GET    | `/admin/prestasi`              | Admin/PrestasiController | index   |
| GET    | `/admin/prestasi/{id}`         | Admin/PrestasiController | show    |
| GET    | `/admin/prestasi/create`       | Admin/PrestasiController | create  |
| POST   | `/admin/prestasi`              | Admin/PrestasiController | store   |
| GET    | `/admin/prestasi/{id}/edit`    | Admin/PrestasiController | edit    |
| POST   | `/admin/prestasi/{id}`         | Admin/PrestasiController | update  |
| POST   | `/admin/prestasi/{id}/delete`  | Admin/PrestasiController | destroy |
| POST   | `/admin/prestasi/{id}/publish` | Admin/PrestasiController | publish |
| POST   | `/admin/prestasi/{id}/archive` | Admin/PrestasiController | archive |

## Prestasi token

| Method | Route                               | Controller                    | Action   |
| ------ | ----------------------------------- | ----------------------------- | -------- |
| GET    | `/admin/prestasi-token`             | Admin/PrestasiTokenController | index    |
| POST   | `/admin/prestasi-token`             | Admin/PrestasiTokenController | generate |
| POST   | `/admin/prestasi-token/{id}/revoke` | Admin/PrestasiTokenController | revoke   |

## Form input prestasi publik via token

| Method | Route                      | Controller                | Action          |
| ------ | -------------------------- | ------------------------- | --------------- |
| GET    | `/prestasi/submit/{token}` | Public/PrestasiController | submissionForm  |
| POST   | `/prestasi/submit/{token}` | Public/PrestasiController | submitWithToken |

---

# 10. Model Mapping

## `News` Model

Tabel: `tbl_news`

Field utama:

```txt
news_id
slug
news_title
news_content
content_json
news_content_short
news_date
photo
banner
category_id
comment
contributor_redaksi
contributor_pewarta
contributor_editor
meta_title
meta_keyword
meta_description
published
status
published_at
created_at
updated_at
deleted_at
```

Method:

```php
News::paginate($filters)
News::findById($id)
News::findBySlug($slug)
News::create($data)
News::update($id, $data)
News::delete($id)
News::publish($id)
News::archive($id)
News::slugExists($slug, $ignoreId = null)
News::incrementViews($id)
News::related($newsId, $categoryId, $limit = 3)
```

---

## `NewsComment` Model

Tabel: `tbl_news_comment`

Method:

```php
NewsComment::paginateForAdmin($filters)
NewsComment::forNews($newsId)
NewsComment::create($data)
NewsComment::approve($id, $moderatorId)
NewsComment::reject($id, $moderatorId)
NewsComment::markSpam($id, $moderatorId)
NewsComment::delete($id)
NewsComment::countPending()
```

---

## `Prestasi` Model

Tabel: `tbl_prestasi`

Method:

```php
Prestasi::paginate($filters)
Prestasi::published($filters)
Prestasi::findById($id)
Prestasi::findBySlug($slug)
Prestasi::create($data)
Prestasi::update($id, $data)
Prestasi::delete($id)
Prestasi::publish($id)
Prestasi::archive($id)
Prestasi::featured($limit)
Prestasi::slugExists($slug, $ignoreId = null)
```

---

## `PrestasiToken` Model

Tabel: `tbl_prestasi_submission_token`

Method:

```php
PrestasiToken::create($plainToken, $data)
PrestasiToken::findValidByPlainToken($plainToken)
PrestasiToken::markUsed($tokenId)
PrestasiToken::revoke($tokenId)
PrestasiToken::isValid($token)
```

Token hash:

```php
hash('sha256', $plainToken)
```

---

## `TeamMember` Model

Tabel: `tbl_team_member`

Tambahan field:

```txt
komisariat
divisi
jabatan
divisi_lain
tahun
status
```

Method:

```php
TeamMember::paginate($filters)
TeamMember::allActive($filters)
TeamMember::findById($id)
TeamMember::create($data)
TeamMember::update($id, $data)
TeamMember::delete($id)
TeamMember::bpiCore($limit)
```

---

# 11. Auth Blueprint

## Tabel auth utama

Gunakan `tbl_user` agar kompatibel dengan admin lama.

## Login flow

```txt
POST /admin/login
  -> cek CSRF
  -> validasi email dan password
  -> cek rate limit
  -> cari user by email
  -> cek status aktif
  -> cek locked_until
  -> password_verify()
  -> session_regenerate_id(true)
  -> simpan user_id, role, login time
  -> update last_login_at dan last_login_ip
  -> redirect dashboard
```

## Password policy

Minimal:

```txt
min 8 karakter
wajib tidak kosong
hash dengan password_hash(PASSWORD_DEFAULT)
verify dengan password_verify()
```

## Jika password lama masih MD5/plain

Buat fallback hati-hati:

```txt
1. Jika password_verify sukses, lanjut.
2. Jika tidak, cek format lama hanya untuk transisi.
3. Jika cocok, langsung rehash ke password_hash.
4. Setelah migrasi selesai, hapus fallback.
```

## Session security

```php
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => $_ENV['SESSION_SECURE'] === 'true',
    'httponly' => true,
    'samesite' => $_ENV['SESSION_SAMESITE'] ?? 'Lax',
]);
```

## Wajib

* `session_regenerate_id(true)` setelah login.
* `session_regenerate_id(true)` setelah privilege berubah.
* Logout hapus session total.
* CSRF token untuk semua form.
* Rate limit login.
* Lock akun sementara setelah gagal login berulang.

---

# 12. Sanitasi dan Validasi Backend

## Prinsip

Frontend hanya membantu UX. Backend tetap sumber kebenaran.

Semua input wajib lewat:

```txt
Request
  -> Validator
  -> Sanitizer
  -> Service
  -> Model
```

## Sanitasi umum

| Tipe input  | Sanitasi                                     |
| ----------- | -------------------------------------------- |
| Text pendek | trim, strip tags                             |
| Email       | filter_var email                             |
| URL         | filter_var url                               |
| Date        | validasi format                              |
| Number      | cast int                                     |
| Enum        | whitelist                                    |
| HTML editor | HTMLPurifier atau allowlist sanitizer        |
| JSON editor | json_decode, validasi schema                 |
| Upload      | cek MIME, ukuran, ekstensi, nama file random |

## Jangan percaya

* Hidden input.
* Select value.
* File name dari user.
* MIME dari browser saja.
* `content_html` dari editor.
* Slug dari form.
* Role dari form.

---

# 13. Block Level Editor untuk News

## Editor frontend

Gunakan Editor.js.

Library ini bukan framework. Ia cocok untuk block-level editor gaya Medium.

## Data yang disimpan

Simpan dua format:

```txt
content_json = output asli Editor.js
news_content = HTML hasil render yang sudah disanitasi
```

## Kenapa dua format

* `content_json` untuk edit ulang.
* `news_content` untuk render publik cepat.
* HTML tetap harus disanitasi.

## Block yang diizinkan

```txt
paragraph
header
image
quote
list
delimiter
embed youtube
table sederhana
```

## Upload image dalam paragraf

Route:

```txt
POST /api/editor/image
```

Response:

```json
{
  "success": 1,
  "file": {
    "url": "/uploads/editor/2026/05/random-name.webp"
  }
}
```

## Validasi upload editor

```txt
MIME: image/jpeg, image/png, image/webp
Max: 5 MB
Resize maksimal: 1600 px
Nama file: random
Path: public/uploads/editor/YYYY/MM
```

## Sanitasi HTML output

Allowlist tag:

```txt
p, h2, h3, h4, strong, em, u, a, ul, ol, li, blockquote, figure, figcaption, img, iframe
```

Allowlist attribute:

```txt
a[href,title,target,rel]
img[src,alt,width,height,loading]
iframe[src,width,height,allow,allowfullscreen,frameborder,referrerpolicy]
```

Allowlist iframe hanya:

```txt
https://www.youtube.com/embed/
https://youtube.com/embed/
```

---

# 14. News Feature Blueprint

## Public news list

Route:

```txt
GET /news
```

Fitur:

* List berita published.
* Filter category.
* Search.
* Pagination.
* Sorting terbaru.
* Dropdown custom.
* Latest news item punya picture.
* Caption memakai `news_content_short`.
* URL memakai slug.

Query filter:

```txt
/news?category=bank-indonesia&q=talkshow&page=1
```

## Public news detail

Route:

```txt
GET /news/{slug}
```

Konten:

* Category.
* Date.
* Title.
* Featured photo.
* Content.
* Contributor:

  * Redaksi
  * Pewarta
  * Editor
* Share section.
* Comment section satu column.
* Artikel terkait dengan picture kiri.
* Komentar approved saja.

## Admin news list

Route:

```txt
GET /admin/news
```

Fitur:

* Search title.
* Filter category.
* Filter status.
* Pagination.
* Quick action:

  * Edit
  * Delete
  * Publish
  * Archive
* Custom confirmation modal.

## Admin add/edit news

Route:

```txt
GET /admin/news/create
GET /admin/news/{id}/edit
```

Layout:

```txt
Main area:
  Block editor besar

Sidebar:
  Title
  News Short Content
  Category
  Date
  Contributor Redaksi
  Contributor Pewarta
  Contributor Editor
  Featured Photo
  Banner
  Comment On/Off
  Status
  SEO
  Save Draft
  Publish
```

Validasi:

```txt
news_title: required, min 5, max 255
news_content_short: required, max 500
content_json: required, valid editor json
news_date: required, date
category_id: required, exists tbl_category
comment: required, enum On/Off
status: required, enum draft/published/archived
photo: nullable image
banner: nullable image
meta_title: nullable max 255
meta_keyword: nullable max 500
meta_description: nullable max 300
```

Slug:

```txt
Jika title baru dibuat:
  generate dari news_title

Jika title diedit:
  slug tidak berubah otomatis, kecuali admin klik "Regenerate slug"
```

---

# 15. Comment Section Blueprint

## Public submit comment

Route:

```txt
POST /news/{slug}/comment
```

Input:

```txt
name
email
website optional
content
parent_id optional
csrf_token
```

Backend:

```txt
1. Validasi CSRF.
2. Cari berita by slug.
3. Pastikan comment_enabled aktif.
4. Validasi field.
5. Sanitasi content.
6. Cek honeypot.
7. Cek throttle by IP.
8. Simpan status pending.
9. Tampilkan pesan: Komentar menunggu moderasi.
```

## News detail share and comment layout

Layout detail berita:

```txt
Article content
Share section
Comment section
Related articles
```

Aturan:

* Share dan komentar tampil dalam satu kolom, bukan grid dua kolom.
* Share section muncul sebelum komentar.
* Comment form mengikuti lebar konten artikel agar tidak terlalu melebar.
* Share URL memakai canonical slug URL `/news/{slug}`.
* Copy link harus memberi feedback singkat seperti `Link disalin`.
* Komentar publik hanya menampilkan status `approved`.
* Komentar baru tetap masuk status `pending` sampai dimoderasi admin.

## Admin comment moderation

Route:

```txt
GET /admin/news-comments
```

Fitur:

* Filter status:

  * Pending
  * Approved
  * Rejected
  * Spam
* Filter berita.
* Search nama/email/content.
* Bulk approve.
* Bulk reject.
* Mark spam.
* Delete.
* Link ke berita terkait.

## Status logic

```txt
pending:
  Baru masuk, belum tampil publik.

approved:
  Tampil di halaman berita.

rejected:
  Tidak tampil, masih tersimpan.

spam:
  Tidak tampil, dipakai untuk evaluasi spam manual.

deleted_at:
  Soft delete.
```

---

# 16. Prestasi Blueprint

## Public prestasi list

Route:

```txt
GET /prestasi
```

Fitur:

* Filter kategori.
* Filter tahun.
* Search.
* List editorial.
* Klik item buka modal detail.
* Modal fixed, tidak ikut scroll.
* Modal punya gambar prestasi.

## Public prestasi detail

Route:

```txt
GET /prestasi/{slug}
```

Opsional. Tetap disediakan untuk SEO.

## Admin manage prestasi

Route:

```txt
GET /admin/prestasi
```

Fitur:

* List prestasi.
* Detail item prestasi.
* Search.
* Filter kategori.
* Filter tahun.
* Filter status.
* Add.
* Edit.
* Delete.
* Publish.
* Archive.

Halaman admin wajib menyediakan:

```txt
GET /admin/prestasi
GET /admin/prestasi/{id}
GET /admin/prestasi/create
GET /admin/prestasi/{id}/edit
```

Alur minimal:

```txt
List prestasi
  -> Detail item
  -> Edit item
  -> Delete dengan custom confirmation modal
```

## Form prestasi

Field:

```txt
title
category
year
member_name
institution
description
detail
photo
certificate_photo
status
is_featured
meta_title
meta_keyword
meta_description
```

## Token input prestasi satu kali

### Admin generate token

Route:

```txt
POST /admin/prestasi-token
```

Admin isi:

```txt
label
intended_for
expires_at
```

System generate:

```txt
plain token: random 32 bytes
token_hash: sha256
url: /prestasi/submit/{plainToken}
```

Plain token hanya ditampilkan sekali.

Admin token page harus menampilkan:

* Generate token form.
* Riwayat token.
* Status token: `active`, `used`, `expired`, `revoked`.
* Link token yang bisa disalin setelah token dibuat.
* Tombol revoke untuk token aktif.
* Indikator bahwa token hanya bisa dipakai satu kali.

### Public submit via token

Route:

```txt
GET /prestasi/submit/{token}
POST /prestasi/submit/{token}
```

Flow:

```txt
1. Hash token dari URL.
2. Cari token_hash.
3. Cek revoked_at null.
4. Cek used_count < max_uses.
5. Cek expires_at.
6. Validasi form.
7. Upload gambar.
8. Simpan ke tbl_prestasi dengan status draft.
9. Simpan submission log.
10. Tambahkan used_count.
11. Set used_at.
12. Token invalid setelah submit.
```

Aturan one-time token:

* `max_uses` default `1`.
* Token langsung tidak valid setelah submit berhasil.
* Plain token tidak boleh disimpan; simpan hanya `hash('sha256', $plainToken)`.
* Jika token sudah used, expired, revoked, atau tidak ditemukan, form tidak boleh tampil.
* Jika submit gagal validasi, token tetap aktif selama data belum tersimpan.
* Setelah data prestasi tersimpan, update token dan submission log dalam transaksi database yang sama.

---

# 17. Team Member Blueprint

## Public team

Route:

```txt
GET /team
```

Fitur:

* Search nama, jabatan, divisi, kampus.
* Filter komisariat:

  * Semua
  * Universitas Jambi
  * UIN Sultan Thaha
  * Alumni
* Filter divisi.
* Filter tahun.
* List mode.
* Detail modal fixed.
* Skeleton jika foto gagal load.

Aturan modal:

* Modal Team Member wajib dirender melalui root modal global di akhir `body`.
* Modal fixed terhadap viewport, bukan terhadap card/list container.
* Modal tidak boleh turun ke bawah ketika halaman sudah discroll.
* Saat modal terbuka, fokus pindah ke dialog, `Escape` menutup modal, backdrop menutup modal, dan fokus kembali ke trigger.

## Admin team member

Route:

```txt
GET /admin/team-member
GET /admin/team-member/create
GET /admin/team-member/{id}/edit
```

Field:

```txt
name
designation
komisariat
divisi
jabatan
divisi_lain
tahun
photo
detail
phone
email
website
instagram
linkedin
meta_title
meta_keyword
meta_description
status
```

Validasi komisariat:

```txt
Universitas Jambi
UIN Sultan Thaha
Alumni
```

---

# 18. Event Blueprint

## Public event list

Route:

```txt
GET /event
```

Fitur:

* Event card horizontal carousel di landing page.
* Event list di halaman event.
* Icon per item.
* Status:

  * upcoming
  * past
* Detail modal atau halaman detail.

## Admin event

Route:

```txt
GET /admin/event
GET /admin/event/create
GET /admin/event/{id}/edit
```

Field existing:

```txt
event_title
event_content
event_content_short
event_start_date
event_end_date
event_location
event_map
photo
banner
meta_title
meta_keyword
meta_description
```

Validasi:

```txt
event_title required
event_start_date required date
event_end_date required date after_or_equal start
event_location required
event_content sanitized html
photo image optional
banner image optional
```

---

# 19. Landing Page Data Mapping

## Hero

Sumber:

```txt
tbl_slider
tbl_settings.logo
tbl_settings.top_bar_email
tbl_settings.top_bar_phone
```

## Program utama

Sumber:

```txt
tbl_feature
```

Atau bisa migrasi ke tabel baru:

```txt
tbl_program
```

Untuk fase ini, tetap gunakan `tbl_feature`.

## BPI Provinsi Jambi

Sumber:

```txt
tbl_team_member
```

Filter:

```txt
designation contains Ketua Umum, Sekretaris, Bendahara, Koordinator
status active
```

Lebih baik tambahkan field:

```txt
is_bpi_core TINYINT(1)
sort_order INT
```

Migrasi opsional:

```sql
ALTER TABLE tbl_team_member
  ADD COLUMN is_bpi_core TINYINT(1) NOT NULL DEFAULT 0 AFTER status,
  ADD COLUMN sort_order INT NOT NULL DEFAULT 0 AFTER is_bpi_core;
```

## Agenda utama

Sumber:

```txt
tbl_event
```

## Latest news

Sumber:

```txt
tbl_news
```

Syarat:

```txt
published = 1
status = published
deleted_at IS NULL
```

---

# 20. Upload Handling

## Folder upload

```txt
public/uploads/news/
public/uploads/events/
public/uploads/team/
public/uploads/prestasi/
public/uploads/gallery/
public/uploads/editor/
```

## Aturan nama file

Jangan pakai nama asli.

Format:

```txt
{module}-{date}-{random}.webp
```

Contoh:

```txt
news-20260506-a8f91c2d.webp
```

## Validasi file

```txt
Max size: 5 MB
Allowed mime:
  image/jpeg
  image/png
  image/webp
```

Gunakan:

```php
finfo_file()
getimagesize()
```

Jangan percaya `$_FILES['type']`.

---

# 21. API Internal

## Editor image upload

| Method | Route               | Fungsi                          |
| ------ | ------------------- | ------------------------------- |
| POST   | `/api/editor/image` | Upload image untuk block editor |

Middleware:

```txt
auth
csrf
```

## News search

| Method | Route                 | Fungsi                                |
| ------ | --------------------- | ------------------------------------- |
| GET    | `/api/news/search?q=` | Search ringan untuk admin atau public |

## Comment count

| Method | Route                       | Fungsi                  |
| ------ | --------------------------- | ----------------------- |
| GET    | `/api/admin/comments/count` | Jumlah komentar pending |

Middleware:

```txt
auth
```

---

# 22. Controller Responsibilities

## Controller tidak boleh berisi query panjang

Controller hanya:

```txt
ambil request
validasi
panggil service/model
return view/redirect/json
```

## Query ada di Model

Contoh:

```php
final class News extends Model
{
    public function findBySlug(string $slug): ?array
    {
        $stmt = $this->db->prepare("
            SELECT n.*, c.category_name
            FROM tbl_news n
            LEFT JOIN tbl_category c ON c.category_id = n.category_id
            WHERE n.slug = :slug
              AND n.deleted_at IS NULL
            LIMIT 1
        ");

        $stmt->execute(['slug' => $slug]);

        return $stmt->fetch() ?: null;
    }
}
```

---

# 23. Security Checklist

## Auth

* Password hash memakai `password_hash()`.
* Login memakai `password_verify()`.
* Session regenerate setelah login.
* Cookie session `HttpOnly`.
* Cookie session `SameSite=Lax`.
* Lock akun setelah gagal login berulang.
* Logout destroy session.
* Role check untuk admin.
* Jangan tampilkan error login detail.

## CSRF

* Semua POST wajib CSRF.
* Token disimpan di session.
* Token diregenerasi berkala.
* Form delete tetap POST, bukan GET.

## XSS

* Output escaped default:

```php
htmlspecialchars($value, ENT_QUOTES, 'UTF-8')
```

* HTML dari editor disanitasi allowlist.
* Komentar tidak boleh render HTML bebas.

## SQL Injection

* Semua query memakai prepared statement.
* Tidak concat input ke SQL.
* Sort column memakai whitelist.

## Upload

* Cek ukuran.
* Cek MIME.
* Cek dimensi gambar.
* Nama file random.
* Jangan izinkan upload `.php`.
* Folder upload tidak boleh execute PHP.

Tambahkan `.htaccess` di uploads:

```apache
php_flag engine off
Options -ExecCGI
RemoveHandler .php .phtml .php3 .php4 .php5 .php7 .php8
```

## Rate limit

Minimal:

```txt
login: 5 percobaan per 10 menit
comment: 3 komentar per 5 menit per IP
contact: 3 submit per 10 menit per IP
prestasi token submit: 1 submit per token
```

---

# 24. Role dan Permission

## Role minimal

```txt
superadmin
admin
editor
moderator
```

## Permission map

| Fitur              | Superadmin | Admin | Editor | Moderator |
| ------------------ | ---------: | ----: | -----: | --------: |
| Dashboard          |        yes |   yes |    yes |       yes |
| Settings           |        yes |   yes |     no |        no |
| Page CMS           |        yes |   yes |     no |        no |
| News CRUD          |        yes |   yes |    yes |        no |
| News publish       |        yes |   yes |    yes |        no |
| Comment moderation |        yes |   yes |    yes |       yes |
| Event CRUD         |        yes |   yes |    yes |        no |
| Team CRUD          |        yes |   yes |     no |        no |
| Prestasi CRUD      |        yes |   yes |    yes |        no |
| Prestasi token     |        yes |   yes |     no |        no |
| User management    |        yes |    no |     no |        no |

Jika `tbl_user.role` masih string bebas, gunakan whitelist.

---

# 25. View Structure

## Public layout

```txt
Views/layouts/public.php
```

Include:

```txt
public-header
content
public-footer
modal-root
script stack
```

## Admin layout

```txt
Views/layouts/admin.php
```

Include:

```txt
admin-sidebar
admin-topbar
flash
content
confirmation modal
script stack
```

## Modal root

Letakkan sebelum `</body>`:

```html
<div id="modal-root"></div>
```

Modal fixed harus keluar dari container scroll.

Modal yang wajib mengikuti aturan ini:

* Team Member detail modal.
* Prestasi detail modal.
* Semua custom confirmation modal admin.

Perilaku wajib:

* Modal container memakai `position: fixed` dan berada di bawah `#modal-root`.
* Modal tidak boleh berada di dalam card, table, sidebar, atau container yang punya `overflow`, `transform`, atau scroll context.
* Fokus masuk ke dialog saat modal terbuka.
* Fokus tetap di dalam modal sampai ditutup.
* `Escape`, backdrop, dan close button menutup modal.
* Fokus kembali ke elemen pemicu setelah modal ditutup.

---

# 26. Admin UI Integration

## Sidebar mobile bug

Sidebar admin harus:

```css
.admin-sidebar {
  position: fixed;
  inset-block: 0;
  left: 0;
  z-index: 80;
  overflow-y: auto;
}
```

Overlay:

```css
.admin-overlay {
  position: fixed;
  inset: 0;
  z-index: 70;
}
```

Body lock saat sidebar terbuka:

```js
document.body.classList.add('overflow-hidden');
```

Acceptance sidebar mobile:

* Sidebar tetap fixed ketika halaman admin discroll.
* Sidebar tidak ikut terdorong oleh scroll container konten.
* Overlay menutup seluruh viewport.
* Sidebar berada di atas overlay.
* Menu bisa discroll sendiri jika item lebih tinggi dari viewport.
* `Escape` menutup sidebar.
* Klik overlay menutup sidebar.
* Body scroll terkunci saat sidebar terbuka dan pulih saat sidebar ditutup.

## Custom modal confirmation

Semua delete pakai modal custom.

Data attribute:

```html
<button
  data-confirm
  data-title="Hapus berita?"
  data-message="Data yang dihapus tidak tampil di publik."
  data-action="/admin/news/100/delete">
  Delete
</button>
```

JS:

```txt
Klik button
  -> buka modal
  -> isi form action
  -> submit POST dengan CSRF
```

---

# 27. SEO Blueprint

## News detail

Meta source:

```txt
meta_title fallback news_title
meta_description fallback news_content_short
meta_keyword fallback category + title
og_image fallback photo
canonical_url /news/{slug}
```

## Prestasi detail

Meta source:

```txt
meta_title fallback title
meta_description fallback description
og_image fallback photo
canonical_url /prestasi/{slug}
```

## Redirect

```txt
/news/id/{id} -> /news/{slug}
```

Pakai status:

```txt
301 permanent
```

---

# 28. Error Handling

## Error pages

```txt
Views/errors/404.php
Views/errors/403.php
Views/errors/419.php
Views/errors/500.php
```

## Logging

Simpan ke:

```txt
storage/logs/app.log
```

Log jangan menyimpan:

```txt
password
csrf token
session id
database password
plain token prestasi
```

---

# 29. Feature dan Subfeature Map

## Public Website

| Feature      | Subfeature                 | Backend Source                     |
| ------------ | -------------------------- | ---------------------------------- |
| Landing page | Hero                       | `tbl_slider`, `tbl_settings`       |
| Landing page | Program utama carousel     | `tbl_feature`                      |
| Landing page | BPI Provinsi Jambi         | `tbl_team_member`                  |
| Landing page | Agenda utama carousel      | `tbl_event`                        |
| Landing page | Latest news with picture   | `tbl_news`                         |
| Landing page | Contact and address        | `tbl_settings`, `tbl_page_contact` |
| About        | Profil organisasi          | `tbl_page_about`                   |
| Team         | Directory, search, filter  | `tbl_team_member`                  |
| Team         | Detail modal               | `tbl_team_member`                  |
| Prestasi     | List, filter, detail modal | `tbl_prestasi`                     |
| News         | List, search, filter       | `tbl_news`, `tbl_category`         |
| News         | Detail by slug             | `tbl_news`                         |
| News         | Related article with image | `tbl_news`                         |
| News         | Share section              | computed URL                       |
| News         | Comment section            | `tbl_news_comment`                 |
| Event        | List and detail            | `tbl_event`                        |
| Contact      | Form and address           | `tbl_page_contact`, mail config    |

## Admin CMS

| Feature        | Subfeature                             | Table                                            |
| -------------- | -------------------------------------- | ------------------------------------------------ |
| Auth           | Login, logout, profile                 | `tbl_user`                                       |
| Dashboard      | Counts and summaries                   | all main tables                                  |
| Settings       | Logo, favicon, footer, topbar, banners | `tbl_settings`                                   |
| Page CMS       | Home, About, FAQ, News, Event, Contact | `tbl_page_*`                                     |
| Language       | Text translation                       | `tbl_language`                                   |
| Category       | News category CRUD                     | `tbl_category`                                   |
| News           | List, add, edit, delete                | `tbl_news`                                       |
| News           | Block editor                           | `tbl_news.content_json`, `tbl_news.news_content` |
| News           | Contributor                            | `tbl_news.contributor_*`                         |
| News Comments  | Moderation                             | `tbl_news_comment`                               |
| Event          | CRUD                                   | `tbl_event`                                      |
| Team Member    | CRUD                                   | `tbl_team_member`                                |
| Slider         | CRUD                                   | `tbl_slider`                                     |
| Photo Gallery  | CRUD                                   | `tbl_photo`                                      |
| Feature        | CRUD                                   | `tbl_feature`                                    |
| Why Choose Us  | CRUD                                   | `tbl_why_choose`                                 |
| FAQ            | CRUD                                   | `tbl_faq`                                        |
| Social Media   | CRUD                                   | `tbl_social`                                     |
| Prestasi       | CRUD                                   | `tbl_prestasi`                                   |
| Prestasi Token | Generate, revoke                       | `tbl_prestasi_submission_token`                  |

---

# 30. Implementation Phases

## Phase 1: Foundation

1. Buat struktur folder.
2. Buat `.env`.
3. Buat PDO database connection.
4. Buat Router.
5. Buat Controller base.
6. Buat Model base.
7. Buat View renderer.
8. Buat Session, CSRF, Validator, Sanitizer.
9. Buat migration runner.

Output:

```txt
Aplikasi bisa buka public route dan admin login route.
```

---

## Phase 2: Auth Admin

1. Migrasi `tbl_user.password` ke 255.
2. Buat AuthService.
3. Buat AuthController.
4. Buat AuthMiddleware.
5. Buat login page.
6. Buat logout.
7. Buat password hash migration.
8. Tambahkan rate limit login.

Output:

```txt
Admin bisa login aman.
```

---

## Phase 3: Public Read Pages

1. Integrasi home.
2. Integrasi about.
3. Integrasi news list.
4. Integrasi news detail by slug.
5. Integrasi event.
6. Integrasi team.
7. Integrasi contact.
8. Integrasi footer.

Output:

```txt
Website publik bisa membaca data dari database.
```

---

## Phase 4: News CMS

1. Migrasi `tbl_news`.
2. Generate slug data lama.
3. Buat News model.
4. Buat NewsController admin.
5. Buat block editor.
6. Buat editor image upload.
7. Buat add/edit news layout.
8. Buat contributor fields.
9. Buat custom upload input.
10. Buat custom dropdown.
11. Buat confirmation modal.

Output:

```txt
Admin bisa manage news dengan block editor.
```

---

## Phase 5: Comment System

1. Migrasi `tbl_news_comment`.
2. Buat public comment form.
3. Buat backend submit comment.
4. Buat admin moderation.
5. Buat approve, reject, spam, delete.
6. Tambahkan count pending di dashboard.

Output:

```txt
Komentar berita bisa masuk dan dimoderasi.
```

---

## Phase 6: Prestasi CMS

1. Migrasi `tbl_prestasi`.
2. Buat Prestasi model.
3. Buat public prestasi page.
4. Buat modal detail prestasi.
5. Buat admin prestasi CRUD.
6. Buat upload gambar prestasi.
7. Buat filter kategori dan tahun.

Output:

```txt
Prestasi bisa dikelola dari admin.
```

---

## Phase 7: One-Time Token Prestasi

1. Migrasi token.
2. Buat token generator.
3. Buat form submit publik via token.
4. Validasi token.
5. Invalidate token setelah submit.
6. Simpan submission log.

Output:

```txt
Input prestasi eksternal bisa dilakukan satu kali via token.
```

---

## Phase 8: Hardening dan QA

1. Test SQL injection.
2. Test XSS.
3. Test CSRF.
4. Test upload file.
5. Test route auth.
6. Test mobile sidebar.
7. Test modal fixed.
8. Test dropdown z-index.
9. Test slug redirect.
10. Test responsive admin.

Output:

```txt
Siap deploy.
```

---

# 31. Minimal Composer Library

Ini bukan framework. Ini library utilitas.

```json
{
  "require": {
    "vlucas/phpdotenv": "^5.6",
    "ezyang/htmlpurifier": "^4.17"
  },
  "autoload": {
    "psr-4": {
      "App\\": "app/"
    }
  }
}
```

Jika mau benar-benar tanpa Composer, `.env` parser dan sanitizer bisa dibuat manual. Tapi untuk HTML editor, `HTMLPurifier` jauh lebih aman.

---

# 32. Deployment Checklist

## Server

* PHP 8.2 atau lebih baru.
* PDO MySQL aktif.
* File upload aktif.
* `display_errors=Off`.
* `log_errors=On`.
* Folder `storage/logs` writable.
* Folder `public/uploads` writable.
* `.env` tidak bisa diakses publik.

## Web root

Arahkan domain ke:

```txt
/public
```

Jangan arahkan ke root project.

## Permissions

```bash
chmod -R 755 public
chmod -R 775 public/uploads storage
```

## Production security

```txt
APP_ENV=production
SESSION_SECURE=true
DISPLAY_ERRORS=false
```

---

# 33. Catatan Kritis

1. Jangan pakai akun database root untuk production.
2. Buat user database khusus dengan akses hanya ke database GenBI.
3. Jangan simpan password database di Git.
4. Jangan render HTML dari editor tanpa sanitizer.
5. Jangan pakai GET untuk delete.
6. Jangan pakai ID saja untuk URL berita baru.
7. Tetap dukung ID lama lewat redirect.
8. Simpan token prestasi dalam bentuk hash.
9. Plain token hanya tampil sekali.
10. Setiap aksi admin penting masuk audit log.
