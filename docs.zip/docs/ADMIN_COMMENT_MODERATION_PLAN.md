# Admin Comment Moderation Implementation Plan

**Goal:** Convert `admin/comment.html` from a static moderation mock into a backend-shaped, test-backed moderation dashboard with static fallback.

**Architecture:** Keep the current static prototype usable by extending `window.GenBIAPI` with admin comment methods that target the planned pure PHP MVC routes from `BLUEPRINTS.md` and fall back to dummy moderation data. Keep all shape mapping in `assets/js/api-core.js` so Node tests can verify filtering, counts, status normalization, and action endpoint construction before browser code renders it.

**Tech Stack:** Static HTML, vanilla JavaScript, CommonJS-compatible test utilities, Node built-in test runner, existing CSS classes in `assets/css/styles.css`.

---

## Phase Scope

This phase implements the P1 roadmap item:

- `P1: Update admin comment page as moderation dashboard wired to backend-shaped API.`

This phase does not build the PHP backend yet. It aligns the frontend with future backend routes:

- `GET /admin/news-comments`
- `POST /admin/news-comments/{id}/approve`
- `POST /admin/news-comments/{id}/reject`
- `POST /admin/news-comments/{id}/delete`

## Files

- Modify: `assets/js/api-core.js`
- Modify: `assets/js/api.js`
- Modify: `assets/js/admin/cms.js`
- Modify: `admin/comment.html`
- Modify: `tests/api-core.test.js`
- Modify: `docs/PROJECT_PROGRESS.md`

## Acceptance Criteria

- Admin comment dashboard reads comments from `window.GenBIAPI.getAdminComments()`.
- Static fallback still works if backend routes do not exist.
- Dashboard counts show `Pending`, `Approved`, and `Rejected/Flagged` correctly.
- Status filter works for `Semua`, `Pending`, `Approved`, `Rejected`, and `Flagged`.
- Search filters by article title, commenter name, email, and comment text.
- Approve updates comment status through `POST /admin/news-comments/{id}/approve`, with fallback mutation.
- Reject updates status through `POST /admin/news-comments/{id}/reject`, with fallback mutation.
- Delete uses a custom confirmation modal and calls `POST /admin/news-comments/{id}/delete`, with fallback removal.
- `npm test` passes before `docs/PROJECT_PROGRESS.md` checkboxes are marked complete.

## Tasks

### Task 1: Add Admin Comment Normalization Tests

- [ ] Add tests to `tests/api-core.test.js` for `normalizeAdminComments`, `getCommentModerationStats`, `filterAdminComments`, and `buildCommentActionEndpoint`.
- [ ] Run `npm test` and confirm the new tests fail before implementation.

### Task 2: Implement Admin Comment Utilities

- [ ] Add `normalizeCommentStatus(value)` to `assets/js/api-core.js`.
- [ ] Add `normalizeAdminComments(payload)` to map backend or fallback comment payloads into one UI shape.
- [ ] Add `getCommentModerationStats(comments)` for dashboard counts.
- [ ] Add `filterAdminComments(comments, filters)` for search and status filtering.
- [ ] Add `buildCommentActionEndpoint(id, action)` for approve/reject/delete endpoints.
- [ ] Run `npm test` and confirm utility tests pass.

### Task 3: Add Admin Comment API Methods

- [ ] Add fallback admin comment data in `assets/js/api.js`.
- [ ] Add `getAdminComments(filters)` using `GET /admin/news-comments` and static fallback.
- [ ] Add `moderateComment(id, action)` using `POST /admin/news-comments/{id}/{action}` and fallback response.
- [ ] Export the new API methods through `window.GenBIAPI`.
- [ ] Run `npm test`.

### Task 4: Wire Admin Comment Dashboard

- [ ] Update `admin/comment.html` to load `assets/js/api-core.js` and `assets/js/api.js` before admin scripts.
- [ ] Replace `renderCommentSetup()` static local array with API-backed state in `assets/js/admin/cms.js`.
- [ ] Render dashboard stats from normalized comments.
- [ ] Render search input and status filter buttons from state.
- [ ] Bind search input to live filtering.
- [ ] Bind status buttons to live filtering.
- [ ] Bind Approve, Reject, and Delete buttons to `GenBIAPI.moderateComment()`.
- [ ] Use `Admin.showConfirm()` for reject/delete actions.
- [ ] Show clear empty and loading states.
- [ ] Run `npm test`.

### Task 5: Update Progress Tracker

- [ ] Mark `docs/PROJECT_PROGRESS.md` P1 admin comment moderation item complete only after `npm test` passes.
- [ ] Add test log entry with the latest passing test count.
- [ ] Add progress log entry summarizing admin moderation integration.

## Verification

- Run `npm test`.
- Run `npm run build:css` only if Tailwind classes changed or after dependency state is repaired.
- Manually smoke test `admin/comment.html` with `npm run serve` once dependencies are healthy enough for local frontend serving.

## Known Constraint

Current dependency state has a partial/corrupt `node_modules`: `npm run build:css` failed because `tailwindcss` was missing from `node_modules/.bin`, and `npm install` failed with `ENOTEMPTY` while renaming `node_modules/autoprefixer`. This phase avoids new Tailwind-only classes and should not require CSS rebuilding.
