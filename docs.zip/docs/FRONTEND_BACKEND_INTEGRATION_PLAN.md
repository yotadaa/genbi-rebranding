# Frontend-Backend Integration Plan

## Goal

Integrate the existing static GenBI frontend with the planned pure PHP MVC backend while keeping the prototype usable before the backend exists.

## Architecture

The frontend will use a lightweight `GenBIAPI` adapter. Page scripts call this adapter instead of reading `window.GenBIData` directly. The adapter tries backend routes from `BLUEPRINTS.md`; if a backend request fails or returns an unexpected shape, it normalizes and returns existing static dummy data.

## Backend Route Targets

| Area | Method | Route | Frontend Use |
| --- | --- | --- | --- |
| News list | `GET` | `/news` | Render `news.html` and latest news on home. |
| News detail | `GET` | `/news/{slug}` | Render `news-detail.html` by slug. |
| Legacy news | `GET` | `/news/id/{id}` | Bridge current `news-detail.html?id=100`. |
| Comments | `POST` | `/news/{slug}/comment` | Submit public comment for moderation. |
| Prestasi list | `GET` | `/prestasi` | Render public Prestasi list. |
| Prestasi detail | `GET` | `/prestasi/{slug}` | Render modal/detail data. |
| Prestasi token submit form | `GET` | `/prestasi/submit/{token}` | Render one-time public Prestasi input form only when token is valid. |
| Prestasi token submit action | `POST` | `/prestasi/submit/{token}` | Submit Prestasi once, then invalidate the token. |
| Team list | `GET` | `/team` | Render team directory and BPI list. |
| Admin comments | `GET` | `/admin/news-comments` | Render moderation dashboard. |
| Admin comment action | `POST` | `/admin/news-comments/{id}/approve|reject|delete` | Moderate comments. |
| Admin Prestasi | `GET/POST` | `/admin/prestasi` | CRUD Prestasi CMS. |
| Admin Prestasi detail | `GET` | `/admin/prestasi/{id}` | Preview one Prestasi item before edit/delete. |
| Prestasi token | `GET/POST` | `/admin/prestasi-token` | Generate and audit token links. |
| Prestasi token revoke | `POST` | `/admin/prestasi-token/{id}/revoke` | Revoke an unused token. |

## Data Normalization Rules

- News title: `news_title`, then `title`.
- News short content: `news_content_short`, then `excerpt`.
- News date: `published_at`, then `news_date`, then `date`.
- News image: `photo`, then `banner`, then `image`, then default fallback image.
- News slug: `slug`, then generated from title and id.
- Comment status: only `approved`/`Approved`/`Disetujui` is public.
- Prestasi title: `judul_prestasi`, then `title`.
- Prestasi member: `nama_anggota`, then `name`.
- Prestasi campus: `komisariat`, then `campus`.
- Prestasi token status: only `active` can render the submit form; `used`, `expired`, `revoked`, and missing tokens render an invalid-token state.

## UI Stability Requirements

- News detail renders article, share section, comments, and related articles in one vertical column.
- News share buttons use the canonical slug URL and Copy Link shows immediate feedback.
- Public comments display approved comments only; submitted comments remain pending until moderation.
- Admin mobile sidebar stays fixed to the viewport, locks body scroll while open, closes on Escape/overlay, and is not affected by page scrolling.
- Team Member and Prestasi modals render through the global modal root before `</body>` and remain fixed in the viewport after scrolling.
- Team Member, Prestasi, and admin confirmation modals move focus into the dialog, trap focus, close on Escape/backdrop/close button, and restore focus to the trigger.

## Prestasi CMS Requirements

- Admin Prestasi includes list, detail, add, edit, delete, publish, archive, search, and filters for category, year, and status.
- Delete actions use custom confirmation modals and POST routes with CSRF, never GET.
- Public Prestasi list/detail reads backend-shaped data first and falls back to dummy data while the PHP backend is unavailable.
- One-time token generation stores only a SHA-256 token hash; the plain token is shown only once after generation.
- Token submit form is rendered only for valid active tokens.
- Successful Prestasi submission saves the draft item, writes a submission log, marks the token used, and invalidates it in the same backend transaction.
- Failed validation must not consume the token if the Prestasi item was not saved.

## Execution Order

1. Add test harness and `GenBIAPI` adapter.
2. Wire public News list/detail to the adapter.
3. Wire comments to approved-only rendering and backend-shaped submission.
4. Keep news detail share and comment sections in a single-column layout.
5. Stabilize P0 UI bugs from `PROBLEMS.md` and `another-PROBLEM.md`: mobile admin sidebar, news filter dropdown, Team Member modal, and Prestasi modal.
6. Wire Prestasi public list/detail and admin list/detail/add/edit flows.
7. Wire Prestasi one-time token generation, history, validation, submission, and invalidation flows.
8. Prepare SEO handoff for PHP-rendered meta tags from `CONFIGS.md` and `NEWS-SHARE.md`.

## Testing Policy

- Use Node's built-in test runner for utility and adapter behavior.
- Every tracked implementation task must have a passing unit test before its checkbox is marked complete in `docs/PROJECT_PROGRESS.md`.
- Static browser smoke testing remains required for visual behavior, but unit tests are the gate for progress tracking.
