# Prestasi Backend Foundation + Critical Fixes Implementation Plan

> **For agentic workers:** Use executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix broken test/asset paths caused by `assets/` -> `public/assets/` relocation, add PHP Prestasi model + routes + admin CRUD endpoints, and add Prestasi token system foundation — completing all P2 items from the progress tracker.

**Architecture:** Pure PHP 8.2+ MVC with custom Router, PDO models, JSON content negotiation for frontend adapter. Frontend uses `GenBIAPI` adapter that tries backend first, falls back to static dummy data. Tests run via `node --test` (JS) and standalone PHP assert scripts.

**Tech Stack:** PHP 8.4, Node.js built-in test runner, vanilla JS (UMD/CommonJS-compatible), Tailwind CSS (compiled output only).

---

## Critical Context

The `assets/` directory was relocated to `public/assets/`. This broke:
1. `tests/api-core.test.js` — requires `../assets/js/api-core.js` (now at `../public/assets/js/api-core.js`)
2. `tools/static-server.js` — requires `../assets/js/api-core.js`
3. `tailwind.config.js` — scans `./assets/js/**/*.js` (should be `./public/assets/js/**/*.js`)
4. `public/index.php` asset bridge — looks for `$root . '/assets'` which no longer exists (assets are now directly in `public/assets/`, served natively by PHP built-in server)
5. HTML files use relative `assets/...` paths — these work when served from PHP (browser resolves to `/assets/...` which maps to `public/assets/...`) but NOT when opened as `file://`

The PHP asset bridge in `public/index.php` is now dead code since assets live directly in `public/assets/` and the PHP built-in server serves them natively. However, we should keep a simplified version for Apache/cPanel compatibility where the rewrite sends everything through `index.php`.

---

## File Structure

### Files to Modify
- `tests/api-core.test.js` — fix require path
- `tools/static-server.js` — fix require path
- `tailwind.config.js` — fix content scan path
- `public/index.php` — update asset bridge to use `public/assets/` (or `__DIR__ . '/assets/'`)
- `bootstrap/app.php` — add Prestasi model and controllers
- `routes/web.php` — add Prestasi public routes
- `routes/admin.php` — add Prestasi admin routes

### Files to Create
- `app/Models/Prestasi.php` — tbl_prestasi model
- `app/Models/PrestasiToken.php` — tbl_prestasi_submission_token model
- `app/Controllers/Public/PrestasiController.php` — public list/detail/token-submit
- `app/Controllers/Admin/PrestasiController.php` — admin CRUD JSON endpoints
- `app/Controllers/Admin/PrestasiTokenController.php` — admin token generation/list
- `tests/php/PrestasiModelTest.php` — PHP model mapping test

### Files to Test
- `tests/api-core.test.js` (17 existing tests must pass after path fix)
- `tests/php/PrestasiModelTest.php` (new)
- All existing PHP tests must still pass

---

## Task 1: Fix Broken Test and Tool Paths

**Files:**
- Modify: `tests/api-core.test.js:4-5`
- Modify: `tools/static-server.js:6`

- [ ] **Step 1: Fix test require paths**

In `tests/api-core.test.js`, change lines 4-5 from:
```js
const Core = require('../assets/js/api-core.js');
const UI = require('../assets/js/lib/ui.js');
```
to:
```js
const Core = require('../public/assets/js/api-core.js');
const UI = require('../public/assets/js/lib/ui.js');
```

- [ ] **Step 2: Fix static-server require path**

In `tools/static-server.js`, change line 6 from:
```js
const Core = require('../assets/js/api-core.js');
```
to:
```js
const Core = require('../public/assets/js/api-core.js');
```

- [ ] **Step 3: Run tests to verify fix**

Run: `npm test`
Expected: 17 tests passing, 0 failures.

- [ ] **Step 4: Verify static server starts**

Run: `node -e "require('./tools/static-server.js')" &` then kill it.
Expected: No module-not-found error.

---

## Task 2: Fix Tailwind Config Content Path

**Files:**
- Modify: `tailwind.config.js:2`

- [ ] **Step 1: Update content scan path**

Change line 2 from:
```js
content: ['./*.html', './admin/**/*.html', './assets/js/**/*.js'],
```
to:
```js
content: ['./*.html', './admin/**/*.html', './public/assets/js/**/*.js'],
```

- [ ] **Step 2: Verify config is valid**

Run: `node -e "require('./tailwind.config.js')"`
Expected: No error.

---

## Task 3: Fix PHP Asset Bridge

**Files:**
- Modify: `public/index.php:6-31`

- [ ] **Step 1: Update asset bridge to use `__DIR__` (public directory)**

The assets now live at `public/assets/`. The PHP built-in server serves them directly, but Apache with `.htaccess` rewrite sends ALL requests through `index.php`. Update the bridge to resolve from `__DIR__` (which is `public/`):

Replace lines 6-31 with:
```php
if (str_starts_with($path, '/assets/')) {
    $assetPath = realpath(__DIR__ . $path);
    $assetRoot = realpath(__DIR__ . '/assets');

    if ($assetPath !== false && $assetRoot !== false && str_starts_with($assetPath, $assetRoot) && is_file($assetPath)) {
        $types = [
            'css' => 'text/css; charset=UTF-8',
            'gif' => 'image/gif',
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'js' => 'text/javascript; charset=UTF-8',
            'png' => 'image/png',
            'svg' => 'image/svg+xml',
            'webp' => 'image/webp',
        ];
        $extension = strtolower(pathinfo($assetPath, PATHINFO_EXTENSION));
        header('Content-Type: ' . ($types[$extension] ?? 'application/octet-stream'));
        header('Cache-Control: public, max-age=3600');
        readfile($assetPath);
        return;
    }

    http_response_code(404);
    echo 'Asset not found';
    return;
}
```

- [ ] **Step 2: Verify PHP lint**

Run: `php -l public/index.php`
Expected: No syntax errors.

- [ ] **Step 3: Smoke test assets via PHP server**

Run PHP server and curl assets:
```bash
php -S 127.0.0.1:8097 -t public public/index.php &
curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:8097/assets/css/tailwind.css
curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:8097/assets/js/api-core.js
```
Expected: Both return `200`.

---

## Task 4: Add PHP Prestasi Model

**Files:**
- Create: `app/Models/Prestasi.php`
- Create: `tests/php/PrestasiModelTest.php`

- [ ] **Step 1: Create Prestasi model**

Create `app/Models/Prestasi.php`:
```php
<?php

declare(strict_types=1);

namespace App\Models;

class Prestasi
{
    public function __construct(private ?\PDO $db = null) {}

    public static function mapRow(array $row): array
    {
        return [
            'id' => (int) ($row['prestasi_id'] ?? $row['id'] ?? 0),
            'prestasi_id' => (int) ($row['prestasi_id'] ?? $row['id'] ?? 0),
            'slug' => $row['slug'] ?? '',
            'title' => $row['judul_prestasi'] ?? $row['title'] ?? '',
            'name' => $row['nama_anggota'] ?? $row['name'] ?? '',
            'campus' => $row['komisariat'] ?? $row['campus'] ?? '',
            'category' => $row['kategori'] ?? $row['category'] ?? '',
            'year' => $row['tahun'] ?? $row['year'] ?? '',
            'description' => $row['deskripsi_singkat'] ?? $row['description'] ?? '',
            'content' => $row['deskripsi_lengkap'] ?? $row['content'] ?? '',
            'image' => $row['foto'] ?? $row['image'] ?? '',
            'institution' => $row['institusi_penyelenggara'] ?? $row['institution'] ?? '',
            'status' => $row['status'] ?? 'published',
            'created_at' => $row['created_at'] ?? '',
            'updated_at' => $row['updated_at'] ?? '',
        ];
    }

    public function published(int $limit = 20, int $offset = 0): array
    {
        if (!$this->db) {
            return [];
        }

        $stmt = $this->db->prepare(
            'SELECT * FROM tbl_prestasi WHERE status = :status AND deleted_at IS NULL ORDER BY tahun DESC, created_at DESC LIMIT :limit OFFSET :offset'
        );
        $stmt->bindValue(':status', 'published', \PDO::PARAM_STR);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $stmt->execute();

        return array_map([self::class, 'mapRow'], $stmt->fetchAll(\PDO::FETCH_ASSOC));
    }

    public function findBySlug(string $slug): ?array
    {
        if (!$this->db) {
            return null;
        }

        $stmt = $this->db->prepare(
            'SELECT * FROM tbl_prestasi WHERE slug = :slug AND status = :status AND deleted_at IS NULL LIMIT 1'
        );
        $stmt->bindValue(':slug', $slug, \PDO::PARAM_STR);
        $stmt->bindValue(':status', 'published', \PDO::PARAM_STR);
        $stmt->execute();

        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ? self::mapRow($row) : null;
    }

    public function findById(int $id): ?array
    {
        if (!$this->db) {
            return null;
        }

        $stmt = $this->db->prepare(
            'SELECT * FROM tbl_prestasi WHERE prestasi_id = :id AND deleted_at IS NULL LIMIT 1'
        );
        $stmt->bindValue(':id', $id, \PDO::PARAM_INT);
        $stmt->execute();

        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ? self::mapRow($row) : null;
    }

    public function all(int $limit = 50, int $offset = 0): array
    {
        if (!$this->db) {
            return [];
        }

        $stmt = $this->db->prepare(
            'SELECT * FROM tbl_prestasi WHERE deleted_at IS NULL ORDER BY created_at DESC LIMIT :limit OFFSET :offset'
        );
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $stmt->execute();

        return array_map([self::class, 'mapRow'], $stmt->fetchAll(\PDO::FETCH_ASSOC));
    }

    public function create(array $data): int
    {
        if (!$this->db) {
            return 0;
        }

        $stmt = $this->db->prepare(
            'INSERT INTO tbl_prestasi (judul_prestasi, slug, nama_anggota, komisariat, kategori, tahun, deskripsi_singkat, deskripsi_lengkap, foto, institusi_penyelenggara, status, created_at) VALUES (:title, :slug, :name, :campus, :category, :year, :description, :content, :image, :institution, :status, NOW())'
        );
        $stmt->execute([
            ':title' => $data['title'] ?? '',
            ':slug' => $data['slug'] ?? '',
            ':name' => $data['name'] ?? '',
            ':campus' => $data['campus'] ?? '',
            ':category' => $data['category'] ?? '',
            ':year' => $data['year'] ?? '',
            ':description' => $data['description'] ?? '',
            ':content' => $data['content'] ?? '',
            ':image' => $data['image'] ?? '',
            ':institution' => $data['institution'] ?? '',
            ':status' => $data['status'] ?? 'draft',
        ]);

        return (int) $this->db->lastInsertId();
    }

    public function update(int $id, array $data): bool
    {
        if (!$this->db) {
            return false;
        }

        $fields = [];
        $params = [':id' => $id];
        $allowed = ['judul_prestasi', 'slug', 'nama_anggota', 'komisariat', 'kategori', 'tahun', 'deskripsi_singkat', 'deskripsi_lengkap', 'foto', 'institusi_penyelenggara', 'status'];
        $map = [
            'title' => 'judul_prestasi',
            'slug' => 'slug',
            'name' => 'nama_anggota',
            'campus' => 'komisariat',
            'category' => 'kategori',
            'year' => 'tahun',
            'description' => 'deskripsi_singkat',
            'content' => 'deskripsi_lengkap',
            'image' => 'foto',
            'institution' => 'institusi_penyelenggara',
            'status' => 'status',
        ];

        foreach ($map as $key => $column) {
            if (array_key_exists($key, $data)) {
                $fields[] = "$column = :$key";
                $params[":$key"] = $data[$key];
            }
        }

        if (empty($fields)) {
            return false;
        }

        $fields[] = 'updated_at = NOW()';
        $sql = 'UPDATE tbl_prestasi SET ' . implode(', ', $fields) . ' WHERE prestasi_id = :id AND deleted_at IS NULL';
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($params);
    }

    public function softDelete(int $id): bool
    {
        if (!$this->db) {
            return false;
        }

        $stmt = $this->db->prepare('UPDATE tbl_prestasi SET deleted_at = NOW() WHERE prestasi_id = :id AND deleted_at IS NULL');
        $stmt->bindValue(':id', $id, \PDO::PARAM_INT);
        return $stmt->execute();
    }
}
```

- [ ] **Step 2: Create Prestasi model test**

Create `tests/php/PrestasiModelTest.php`:
```php
<?php

declare(strict_types=1);

use App\Models\Prestasi;

require dirname(__DIR__, 2) . '/bootstrap/app.php';

$row = Prestasi::mapRow([
    'prestasi_id' => 5,
    'slug' => 'juara-kti-nasional-5',
    'judul_prestasi' => 'Juara KTI Nasional',
    'nama_anggota' => 'Amalia',
    'komisariat' => 'Universitas Jambi',
    'kategori' => 'Karya Tulis Ilmiah',
    'tahun' => '2026',
    'deskripsi_singkat' => 'Ringkasan prestasi',
    'deskripsi_lengkap' => 'Deskripsi lengkap prestasi.',
    'foto' => '/uploads/prestasi/kti.jpg',
    'institusi_penyelenggara' => 'Kemendikbud',
    'status' => 'published',
    'created_at' => '2026-05-06 10:00:00',
    'updated_at' => '2026-05-06 12:00:00',
]);

assert($row['id'] === 5);
assert($row['prestasi_id'] === 5);
assert($row['slug'] === 'juara-kti-nasional-5');
assert($row['title'] === 'Juara KTI Nasional');
assert($row['name'] === 'Amalia');
assert($row['campus'] === 'Universitas Jambi');
assert($row['category'] === 'Karya Tulis Ilmiah');
assert($row['year'] === '2026');
assert($row['description'] === 'Ringkasan prestasi');
assert($row['content'] === 'Deskripsi lengkap prestasi.');
assert($row['image'] === '/uploads/prestasi/kti.jpg');
assert($row['institution'] === 'Kemendikbud');
assert($row['status'] === 'published');

// Test with minimal/alternative field names
$row2 = Prestasi::mapRow([
    'id' => 10,
    'title' => 'Juara Debat',
    'name' => 'Budi',
    'campus' => 'UIN STS Jambi',
    'category' => 'Debat',
    'year' => '2025',
]);

assert($row2['id'] === 10);
assert($row2['title'] === 'Juara Debat');
assert($row2['name'] === 'Budi');
assert($row2['campus'] === 'UIN STS Jambi');

echo "PHP prestasi model tests passed\n";
```

- [ ] **Step 3: Run Prestasi model test**

Run: `php -d zend.assertions=1 -d assert.exception=1 tests/php/PrestasiModelTest.php`
Expected: `PHP prestasi model tests passed`

---

## Task 5: Add PHP Prestasi Token Model

**Files:**
- Create: `app/Models/PrestasiToken.php`

- [ ] **Step 1: Create PrestasiToken model**

Create `app/Models/PrestasiToken.php`:
```php
<?php

declare(strict_types=1);

namespace App\Models;

class PrestasiToken
{
    public function __construct(private ?\PDO $db = null) {}

    public static function mapRow(array $row): array
    {
        return [
            'id' => (int) ($row['token_id'] ?? $row['id'] ?? 0),
            'token_id' => (int) ($row['token_id'] ?? $row['id'] ?? 0),
            'token_hash' => $row['token_hash'] ?? '',
            'label' => $row['label'] ?? $row['keterangan'] ?? '',
            'status' => $row['status'] ?? 'active',
            'created_by' => (int) ($row['created_by'] ?? 0),
            'used_at' => $row['used_at'] ?? null,
            'expires_at' => $row['expires_at'] ?? null,
            'created_at' => $row['created_at'] ?? '',
        ];
    }

    public function generate(string $label, int $createdBy, ?string $expiresAt = null): ?string
    {
        if (!$this->db) {
            return null;
        }

        $plainToken = bin2hex(random_bytes(32));
        $hash = hash('sha256', $plainToken);

        $stmt = $this->db->prepare(
            'INSERT INTO tbl_prestasi_submission_token (token_hash, label, status, created_by, expires_at, created_at) VALUES (:hash, :label, :status, :created_by, :expires_at, NOW())'
        );
        $stmt->execute([
            ':hash' => $hash,
            ':label' => $label,
            ':status' => 'active',
            ':created_by' => $createdBy,
            ':expires_at' => $expiresAt,
        ]);

        return $plainToken;
    }

    public function validateToken(string $plainToken): ?array
    {
        if (!$this->db) {
            return null;
        }

        $hash = hash('sha256', $plainToken);
        $stmt = $this->db->prepare(
            'SELECT * FROM tbl_prestasi_submission_token WHERE token_hash = :hash AND status = :status AND (expires_at IS NULL OR expires_at > NOW()) LIMIT 1'
        );
        $stmt->bindValue(':hash', $hash, \PDO::PARAM_STR);
        $stmt->bindValue(':status', 'active', \PDO::PARAM_STR);
        $stmt->execute();

        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ? self::mapRow($row) : null;
    }

    public function markUsed(int $tokenId): bool
    {
        if (!$this->db) {
            return false;
        }

        $stmt = $this->db->prepare(
            'UPDATE tbl_prestasi_submission_token SET status = :status, used_at = NOW() WHERE token_id = :id AND status = :active'
        );
        return $stmt->execute([
            ':status' => 'used',
            ':id' => $tokenId,
            ':active' => 'active',
        ]);
    }

    public function revoke(int $tokenId): bool
    {
        if (!$this->db) {
            return false;
        }

        $stmt = $this->db->prepare(
            'UPDATE tbl_prestasi_submission_token SET status = :status WHERE token_id = :id AND status = :active'
        );
        return $stmt->execute([
            ':status' => 'revoked',
            ':id' => $tokenId,
            ':active' => 'active',
        ]);
    }

    public function all(int $limit = 50, int $offset = 0): array
    {
        if (!$this->db) {
            return [];
        }

        $stmt = $this->db->prepare(
            'SELECT * FROM tbl_prestasi_submission_token ORDER BY created_at DESC LIMIT :limit OFFSET :offset'
        );
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $stmt->execute();

        return array_map([self::class, 'mapRow'], $stmt->fetchAll(\PDO::FETCH_ASSOC));
    }
}
```

- [ ] **Step 2: Verify PHP lint**

Run: `php -l app/Models/PrestasiToken.php`
Expected: No syntax errors.

---

## Task 6: Add Prestasi Public Controller

**Files:**
- Create: `app/Controllers/Public/PrestasiController.php`

- [ ] **Step 1: Create public Prestasi controller**

Create `app/Controllers/Public/PrestasiController.php`:
```php
<?php

declare(strict_types=1);

namespace App\Controllers\Public;

use App\Core\Request;
use App\Core\Response;
use App\Core\StaticPageRenderer;
use App\Models\Prestasi;
use App\Models\PrestasiToken;

class PrestasiController
{
    public function __construct(
        private StaticPageRenderer $renderer,
        private ?Prestasi $prestasi = null,
        private ?PrestasiToken $tokenModel = null,
    ) {}

    public function index(Request $request, Response $response): void
    {
        if ($request->acceptsJson()) {
            $page = max(1, (int) ($request->query('page') ?? 1));
            $limit = 20;
            $offset = ($page - 1) * $limit;
            $items = $this->prestasi?->published($limit, $offset) ?? [];
            $response->json(['data' => $items, 'page' => $page]);
            return;
        }

        $this->renderer->render($response, 'prestasi.html');
    }

    public function show(Request $request, Response $response, array $params): void
    {
        $slug = $params['slug'] ?? '';

        if ($request->acceptsJson()) {
            $item = $this->prestasi?->findBySlug($slug);
            if (!$item) {
                $response->json(['error' => 'Not found'], 404);
                return;
            }
            $response->json(['data' => $item]);
            return;
        }

        $this->renderer->render($response, 'prestasi.html');
    }

    public function submissionForm(Request $request, Response $response, array $params): void
    {
        $token = $params['token'] ?? '';

        if ($request->acceptsJson()) {
            $valid = $this->tokenModel?->validateToken($token);
            if (!$valid) {
                $response->json(['error' => 'Token tidak valid atau sudah digunakan'], 403);
                return;
            }
            $response->json(['data' => ['valid' => true, 'label' => $valid['label']]]);
            return;
        }

        // For HTML, render a submission form page (static fallback for now)
        $this->renderer->render($response, 'prestasi.html');
    }

    public function submitWithToken(Request $request, Response $response, array $params): void
    {
        $token = $params['token'] ?? '';
        $valid = $this->tokenModel?->validateToken($token);

        if (!$valid) {
            $response->json(['error' => 'Token tidak valid atau sudah digunakan'], 403);
            return;
        }

        $body = $request->json();
        $errors = $this->validateSubmission($body);
        if (!empty($errors)) {
            $response->json(['error' => 'Validasi gagal', 'details' => $errors], 422);
            return;
        }

        $slug = $this->generateSlug($body['title'] ?? 'prestasi');

        $id = $this->prestasi?->create([
            'title' => trim($body['title'] ?? ''),
            'slug' => $slug,
            'name' => trim($body['name'] ?? ''),
            'campus' => trim($body['campus'] ?? ''),
            'category' => trim($body['category'] ?? ''),
            'year' => trim($body['year'] ?? ''),
            'description' => trim($body['description'] ?? ''),
            'content' => trim($body['content'] ?? ''),
            'institution' => trim($body['institution'] ?? ''),
            'status' => 'pending',
        ]);

        if ($id) {
            $this->tokenModel?->markUsed($valid['id']);
            $response->json(['data' => ['id' => $id, 'status' => 'pending']], 201);
        } else {
            $response->json(['error' => 'Gagal menyimpan data'], 500);
        }
    }

    private function validateSubmission(array $body): array
    {
        $errors = [];
        if (empty(trim($body['title'] ?? ''))) {
            $errors[] = 'Judul prestasi wajib diisi';
        }
        if (empty(trim($body['name'] ?? ''))) {
            $errors[] = 'Nama anggota wajib diisi';
        }
        if (empty(trim($body['campus'] ?? ''))) {
            $errors[] = 'Komisariat wajib diisi';
        }
        if (empty(trim($body['category'] ?? ''))) {
            $errors[] = 'Kategori wajib diisi';
        }
        if (empty(trim($body['year'] ?? ''))) {
            $errors[] = 'Tahun wajib diisi';
        }
        return $errors;
    }

    private function generateSlug(string $title): string
    {
        $slug = mb_strtolower($title);
        $slug = preg_replace('/[^a-z0-9\s-]/', '', $slug) ?? '';
        $slug = preg_replace('/[\s-]+/', '-', $slug) ?? '';
        return trim($slug, '-') ?: 'prestasi';
    }
}
```

- [ ] **Step 2: Verify PHP lint**

Run: `php -l app/Controllers/Public/PrestasiController.php`
Expected: No syntax errors.

---

## Task 7: Add Prestasi Admin Controller

**Files:**
- Create: `app/Controllers/Admin/PrestasiController.php`
- Create: `app/Controllers/Admin/PrestasiTokenController.php`

- [ ] **Step 1: Create admin Prestasi controller**

Create `app/Controllers/Admin/PrestasiController.php`:
```php
<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Request;
use App\Core\Response;
use App\Models\Prestasi;

class PrestasiController
{
    public function __construct(private ?Prestasi $prestasi = null) {}

    public function index(Request $request, Response $response): void
    {
        $page = max(1, (int) ($request->query('page') ?? 1));
        $limit = 50;
        $offset = ($page - 1) * $limit;
        $items = $this->prestasi?->all($limit, $offset) ?? [];
        $response->json(['data' => $items, 'page' => $page]);
    }

    public function show(Request $request, Response $response, array $params): void
    {
        $id = (int) ($params['id'] ?? 0);
        $item = $this->prestasi?->findById($id);

        if (!$item) {
            $response->json(['error' => 'Not found'], 404);
            return;
        }

        $response->json(['data' => $item]);
    }

    public function store(Request $request, Response $response): void
    {
        $body = $request->json();
        $errors = $this->validate($body);

        if (!empty($errors)) {
            $response->json(['error' => 'Validasi gagal', 'details' => $errors], 422);
            return;
        }

        $slug = $this->generateSlug($body['title'] ?? 'prestasi');

        $id = $this->prestasi?->create([
            'title' => trim($body['title'] ?? ''),
            'slug' => $slug,
            'name' => trim($body['name'] ?? ''),
            'campus' => trim($body['campus'] ?? ''),
            'category' => trim($body['category'] ?? ''),
            'year' => trim($body['year'] ?? ''),
            'description' => trim($body['description'] ?? ''),
            'content' => trim($body['content'] ?? ''),
            'image' => trim($body['image'] ?? ''),
            'institution' => trim($body['institution'] ?? ''),
            'status' => $body['status'] ?? 'draft',
        ]);

        if ($id) {
            $response->json(['data' => ['id' => $id]], 201);
        } else {
            $response->json(['error' => 'Gagal menyimpan'], 500);
        }
    }

    public function update(Request $request, Response $response, array $params): void
    {
        $id = (int) ($params['id'] ?? 0);
        $body = $request->json();

        $success = $this->prestasi?->update($id, $body);

        if ($success) {
            $response->json(['data' => ['id' => $id, 'updated' => true]]);
        } else {
            $response->json(['error' => 'Gagal memperbarui atau data tidak ditemukan'], 404);
        }
    }

    public function delete(Request $request, Response $response, array $params): void
    {
        $id = (int) ($params['id'] ?? 0);
        $success = $this->prestasi?->softDelete($id);

        if ($success) {
            $response->json(['data' => ['id' => $id, 'deleted' => true]]);
        } else {
            $response->json(['error' => 'Gagal menghapus atau data tidak ditemukan'], 404);
        }
    }

    private function validate(array $body): array
    {
        $errors = [];
        if (empty(trim($body['title'] ?? ''))) {
            $errors[] = 'Judul prestasi wajib diisi';
        }
        if (empty(trim($body['name'] ?? ''))) {
            $errors[] = 'Nama anggota wajib diisi';
        }
        if (empty(trim($body['campus'] ?? ''))) {
            $errors[] = 'Komisariat wajib diisi';
        }
        return $errors;
    }

    private function generateSlug(string $title): string
    {
        $slug = mb_strtolower($title);
        $slug = preg_replace('/[^a-z0-9\s-]/', '', $slug) ?? '';
        $slug = preg_replace('/[\s-]+/', '-', $slug) ?? '';
        return trim($slug, '-') ?: 'prestasi';
    }
}
```

- [ ] **Step 2: Create admin PrestasiToken controller**

Create `app/Controllers/Admin/PrestasiTokenController.php`:
```php
<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Request;
use App\Core\Response;
use App\Models\PrestasiToken;

class PrestasiTokenController
{
    public function __construct(private ?PrestasiToken $tokenModel = null) {}

    public function index(Request $request, Response $response): void
    {
        $items = $this->tokenModel?->all() ?? [];
        $response->json(['data' => $items]);
    }

    public function generate(Request $request, Response $response): void
    {
        $body = $request->json();
        $label = trim($body['label'] ?? '');
        $expiresAt = $body['expires_at'] ?? null;

        if (empty($label)) {
            $response->json(['error' => 'Label/keterangan wajib diisi'], 422);
            return;
        }

        // TODO: get actual admin user ID from session when auth is implemented
        $createdBy = 1;

        $plainToken = $this->tokenModel?->generate($label, $createdBy, $expiresAt);

        if ($plainToken) {
            $response->json(['data' => ['token' => $plainToken, 'label' => $label]], 201);
        } else {
            $response->json(['error' => 'Gagal membuat token'], 500);
        }
    }

    public function revoke(Request $request, Response $response, array $params): void
    {
        $id = (int) ($params['id'] ?? 0);
        $success = $this->tokenModel?->revoke($id);

        if ($success) {
            $response->json(['data' => ['id' => $id, 'revoked' => true]]);
        } else {
            $response->json(['error' => 'Gagal merevoke token atau token tidak aktif'], 404);
        }
    }
}
```

- [ ] **Step 3: Verify PHP lint for both controllers**

Run: `php -l app/Controllers/Admin/PrestasiController.php && php -l app/Controllers/Admin/PrestasiTokenController.php`
Expected: No syntax errors.

---

## Task 8: Wire Routes and Bootstrap

**Files:**
- Modify: `bootstrap/app.php`
- Modify: `routes/web.php`
- Modify: `routes/admin.php`

- [ ] **Step 1: Update bootstrap/app.php**

Add use statements and instantiate models/controllers:

After existing use statements, add:
```php
use App\Controllers\Admin\PrestasiController as AdminPrestasiController;
use App\Controllers\Admin\PrestasiTokenController;
use App\Controllers\Public\PrestasiController;
use App\Models\Prestasi;
use App\Models\PrestasiToken;
```

After existing model instantiation in try block, add:
```php
$prestasiModel = new Prestasi($db);
$tokenModel = new PrestasiToken($db);
```

After existing controller instantiation, add:
```php
$prestasiController = new PrestasiController($renderer, $prestasiModel, $tokenModel);
$adminPrestasiController = new AdminPrestasiController($prestasiModel);
$adminPrestasiTokenController = new PrestasiTokenController($tokenModel);
```

Also add `$prestasiModel = null;` and `$tokenModel = null;` before the try block.

- [ ] **Step 2: Add public Prestasi routes to routes/web.php**

Add before the existing `/prestasi` static route (replace it):
```php
$router->get('/prestasi', static fn (Request $request, Response $response) => $prestasiController->index($request, $response));
$router->get('/prestasi/submit/{token}', static fn (Request $request, Response $response, array $params) => $prestasiController->submissionForm($request, $response, $params));
$router->post('/prestasi/submit/{token}', static fn (Request $request, Response $response, array $params) => $prestasiController->submitWithToken($request, $response, $params));
$router->get('/prestasi/{slug}', static fn (Request $request, Response $response, array $params) => $prestasiController->show($request, $response, $params));
```

- [ ] **Step 3: Add admin Prestasi routes to routes/admin.php**

Add before the catch-all `admin/{page}` route:
```php
$router->get('/admin/prestasi', static fn (Request $request, Response $response) => $adminPrestasiController->index($request, $response));
$router->post('/admin/prestasi', static fn (Request $request, Response $response) => $adminPrestasiController->store($request, $response));
$router->get('/admin/prestasi/{id}', static fn (Request $request, Response $response, array $params) => $adminPrestasiController->show($request, $response, $params));
$router->post('/admin/prestasi/{id}/update', static fn (Request $request, Response $response, array $params) => $adminPrestasiController->update($request, $response, $params));
$router->post('/admin/prestasi/{id}/delete', static fn (Request $request, Response $response, array $params) => $adminPrestasiController->delete($request, $response, $params));
$router->get('/admin/prestasi-tokens', static fn (Request $request, Response $response) => $adminPrestasiTokenController->index($request, $response));
$router->post('/admin/prestasi-tokens', static fn (Request $request, Response $response) => $adminPrestasiTokenController->generate($request, $response));
$router->post('/admin/prestasi-tokens/{id}/revoke', static fn (Request $request, Response $response, array $params) => $adminPrestasiTokenController->revoke($request, $response, $params));
```

- [ ] **Step 4: Verify PHP lint on all modified files**

Run: `php -l bootstrap/app.php && php -l routes/web.php && php -l routes/admin.php`
Expected: No syntax errors.

---

## Task 9: Full Verification

- [ ] **Step 1: Run all PHP tests**

Run:
```bash
php -d zend.assertions=1 -d assert.exception=1 tests/php/FoundationTest.php
php -d zend.assertions=1 -d assert.exception=1 tests/php/MigrationRunnerTest.php
php -d zend.assertions=1 -d assert.exception=1 tests/php/NewsModelTest.php
php -d zend.assertions=1 -d assert.exception=1 tests/php/NewsCommentModelTest.php
php -d zend.assertions=1 -d assert.exception=1 tests/php/PrestasiModelTest.php
```
Expected: All pass.

- [ ] **Step 2: Run JS tests**

Run: `npm test`
Expected: 17 tests passing, 0 failures.

- [ ] **Step 3: Smoke test PHP routes**

Start PHP server and test:
```bash
php -S 127.0.0.1:8098 -t public public/index.php &
# Assets
curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:8098/assets/css/tailwind.css  # 200
curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:8098/assets/js/api-core.js    # 200
# Prestasi public
curl -s -o /dev/null -w '%{http_code}' -H 'Accept: application/json' http://127.0.0.1:8098/prestasi  # 200
curl -s -o /dev/null -w '%{http_code}' -H 'Accept: application/json' http://127.0.0.1:8098/prestasi/test-slug  # 404 (no DB)
# Prestasi admin
curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:8098/admin/prestasi  # 200
curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:8098/admin/prestasi-tokens  # 200
# Token validation
curl -s -o /dev/null -w '%{http_code}' -H 'Accept: application/json' http://127.0.0.1:8098/prestasi/submit/abc123  # 403
```
Expected: Status codes as noted.

- [ ] **Step 4: Update docs/PROJECT_PROGRESS.md**

Mark P2 Prestasi items as complete. Add test log entries.

- [ ] **Step 5: Create report**

Create `docs/report/2026-05-06-prestasi-foundation-and-path-fixes.md`.

- [ ] **Step 6: Notify user**

Run: `wp --contact 62895703051945 --message "..."`

---

## Execution Order Summary

1. Task 1: Fix JS test/tool paths (unblocks `npm test`)
2. Task 2: Fix Tailwind config (unblocks `npm run build:css` when deps work)
3. Task 3: Fix PHP asset bridge (correctness for Apache/cPanel)
4. Task 4: Add Prestasi model + test
5. Task 5: Add PrestasiToken model
6. Task 6: Add public Prestasi controller
7. Task 7: Add admin Prestasi + Token controllers
8. Task 8: Wire routes and bootstrap
9. Task 9: Full verification, docs, and notification
