# SSR Migration Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Move the PHP MVC app from static HTML shells plus client-side rendering to server-side PHP views that render real database content directly.

**Architecture:** Add a small PHP view renderer alongside the current `StaticPageRenderer`, then migrate routes one slice at a time. Public read pages should render HTML from controllers/models, while JavaScript remains only for progressive behavior such as filters, modals, Editor.js, uploads, and form submits.

**Tech Stack:** PHP 8.2+ custom MVC, PDO models, PHP templates in `app/Views`, vanilla JavaScript, Editor.js, Tailwind compiled CSS, existing Node/PHP tests.

**Current Condition, 2026-05-07:** The app is no longer only a static prototype. PHP MVC routes, auth, CSRF middleware, public News/Event/Team/Prestasi controllers, admin News/Prestasi JSON endpoints, and several migrations already exist. Static HTML shells still render many pages, but admin News and Prestasi now depend on database-backed JSON APIs plus progressive JavaScript. The SSR migration must preserve this working state instead of restarting from the original static-only baseline.

---

## Migration Principles

- Keep routes and URLs unchanged: `/news`, `/news/{slug}`, `/team`, `/event`, `/prestasi`, `/admin/news`, `/admin/news-add`, `/admin/news-edit?id=...`.
- Do not delete static HTML immediately; keep it as fallback until a route is fully SSR and tested.
- Do not hard-code database credentials or secrets.
- Keep API JSON behavior intact for existing JS consumers by preserving `Accept: application/json` branches.
- Prefer small view helpers over a template engine; no Laravel, CodeIgniter, Twig, Blade, or heavy framework.
- Commit every completed phase after verification passes.
- Before rendering database content server-side, audit the real schema against `BLUEPRINTS.md`, `PROBLEMS.md`, and the current News/Prestasi implementation. Add forward-only migrations for missing or incompatible columns instead of changing application code to fit an outdated table shape.
- Treat `tbl_news` and `tbl_prestasi` as source-of-truth content tables for this phase. Do not switch back to the modern `news`, `teams`, or other unused prototype tables unless a separate migration decision is documented.

## File Structure

- Create `app/Core/ViewRenderer.php`: safe PHP view renderer with shared escaping helpers.
- Create `app/Views/layouts/public.php`: public HTML document shell.
- Create `app/Views/layouts/admin.php`: admin HTML document shell with CSRF meta tag and noindex.
- Create `app/Views/partials/public-header.php`: public nav/header partial.
- Create `app/Views/partials/public-footer.php`: public footer partial.
- Create `app/Views/partials/admin-sidebar.php`: admin sidebar partial.
- Create `app/Views/partials/admin-topbar.php`: admin topbar partial.
- Create `app/Views/public/news/index.php`: SSR public news list.
- Create `app/Views/public/news/show.php`: SSR public news detail.
- Create `app/Views/public/prestasi/index.php`: SSR public Prestasi list with list/grid-ready markup.
- Create `app/Views/public/prestasi/show.php` only if Prestasi detail gets a public route in this phase; otherwise keep detail modal progressive.
- Create `app/Views/admin/news/index.php`: SSR admin news list page shell.
- Create `app/Views/admin/news/form.php`: SSR admin news add/edit page shell.
- Create `app/Views/admin/prestasi/index.php`: SSR admin Prestasi list shell.
- Create `app/Views/admin/prestasi/form.php`: SSR admin Prestasi add/edit shell.
- Modify `bootstrap/app.php`: instantiate `ViewRenderer` and pass it to controllers.
- Modify `app/Controllers/Public/NewsController.php`: render PHP views for non-JSON requests.
- Modify `app/Controllers/Public/PrestasiController.php`: render PHP views for non-JSON requests.
- Modify `app/Controllers/Admin/AdminPageController.php`: render SSR admin news pages before falling back to static HTML.
- Modify `app/Controllers/Admin/NewsController.php`: keep JSON API, upload, store, update, delete unchanged except for any data shape needed by SSR forms.
- Modify `app/Controllers/Admin/PrestasiController.php`: keep JSON API, upload, store, update, delete unchanged except for any data shape needed by SSR forms.
- Modify `public/assets/js/admin/cms.js`: reduce admin news page JS to progressive behavior once server renders the shell.
- Modify `public/assets/js/pages/news.js`, `public/assets/js/pages/news-detail.js`, and `public/assets/js/pages/prestasi.js`: disable duplicate rendering when SSR markup already exists.
- Add `tests/php/ViewRendererTest.php`: tests escaping, layout rendering, and missing view behavior.
- Add or extend PHP route smoke tests if available; otherwise document curl smoke checks in each task.

---

### Task 0: Audit News And Prestasi Schema Before SSR

**Files:**
- Inspect: `BLUEPRINTS.md`
- Inspect: `PROBLEMS.md`
- Inspect: `another-PROBLEM.md`
- Inspect: `database/migrations/*.php`
- Inspect: `app/Models/News.php`
- Inspect: `app/Models/Prestasi.php`
- Create if needed: `database/migrations/YYYY_MM_DD_HHMM_align_news_prestasi_schema.php`
- Create or extend if needed: `tests/php/NewsModelTest.php`
- Create or extend if needed: `tests/php/PrestasiModelTest.php`

- [ ] **Step 1: Confirm currently applied migrations**

Use the existing PHP bootstrap/PDO path rather than hard-coded credentials or direct MySQL CLI credentials. Check the migration table or run the existing migration status mechanism if available.

Minimum result to document in the implementation report:

```text
- Applied migration list for News/Prestasi/comment/token tables.
- Whether `tbl_news`, `tbl_news_comment`, `tbl_prestasi`, `tbl_prestasi_submission_token`, and `tbl_prestasi_submission` exist.
- Whether any migration file exists but has not been applied.
```

- [ ] **Step 2: Compare `tbl_news` against the required current shape**

The SSR News pages must read from `tbl_news`, not from the modern `news` table. Confirm these columns/indexes exist and match the current application behavior:

```text
Required `tbl_news` columns:
- news_id
- news_title
- news_content_short
- news_content
- slug
- category_id
- photo
- banner
- comment
- contributor_redaksi
- contributor_pewarta
- contributor_editor
- content_json
- status ENUM/allowed values: draft, published, archived
- published_at
- created_at
- updated_at
- deleted_at

Required `tbl_news` indexes/constraints:
- unique slug index
- category_id index
- news_date or equivalent publish-date index
- status index
- published index when legacy `published` remains in use
```

Current behavior to preserve:

```text
- Public `/news/{slug}` uses slug canonical URLs.
- Legacy ID URLs redirect to slug URLs.
- Public listing/detail exclude draft, archived, and soft-deleted rows.
- Contributor box renders only real `contributor_pewarta` or `contributor_editor`; do not reintroduce fake/default Redaksi values.
- Admin add/edit stores safe article HTML in `tbl_news.news_content`.
- `content_json` may remain optional for Editor.js data, but SSR must not depend on it until it is reliably populated.
- News detail share/canonical uses `/news/{slug}` and absolute Open Graph/Twitter image URLs.
```

- [ ] **Step 3: Compare `tbl_prestasi` against the required current shape**

The SSR Prestasi pages must read from `tbl_prestasi`. Confirm these columns/indexes exist and match the current simplified Prestasi form, not the older category-heavy draft in `PROBLEMS.md`:

```text
Required `tbl_prestasi` columns:
- prestasi_id
- title
- slug
- category
- year
- member_name
- institution
- description
- detail
- photo
- certificate_photo
- status ENUM/allowed values: draft, published, archived
- is_featured
- meta_title
- meta_keyword
- meta_description
- created_by
- updated_by
- created_at
- updated_at
- deleted_at

Required `tbl_prestasi` indexes/constraints:
- unique slug index
- category index
- year index
- status index
- is_featured index
```

Current behavior to preserve:

```text
- Admin add/edit fields are `Nama`, `Penyelengara`, `Tahun`, `Peringkat`, and `Deskripsi Singkat`.
- `Nama` maps to `member_name` and should be searchable from Team data in the UI.
- `Penyelengara` maps to `institution`.
- `Tahun` maps to integer `year`.
- `Peringkat` maps to `category`.
- `Deskripsi Singkat` maps to `description` and may be mirrored to `detail` for compatibility.
- Public `/prestasi` has no tag/category filter, supports list/grid toggle, and shows only published non-deleted rows.
- Google Drive image IDs/URLs and local upload paths must resolve through model/API normalization without breaking SSR image markup.
```

- [ ] **Step 4: Decide whether a migration is required**

Create a forward-only migration if any of these are true:

```text
- A required News/Prestasi column is missing.
- `status` allows unsupported values such as `pending` where the current admin only supports `draft`, `published`, `archived`.
- Slugs are missing, nullable without a backfill plan, or not unique.
- Soft-delete columns are missing while controllers/models expect `deleted_at`.
- Contributor columns are missing from `tbl_news`.
- `tbl_prestasi.photo` or `certificate_photo` is too short for current Google Drive thumbnail/open/download URL storage requirements. Prefer widening to `VARCHAR(255)` or `TEXT` if actual stored values can exceed the existing limit.
- Existing indexes are missing and listing/detail queries would scan the full content table.
```

Do not create a migration just because a legacy column still exists. Keep legacy fields when they are harmless and still used by old data or fallback code.

- [ ] **Step 5: Add safe backfills when needed**

If the audit finds missing data, include idempotent backfills in the migration or a documented one-time script:

```text
- Backfill `tbl_news.slug` from `news_title`, with collision handling.
- Backfill `tbl_news.published_at` from `news_date` or `created_at` when empty.
- Normalize empty contributor placeholders to `NULL`, not default Redaksi text.
- Backfill `tbl_prestasi.slug` from `title`, with collision handling.
- Normalize Prestasi statuses to `draft`, `published`, or `archived`.
- Preserve existing Prestasi member/institution/year/category values without overwriting valid seeded data.
```

- [ ] **Step 6: Verify model compatibility before SSR views**

Run:

```bash
php -l app/Models/News.php
php -l app/Models/Prestasi.php
php -d zend.assertions=1 -d assert.exception=1 tests/php/NewsModelTest.php
php -d zend.assertions=1 -d assert.exception=1 tests/php/PrestasiModelTest.php
```

If a migration was added, also run the migration through the project migration runner in the local environment and document the result. Do not mark SSR tasks complete until schema audit and model tests pass.

---

### Task 1: Add PHP View Renderer Foundation

**Files:**
- Create: `app/Core/ViewRenderer.php`
- Create: `tests/php/ViewRendererTest.php`
- Modify: `bootstrap/app.php`

- [ ] **Step 1: Write the failing renderer test**

Create `tests/php/ViewRendererTest.php` with:

```php
<?php

declare(strict_types=1);

use App\Core\ViewRenderer;

require_once dirname(__DIR__, 2) . '/bootstrap/app.php';

$root = dirname(__DIR__, 2);
$tmpViewDir = sys_get_temp_dir() . '/genbi-view-test-' . bin2hex(random_bytes(4));
mkdir($tmpViewDir . '/layouts', 0777, true);

file_put_contents($tmpViewDir . '/sample.php', '<p><?= $e($title) ?></p>');
file_put_contents($tmpViewDir . '/layouts/base.php', '<main><?= $content ?></main>');

$renderer = new ViewRenderer($tmpViewDir);

$html = $renderer->render('sample.php', ['title' => '<script>alert(1)</script>']);
assert($html === '<p>&lt;script&gt;alert(1)&lt;/script&gt;</p>');

$layoutHtml = $renderer->renderWithLayout('sample.php', 'layouts/base.php', ['title' => 'GenBI']);
assert($layoutHtml === '<main><p>GenBI</p></main>');

$missing = $renderer->render('missing.php');
assert(str_contains($missing, '404'));

array_map('unlink', glob($tmpViewDir . '/layouts/*') ?: []);
rmdir($tmpViewDir . '/layouts');
array_map('unlink', glob($tmpViewDir . '/*') ?: []);
rmdir($tmpViewDir);
```

- [ ] **Step 2: Run test to verify it fails**

Run: `php -d zend.assertions=1 -d assert.exception=1 tests/php/ViewRendererTest.php`

Expected: FAIL because `App\Core\ViewRenderer` does not exist.

- [ ] **Step 3: Implement `ViewRenderer`**

Create `app/Core/ViewRenderer.php`:

```php
<?php

declare(strict_types=1);

namespace App\Core;

use Throwable;

final class ViewRenderer
{
    public function __construct(private string $viewRoot)
    {
    }

    /** @param array<string, mixed> $data */
    public function render(string $view, array $data = []): string
    {
        $file = $this->resolve($view);
        if ($file === null) {
            return '<!doctype html><title>404</title><h1>404 - View tidak ditemukan</h1>';
        }

        $e = static fn (mixed $value): string => htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
        $asset = static fn (string $path): string => '/assets/' . ltrim($path, '/');
        $url = static fn (string $path): string => '/' . ltrim($path, '/');

        try {
            ob_start();
            extract($data, EXTR_SKIP);
            require $file;
            return (string) ob_get_clean();
        } catch (Throwable $throwable) {
            if (ob_get_level() > 0) {
                ob_end_clean();
            }
            throw $throwable;
        }
    }

    /** @param array<string, mixed> $data */
    public function renderWithLayout(string $view, string $layout, array $data = []): string
    {
        $content = $this->render($view, $data);
        return $this->render($layout, array_merge($data, ['content' => $content]));
    }

    private function resolve(string $view): ?string
    {
        $safe = str_replace('..', '', ltrim($view, '/'));
        $file = rtrim($this->viewRoot, '/') . '/' . $safe;
        return is_file($file) ? $file : null;
    }
}
```

- [ ] **Step 4: Wire renderer in bootstrap**

Modify `bootstrap/app.php` near the existing static renderer:

```php
use App\Core\ViewRenderer;
```

Then after `$renderer = new StaticPageRenderer($rootPath);` add:

```php
$viewRenderer = new ViewRenderer($rootPath . '/app/Views');
```

Do not replace any controller constructor yet.

- [ ] **Step 5: Run tests**

Run: `php -d zend.assertions=1 -d assert.exception=1 tests/php/ViewRendererTest.php`

Expected: PASS.

Run: `for f in tests/php/*.php; do php -d zend.assertions=1 -d assert.exception=1 "$f"; done`

Expected: all PHP tests pass.

- [ ] **Step 6: Commit**

Run:

```bash
git add app/Core/ViewRenderer.php bootstrap/app.php tests/php/ViewRendererTest.php
git commit -m "feat: add PHP view renderer foundation"
```

---

### Task 2: Add Shared SSR Layouts And Partials

**Files:**
- Create: `app/Views/layouts/public.php`
- Create: `app/Views/layouts/admin.php`
- Create: `app/Views/partials/public-header.php`
- Create: `app/Views/partials/public-footer.php`
- Create: `app/Views/partials/admin-sidebar.php`
- Create: `app/Views/partials/admin-topbar.php`
- Modify: `tests/php/ViewRendererTest.php`

- [ ] **Step 1: Extend test for layout assets and CSRF**

Append to `tests/php/ViewRendererTest.php` before cleanup:

```php
mkdir($tmpViewDir . '/partials', 0777, true);
file_put_contents($tmpViewDir . '/partials/head.php', '<meta name="csrf-token" content="<?= $e($csrfToken ?? "") ?>">');
file_put_contents($tmpViewDir . '/layouts/admin.php', '<!doctype html><html><head><?php require __DIR__ . "/../partials/head.php"; ?></head><body><?= $content ?></body></html>');

$adminHtml = $renderer->renderWithLayout('sample.php', 'layouts/admin.php', ['title' => 'Admin', 'csrfToken' => 'abc123']);
assert(str_contains($adminHtml, '<meta name="csrf-token" content="abc123">'));
```

Also update cleanup to remove `$tmpViewDir . '/partials/*'` and the `partials` directory.

- [ ] **Step 2: Run test to verify it fails if cleanup is incomplete**

Run: `php -d zend.assertions=1 -d assert.exception=1 tests/php/ViewRendererTest.php`

Expected: PASS after cleanup is adjusted; if cleanup fails, fix cleanup before continuing.

- [ ] **Step 3: Create public layout**

Create `app/Views/layouts/public.php`:

```php
<!doctype html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?= $meta ?? '<title>GenBI Provinsi Jambi</title>' ?>
  <link rel="stylesheet" href="/assets/css/tailwind.css">
  <link rel="stylesheet" href="/assets/css/styles.css">
  <?= $jsonld ?? '' ?>
</head>
<body class="<?= $e($bodyClass ?? '') ?>">
  <?php require __DIR__ . '/../partials/public-header.php'; ?>
  <main id="main-content">
    <?= $content ?>
  </main>
  <?php require __DIR__ . '/../partials/public-footer.php'; ?>
  <div id="modal-root"></div>
  <script src="/assets/js/data.js"></script>
  <script src="/assets/js/api-core.js"></script>
  <script src="/assets/js/api.js"></script>
  <script src="/assets/js/app.js"></script>
  <?= $scripts ?? '' ?>
</body>
</html>
```

- [ ] **Step 4: Create admin layout**

Create `app/Views/layouts/admin.php`:

```php
<!doctype html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="robots" content="noindex, nofollow">
  <meta name="csrf-token" content="<?= $e($csrfToken ?? '') ?>">
  <title><?= $e($title ?? 'Admin GenBI') ?></title>
  <link rel="stylesheet" href="/assets/css/tailwind.css">
  <link rel="stylesheet" href="/assets/css/styles.css">
</head>
<body class="admin-body" data-cms-page="<?= $e($cmsPage ?? '') ?>" data-cms-mode="<?= $e($cmsMode ?? '') ?>">
  <div class="admin-shell">
    <?php require __DIR__ . '/../partials/admin-sidebar.php'; ?>
    <div class="admin-main">
      <?php require __DIR__ . '/../partials/admin-topbar.php'; ?>
      <main class="px-4 py-8 md:px-8 lg:px-10" id="admin-content">
        <?= $content ?>
      </main>
    </div>
  </div>
  <div id="admin-mobile-backdrop" class="fixed inset-0 z-[70] hidden bg-neutral-950/35 backdrop-blur-sm lg:hidden"></div>
  <div id="admin-toast" class="admin-toast rounded-2xl bg-blue-950 px-5 py-4 text-sm font-semibold text-white shadow-2xl">Perubahan disimpan.</div>
  <script src="/assets/js/data.js"></script>
  <script src="/assets/js/api-core.js"></script>
  <script src="/assets/js/api.js"></script>
  <script src="/assets/js/app.js"></script>
  <script src="/assets/js/admin/admin.js"></script>
  <?= $scripts ?? '' ?>
</body>
</html>
```

- [ ] **Step 5: Create minimal partials**

Create `app/Views/partials/public-header.php`:

```php
<header class="site-header">
  <div class="site-container flex items-center justify-between py-4">
    <a href="/" class="font-bold text-blue-900">GenBI Jambi</a>
    <nav class="hidden gap-5 text-sm font-semibold text-neutral-700 md:flex">
      <a href="/about">About</a>
      <a href="/team">Team</a>
      <a href="/news">News</a>
      <a href="/event">Event</a>
      <a href="/prestasi">Prestasi</a>
      <a href="/contact">Contact</a>
    </nav>
  </div>
</header>
```

Create `app/Views/partials/public-footer.php`:

```php
<footer class="bg-blue-950 py-10 text-white">
  <div class="site-container text-sm text-white/75">© <?= date('Y') ?> GenBI Provinsi Jambi</div>
</footer>
```

Create `app/Views/partials/admin-sidebar.php`:

```php
<aside id="admin-sidebar" class="admin-sidebar"></aside>
```

Create `app/Views/partials/admin-topbar.php`:

```php
<div id="admin-topbar" class="admin-topbar"></div>
```

- [ ] **Step 6: Verify**

Run: `php -d zend.assertions=1 -d assert.exception=1 tests/php/ViewRendererTest.php`

Expected: PASS.

Run: `php -l app/Views/layouts/public.php && php -l app/Views/layouts/admin.php`

Expected: no syntax errors.

- [ ] **Step 7: Commit**

Run:

```bash
git add app/Views tests/php/ViewRendererTest.php
git commit -m "feat: add shared PHP layouts and partials"
```

---

### Task 3: Migrate Public News List To SSR

**Files:**
- Create: `app/Views/public/news/index.php`
- Modify: `app/Controllers/Public/NewsController.php`
- Modify: `bootstrap/app.php`
- Modify: `public/assets/js/pages/news.js`

- [ ] **Step 1: Update controller constructor**

Modify `app/Controllers/Public/NewsController.php` imports:

```php
use App\Core\ViewRenderer;
```

Change constructor to:

```php
public function __construct(
    private StaticPageRenderer $renderer,
    private ?News $news = null,
    private ?ViewRenderer $viewRenderer = null,
) {
}
```

Modify `bootstrap/app.php` controller creation:

```php
$newsController = new NewsController($renderer, $newsModel, $viewRenderer);
```

- [ ] **Step 2: Create news index view**

Create `app/Views/public/news/index.php`:

```php
<section class="bg-stone py-14 md:py-20">
  <div class="site-container">
    <p class="eyebrow">News</p>
    <h1 class="page-title mt-4">Berita GenBI Jambi</h1>
    <p class="lead mt-6 max-w-3xl">Kabar kegiatan, literasi kebanksentralan, dan kontribusi GenBI Provinsi Jambi.</p>
    <div id="news-root" data-ssr="true" class="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
      <?php foreach (($items ?? []) as $item): ?>
        <article class="news-card">
          <a href="/news/<?= rawurlencode((string) $item['slug']) ?>">
            <?php if (!empty($item['image'])): ?>
              <img src="<?= $e($item['image']) ?>" alt="<?= $e($item['title']) ?>" class="news-card-image">
            <?php endif; ?>
            <div class="news-card-body">
              <div class="flex flex-wrap items-center gap-2 text-xs font-bold text-blue-800">
                <span><?= $e($item['category']) ?></span>
                <span><?= $e(substr((string) ($item['date'] ?? ''), 0, 10)) ?></span>
              </div>
              <h2 class="mt-3 text-xl font-semibold text-neutral-950"><?= $e($item['title']) ?></h2>
              <p class="mt-3 text-sm leading-6 text-neutral-600"><?= $e($item['excerpt']) ?></p>
            </div>
          </a>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>
```

- [ ] **Step 3: Render SSR view in controller**

In `NewsController::index()`, replace the final static render branch with:

```php
$seo = SeoService::forPage('news.html');
$meta = SeoService::renderMetaBlock($seo);
$jsonld = StructuredData::organization() . PHP_EOL . '  ' . StructuredData::breadcrumbs([
    ['name' => 'Beranda', 'url' => '/'],
    ['name' => 'Berita', 'url' => '/news'],
]);

if ($this->viewRenderer instanceof ViewRenderer) {
    $items = $this->readFromDatabase(static fn (News $news): array => $news->paginate([], 100, 0)) ?? [];
    $html = $this->viewRenderer->renderWithLayout('public/news/index.php', 'layouts/public.php', [
        'items' => $items,
        'meta' => $meta,
        'jsonld' => $jsonld,
        'bodyClass' => 'page-news',
        'scripts' => '<script src="/assets/js/pages/news.js"></script>',
    ]);
    $response->html($html);
    return;
}

$response->html($this->renderer->render('news.html', ['meta' => $meta, 'jsonld' => $jsonld]));
```

- [ ] **Step 4: Prevent duplicate client rendering**

At the top of `public/assets/js/pages/news.js`, after root lookup, add:

```js
if (root?.dataset.ssr === 'true') {
  document.body.classList.add('page-ready');
  return;
}
```

Use the actual variable name already present in `news.js`; if it is not named `root`, apply the same guard to the existing root element variable.

- [ ] **Step 5: Verify**

Run: `php -l app/Controllers/Public/NewsController.php && php -l app/Views/public/news/index.php`

Expected: no syntax errors.

Run: `npm test`

Expected: 19 JS tests pass.

Smoke with server:

```bash
php -S 127.0.0.1:8091 -t public public/index.php
```

In another shell run: `/usr/bin/curl -s -o /tmp/news.html -w '%{http_code}' http://127.0.0.1:8091/news`

Expected: `200`, and `/tmp/news.html` contains `data-ssr="true"` and at least one `.news-card` when DB is available.

- [ ] **Step 6: Commit**

Run:

```bash
git add app/Controllers/Public/NewsController.php app/Views/public/news/index.php bootstrap/app.php public/assets/js/pages/news.js
git commit -m "feat: render public news list server-side"
```

---

### Task 4: Migrate Public News Detail To SSR

**Files:**
- Create: `app/Views/public/news/show.php`
- Modify: `app/Controllers/Public/NewsController.php`
- Modify: `public/assets/js/pages/news-detail.js`

- [ ] **Step 1: Create detail view**

Create `app/Views/public/news/show.php`:

```php
<?php $item = $item ?? null; ?>
<?php if (!$item): ?>
  <section class="bg-stone py-16"><div class="article-container text-sm text-neutral-600">Berita tidak ditemukan.</div></section>
<?php else: ?>
  <section class="news-detail-hero">
    <?php if (!empty($item['image'])): ?>
      <img class="news-detail-hero-img" src="<?= $e($item['image']) ?>" alt="<?= $e($item['title']) ?>">
    <?php endif; ?>
    <div class="news-detail-hero-overlay"></div>
    <div class="news-detail-hero-content article-container fade-up in-view">
      <a href="/news" class="chip chip-light mb-7">← Kembali ke News</a>
      <div class="news-detail-meta flex flex-wrap items-center gap-3 text-xs font-semibold text-white/80">
        <span><?= $e($item['category']) ?></span>
        <span><?= $e(substr((string) ($item['date'] ?? ''), 0, 10)) ?></span>
      </div>
      <h1 class="page-title mt-5"><?= $e($item['title']) ?></h1>
      <p class="lead mt-7"><?= $e($item['excerpt']) ?></p>
    </div>
  </section>
  <section class="bg-cream py-10 md:py-16">
    <article class="article-container fade-up in-view">
      <div id="news-detail-root" data-ssr="true" class="prose-soft news-detail-content">
        <?php if (!empty($item['image'])): ?>
          <img class="news-detail-inline-image" src="<?= $e($item['image']) ?>" alt="<?= $e($item['title']) ?>">
        <?php endif; ?>
        <?= $item['content'] ?? '' ?>
      </div>
      <?php if (!empty($item['contributor_pewarta']) || !empty($item['contributor_editor'])): ?>
        <div class="mt-10 rounded-[1.5rem] border border-neutral-900/10 bg-white/80 p-5 text-sm leading-7 text-neutral-700">
          <?php if (!empty($item['contributor_pewarta'])): ?><p><strong>Pewarta:</strong> <?= $e($item['contributor_pewarta']) ?></p><?php endif; ?>
          <?php if (!empty($item['contributor_editor'])): ?><p><strong>Editor:</strong> <?= $e($item['contributor_editor']) ?></p><?php endif; ?>
        </div>
      <?php endif; ?>
    </article>
  </section>
<?php endif; ?>
```

- [ ] **Step 2: Render detail view in controller**

In `NewsController::show()`, replace the final static render branch with:

```php
if ($this->viewRenderer instanceof ViewRenderer) {
    $html = $this->viewRenderer->renderWithLayout('public/news/show.php', 'layouts/public.php', [
        'item' => $item,
        'meta' => $meta,
        'jsonld' => $jsonld,
        'bodyClass' => 'page-news-detail',
        'scripts' => '<script src="/assets/js/pages/news-detail.js"></script>',
    ]);
    $response->html($html, is_array($item) ? 200 : 404);
    return;
}

$response->html($this->renderer->render('news-detail.html', ['slug' => $slug, 'meta' => $meta, 'jsonld' => $jsonld]));
```

- [ ] **Step 3: Prevent duplicate detail rendering**

At the start of `renderDetail()` in `public/assets/js/pages/news-detail.js`, after root lookup, add:

```js
if (root?.dataset.ssr === 'true') {
  document.body.classList.add('page-ready');
  return;
}
```

- [ ] **Step 4: Verify**

Run: `php -l app/Views/public/news/show.php && php -l app/Controllers/Public/NewsController.php`

Expected: no syntax errors.

Run: `node --check public/assets/js/pages/news-detail.js && npm test`

Expected: syntax check passes and 19 tests pass.

Smoke: `/usr/bin/curl -s -o /tmp/news-detail.html -w '%{http_code}' http://127.0.0.1:8091/news/<known-slug>`

Expected: `200`; HTML contains `data-ssr="true"`, `NewsArticle` JSON-LD, and no default contributor box when contributor columns are empty.

- [ ] **Step 5: Commit**

Run:

```bash
git add app/Controllers/Public/NewsController.php app/Views/public/news/show.php public/assets/js/pages/news-detail.js
git commit -m "feat: render public news detail server-side"
```

---

### Task 5: Migrate Admin News List Shell To SSR

**Files:**
- Create: `app/Views/admin/news/index.php`
- Modify: `app/Controllers/Admin/AdminPageController.php`
- Modify: `bootstrap/app.php`
- Modify: `public/assets/js/admin/cms.js`

- [ ] **Step 1: Update admin page controller constructor**

Modify imports in `app/Controllers/Admin/AdminPageController.php`:

```php
use App\Core\ViewRenderer;
use App\Models\News;
```

Change constructor:

```php
public function __construct(
    private StaticPageRenderer $renderer,
    private ?ViewRenderer $viewRenderer = null,
    private ?News $news = null,
) {
}
```

Modify `bootstrap/app.php`:

```php
$adminPageController = new AdminPageController($renderer, $viewRenderer, $newsModel);
```

- [ ] **Step 2: Create admin news list view**

Create `app/Views/admin/news/index.php`:

```php
<div class="admin-page-head">
  <div>
    <p class="admin-eyebrow">News CMS</p>
    <h1>View News</h1>
    <p>Daftar berita dari <code>tbl_news</code>. Aksi hapus tetap memakai custom confirmation modal.</p>
  </div>
  <a href="/admin/news-add" class="btn btn-primary">Add News</a>
</div>
<section class="admin-card mt-6 overflow-hidden">
  <table class="admin-table">
    <thead><tr><th>SL</th><th>Photo</th><th>News Title</th><th>Category</th><th>Status</th><th>Action</th></tr></thead>
    <tbody id="admin-news-list" data-ssr="true">
      <?php foreach (($items ?? []) as $index => $item): ?>
        <tr>
          <td><?= $index + 1 ?></td>
          <td><?php if (!empty($item['photo'])): ?><img src="<?= $e($item['photo']) ?>" class="table-thumb" alt="<?= $e($item['title']) ?>"><?php endif; ?></td>
          <td><strong><?= $e($item['title']) ?></strong><p class="mt-1 text-xs text-neutral-500"><?= $e(substr((string) ($item['date'] ?? ''), 0, 10)) ?></p></td>
          <td><?= $e($item['category']) ?></td>
          <td><span class="status-pill <?= $e($item['status']) ?>"><?= $e($item['status']) ?></span></td>
          <td><a class="btn btn-secondary" href="/admin/news-edit?id=<?= (int) $item['id'] ?>">Edit</a> <button class="btn btn-danger" data-delete-news="<?= (int) $item['id'] ?>">Delete</button></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</section>
```

- [ ] **Step 3: Route admin news page through SSR**

In `AdminPageController::show()`, after `$page` is calculated, add:

```php
if ($page === 'news' && $this->viewRenderer instanceof ViewRenderer) {
    $items = $this->news?->allForAdmin(50, 0) ?? [];
    $html = $this->viewRenderer->renderWithLayout('admin/news/index.php', 'layouts/admin.php', [
        'title' => 'View News | Admin GenBI',
        'csrfToken' => CsrfService::token(),
        'cmsPage' => 'news',
        'cmsMode' => 'list',
        'items' => $items,
        'scripts' => '<script src="/assets/js/admin/cms.js"></script>',
    ]);
    $response->html($html, 200, ['X-Robots-Tag' => 'noindex, nofollow']);
    return;
}
```

- [ ] **Step 4: Prevent duplicate admin list rendering**

In `public/assets/js/admin/cms.js`, in `renderNewsList()`, add a guard at the top:

```js
if (document.querySelector('#admin-news-list[data-ssr="true"]')) {
  bindNewsDeleteButtons();
  return;
}
```

If no `bindNewsDeleteButtons()` exists, extract the existing delete button binding from the bottom of `renderNewsList()` into a named function and call it in both paths.

- [ ] **Step 5: Verify**

Run: `php -l app/Controllers/Admin/AdminPageController.php && php -l app/Views/admin/news/index.php`

Expected: no syntax errors.

Run: `node --check public/assets/js/admin/cms.js && npm test`

Expected: syntax check passes and 19 tests pass.

Smoke `/admin/news` while logged in.

Expected: HTML source contains `id="admin-news-list" data-ssr="true"` and no CSRF errors on delete.

- [ ] **Step 6: Commit**

Run:

```bash
git add app/Controllers/Admin/AdminPageController.php app/Views/admin/news/index.php bootstrap/app.php public/assets/js/admin/cms.js
git commit -m "feat: render admin news list server-side"
```

---

### Task 6: Migrate Admin News Add/Edit Shell To SSR

**Files:**
- Create: `app/Views/admin/news/form.php`
- Modify: `app/Controllers/Admin/AdminPageController.php`
- Modify: `public/assets/js/admin/cms.js`

- [ ] **Step 1: Create SSR form view**

Create `app/Views/admin/news/form.php` with the same semantic structure currently generated in `renderNewsEditor()`:

```php
<?php $item = $item ?? ['title' => '', 'excerpt' => '', 'content' => '', 'date' => date('Y-m-d'), 'category_id' => 0, 'photo' => '', 'banner' => '', 'status' => 'draft']; ?>
<form class="medium-editor-layout" id="news-editor-form" data-news-id="<?= (int) ($item['id'] ?? 0) ?>" data-news-mode="<?= $e($mode ?? 'create') ?>">
  <main class="medium-editor-canvas">
    <div class="medium-editor-kicker">Story editor</div>
    <section class="story-main-block">
      <label for="news-title-field">News Title</label>
      <div id="news-title-field" class="story-title-field" contenteditable="true" spellcheck="true" data-placeholder="Tulis judul berita..."><?= $e($item['title'] ?? '') ?></div>
    </section>
    <section class="story-main-block">
      <label for="news-short-content-field">News Short Content</label>
      <div id="news-short-content-field" class="story-excerpt-field" contenteditable="true" spellcheck="true" data-placeholder="Tulis caption atau ringkasan singkat untuk news list..."><?= $e($item['excerpt'] ?? '') ?></div>
    </section>
    <div class="medium-editor-divider"><div class="medium-editor-kicker">News content</div></div>
    <div id="news-editor" class="medium-editor-host" data-initial-html="<?= $e($item['content'] ?? '') ?>"></div>
    <div id="editor-fallback" class="editor-fallback hidden"><article contenteditable="true"><?= $item['content'] ?? '' ?></article></div>
    <p class="medium-editor-help">Tekan <strong>Enter</strong> untuk membuat blok baru. Sisipkan gambar di antara paragraf lewat tombol plus Editor.js atau panel kanan.</p>
  </main>
  <aside class="editor-config-sidebar medium-config-sidebar">
    <section class="config-card medium-config-card">
      <h2>Publishing</h2>
      <label class="config-field"><span>News Publish Date</span><input id="news-date" class="config-input" type="date" value="<?= $e(substr((string) ($item['date'] ?? date('Y-m-d')), 0, 10)) ?>"></label>
      <label class="config-field"><span>Category</span><select class="config-input" id="news-category-select"><?php foreach (($categories ?? []) as $category): ?><option value="<?= (int) $category['category_id'] ?>" <?= (int) ($item['category_id'] ?? 0) === (int) $category['category_id'] ? 'selected' : '' ?>><?= $e($category['category_name']) ?></option><?php endforeach; ?></select></label>
    </section>
    <section class="config-card medium-config-card">
      <h2>Photo and Banner</h2>
      <?php if (!empty($item['photo'])): ?><img src="<?= $e($item['photo']) ?>" class="config-preview" alt="Featured photo"><?php else: ?><div class="config-empty">Belum ada foto utama</div><?php endif; ?>
      <input id="news-photo-file" class="hidden" type="file" accept="image/*">
      <button type="button" id="news-photo-upload-btn" class="btn btn-secondary w-full mt-2">Upload Featured Photo</button>
      <input class="config-input mt-2" id="news-photo-url" value="<?= $e($item['photo'] ?? '') ?>" placeholder="URL foto utama">
      <input id="news-banner-file" class="hidden" type="file" accept="image/*">
      <button type="button" id="news-banner-upload-btn" class="btn btn-secondary w-full mt-2">Upload Banner</button>
      <input class="config-input mt-2" id="news-banner-url" value="<?= $e($item['banner'] ?? '') ?>" placeholder="URL banner">
    </section>
    <section class="config-card medium-config-card">
      <h2>Contributors</h2>
      <label class="config-field"><span>Pewarta</span><input class="config-input" id="news-pewarta" value="<?= $e($item['contributor_pewarta'] ?? '') ?>"></label>
      <label class="config-field"><span>Editor</span><input class="config-input" id="news-editor-name" value="<?= $e($item['contributor_editor'] ?? '') ?>"></label>
    </section>
    <section class="config-card medium-config-card">
      <h2>Status</h2>
      <label class="config-field"><span>Publish Status</span><select class="config-input" id="news-status"><option value="draft" <?= ($item['status'] ?? 'draft') === 'draft' ? 'selected' : '' ?>>Draft</option><option value="published" <?= ($item['status'] ?? '') === 'published' ? 'selected' : '' ?>>Published</option><option value="archived" <?= ($item['status'] ?? '') === 'archived' ? 'selected' : '' ?>>Archived</option></select></label>
    </section>
    <button type="submit" class="btn btn-primary w-full"><?= ($mode ?? 'create') === 'edit' ? 'Update News' : 'Submit News' ?></button>
  </aside>
</form>
```

- [ ] **Step 2: Render add/edit pages from admin controller**

In `AdminPageController::show()`, add before the static fallback:

```php
if (in_array($page, ['news-add', 'news-edit'], true) && $this->viewRenderer instanceof ViewRenderer) {
    $id = (int) ($request->query('id') ?? 0);
    $item = $page === 'news-edit' && $id > 0 ? $this->news?->findById($id) : null;
    $categories = $this->news?->categories() ?? [];
    $html = $this->viewRenderer->renderWithLayout('admin/news/form.php', 'layouts/admin.php', [
        'title' => ($page === 'news-edit' ? 'Edit News' : 'Add News') . ' | Admin GenBI',
        'csrfToken' => CsrfService::token(),
        'cmsPage' => 'news',
        'cmsMode' => 'editor',
        'mode' => $page === 'news-edit' ? 'edit' : 'create',
        'item' => $item,
        'categories' => $categories,
        'scripts' => '<script src="https://cdn.jsdelivr.net/npm/@editorjs/editorjs@latest"></script><script src="https://cdn.jsdelivr.net/npm/@editorjs/header@latest"></script><script src="https://cdn.jsdelivr.net/npm/@editorjs/list@latest"></script><script src="https://cdn.jsdelivr.net/npm/@editorjs/quote@latest"></script><script src="https://cdn.jsdelivr.net/npm/@editorjs/image@latest"></script><script src="/assets/js/admin/cms.js"></script>',
    ]);
    $response->html($html, 200, ['X-Robots-Tag' => 'noindex, nofollow']);
    return;
}
```

- [ ] **Step 3: Convert admin JS to hydrate existing SSR form**

In `renderNewsEditor(isEdit)`, add at the top:

```js
const existingForm = document.querySelector('#news-editor-form[data-news-mode]');
if (existingForm) {
  const editor = initMediumEditor({ content: document.querySelector('#news-editor')?.dataset.initialHtml || '' }, isEdit);
  bindMediumEditorActions(editor);
  bindNewsImageUploads();
  bindNewsEditorSubmit(editor, isEdit, Number(existingForm.dataset.newsId) || 0);
  return;
}
```

Extract the submit listener body into:

```js
function bindNewsEditorSubmit(editor, isEdit, id) {
  document.querySelector('#news-editor-form')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    // Move the existing submit code here without changing payload fields.
  });
}
```

Then replace the old inline `addEventListener('submit', ...)` with `bindNewsEditorSubmit(editor, isEdit, id);`.

- [ ] **Step 4: Verify**

Run: `php -l app/Views/admin/news/form.php && php -l app/Controllers/Admin/AdminPageController.php`

Expected: no syntax errors.

Run: `node --check public/assets/js/admin/cms.js && npm test && rtk npm run build:css`

Expected: all pass.

Manual smoke:

- Open `/admin/news-add` while logged in.
- Confirm source HTML includes `id="news-editor-form"` without waiting for JS.
- Submit a draft with title, short content, and one paragraph.
- Confirm no `CSRF token invalid` error.
- Open `/admin/news-edit?id=<new-id>`.
- Confirm `tbl_news.news_content` HTML appears in the story editor.

- [ ] **Step 5: Commit**

Run:

```bash
git add app/Controllers/Admin/AdminPageController.php app/Views/admin/news/form.php public/assets/js/admin/cms.js
git commit -m "feat: render admin news editor server-side"
```

---

### Task 7: Repeat SSR Pattern For Team, Event, Prestasi

**Files:**
- Create: `app/Views/public/team/index.php`
- Create: `app/Views/public/event/index.php`
- Create: `app/Views/public/event/show.php`
- Create: `app/Views/public/prestasi/index.php`
- Modify: `app/Controllers/Public/TeamController.php`
- Modify: `app/Controllers/Public/EventController.php`
- Modify: `app/Controllers/Public/PrestasiController.php`
- Modify: corresponding page JS files to skip duplicate rendering when `data-ssr="true"` exists.

- [ ] **Step 1: Apply same controller pattern**

For each public controller constructor, add optional `ViewRenderer`:

```php
private ?ViewRenderer $viewRenderer = null,
```

Pass `$viewRenderer` from `bootstrap/app.php` to `TeamController`, `EventController`, and `PrestasiController`.

- [ ] **Step 2: Create SSR index views**

Each index view should render a full meaningful list from the model and mark the list root with `data-ssr="true"`.

For Prestasi, do not copy the older filter-heavy UI from `PROBLEMS.md` directly. Match the current accepted behavior:

```text
- No public tag/category filter.
- Keep the segmented List/Grid toggle as progressive UI.
- Initial SSR markup should be useful even before JS: render a one-row-per-item list by default.
- Include image markup using the normalized `image`/`photo` value from the model/API shape.
- Render only published, non-deleted rows.
```

Use this minimum pattern for each card list:

```php
<section class="bg-stone py-14 md:py-20">
  <div class="site-container">
    <p class="eyebrow"><?= $e($eyebrow ?? '') ?></p>
    <h1 class="page-title mt-4"><?= $e($title ?? '') ?></h1>
    <div data-ssr="true" class="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
      <?php foreach (($items ?? []) as $item): ?>
        <article class="rounded-[1.5rem] border border-neutral-900/10 bg-white p-5 shadow-sm">
          <h2 class="text-xl font-semibold text-neutral-950"><?= $e($item['title'] ?? $item['name'] ?? '') ?></h2>
          <p class="mt-3 text-sm leading-6 text-neutral-600"><?= $e($item['description'] ?? $item['excerpt'] ?? $item['role'] ?? '') ?></p>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>
```

- [ ] **Step 3: Keep JSON API behavior**

Do not remove any `if ($request->acceptsJson())` branches. Add SSR only to non-JSON branches.

- [ ] **Step 4: Add duplicate-render guards to JS**

For each page JS, add:

```js
if (document.querySelector('[data-ssr="true"]')) {
  document.body.classList.add('page-ready');
  return;
}
```

Place the guard after the script has confirmed it is on the correct page.

- [ ] **Step 5: Verify**

Run:

```bash
php -l app/Controllers/Public/TeamController.php
php -l app/Controllers/Public/EventController.php
php -l app/Controllers/Public/PrestasiController.php
node --check public/assets/js/pages/team.js
node --check public/assets/js/pages/event.js
node --check public/assets/js/pages/prestasi.js
npm test
```

Smoke:

```bash
/usr/bin/curl -s -o /tmp/team.html -w '%{http_code}' http://127.0.0.1:8091/team
/usr/bin/curl -s -o /tmp/event.html -w '%{http_code}' http://127.0.0.1:8091/event
/usr/bin/curl -s -o /tmp/prestasi.html -w '%{http_code}' http://127.0.0.1:8091/prestasi
```

Expected: all return `200`.

- [ ] **Step 6: Commit**

Run:

```bash
git add app/Controllers/Public app/Views/public public/assets/js/pages bootstrap/app.php
git commit -m "feat: render remaining public listing pages server-side"
```

---

### Task 8: Retire Static HTML Fallbacks Route-By-Route

**Files:**
- Modify: `app/Core/StaticPageRenderer.php`
- Modify: `docs/PROJECT_PROGRESS.md`
- Create: `docs/report/YYYY-MM-DD-ssr-migration.md`

- [ ] **Step 1: Add progress report**

Create `docs/report/2026-05-06-ssr-migration.md`:

```markdown
# SSR Migration Report

## Completed
- PHP view renderer added.
- Shared public/admin layouts added.
- Public news list/detail render server-side.
- Admin news list/editor shell render server-side.
- JSON API branches preserved.

## Verification
- npm test
- PHP test loop
- node --check modified JS files
- php -l modified PHP files
- curl smoke checks for migrated routes

## Remaining
- Convert remaining static public/admin pages when their models and schema audits are ready.
- Keep News/Prestasi schema audit notes with the migration report, including whether follow-up migrations were required.
- Remove static fallback HTML only after equivalent SSR pages pass smoke tests.
```

- [ ] **Step 2: Update progress tracker**

In `docs/PROJECT_PROGRESS.md`, mark SSR migration items complete only for routes that passed tests and smoke checks. Do not mark unrelated CMS features complete.

- [ ] **Step 3: Keep static fallback until all equivalent SSR exists**

Do not delete root `*.html` or `admin/*.html` in this task. Add comments to `StaticPageRenderer.php` only if needed:

```php
// Static fallback remains during incremental SSR migration.
```

- [ ] **Step 4: Final verification**

Run:

```bash
npm test
rtk npm run build:css
for f in tests/php/*.php; do php -d zend.assertions=1 -d assert.exception=1 "$f"; done
```

Expected: all pass.

- [ ] **Step 5: Commit**

Run:

```bash
git add docs/PROJECT_PROGRESS.md docs/report/2026-05-06-ssr-migration.md app/Core/StaticPageRenderer.php
git commit -m "docs: record SSR migration progress"
```

---

## Final Acceptance Criteria

- `/news` renders meaningful article cards in initial HTML without waiting for JS.
- `/news/{slug}` renders title, hero, featured image, article body, and preserved contributor data in initial HTML.
- `/admin/news` renders the news table in initial HTML while JS only binds delete behavior.
- `/admin/news-add` and `/admin/news-edit?id=...` render the form shell server-side.
- Admin news add/edit still stores HTML in `tbl_news.news_content`.
- `tbl_news` schema is audited before SSR News rollout; any missing slug, contributor, status, timestamp, soft-delete, `content_json`, or index requirement is fixed with a forward-only migration.
- `tbl_prestasi` schema is audited before SSR Prestasi rollout; any missing title, slug, member, institution, year, category/peringkat, description/detail, image, status, soft-delete, or index requirement is fixed with a forward-only migration.
- Public `/prestasi` SSR preserves the current simplified Prestasi UX: no tag/category filter, list/grid-ready markup, published-only rows, normalized image URLs, and fields mapped from `member_name`, `institution`, `year`, `category`, and `description`.
- Admin news add/edit no longer throws `CSRF token invalid` for normal authenticated sessions.
- Image upload blocks show upload state and preview after successful upload.
- JSON API behavior stays compatible for existing `window.GenBIAPI` consumers.
- Static HTML files are not deleted until their corresponding SSR routes are fully migrated and verified.

## Self-Review

- Spec coverage: The plan covers PHP renderer foundation, schema/migration audit for current News and Prestasi conditions, public news SSR, admin news SSR, CSRF-safe admin submit/upload flow, and route-by-route migration for other public pages.
- Placeholder scan: The plan avoids `TBD`, vague error handling, and unspecified tests. Every task includes exact files and commands.
- Type consistency: `ViewRenderer`, `renderWithLayout()`, `ViewRenderer` constructor usage, and controller constructor signatures are consistent across tasks.
