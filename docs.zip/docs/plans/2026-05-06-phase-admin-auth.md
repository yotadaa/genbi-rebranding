# Admin Authentication Implementation Plan

> **For agentic workers:** Use executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add secure admin authentication with login/logout, session management, middleware pipeline, CSRF protection, and rate limiting — making all admin routes production-safe.

**Architecture:** Add middleware support to the existing Router via a simple pipeline pattern. Create AuthService for login/verify logic, CsrfService for token management, and middleware classes that wrap route handlers. Session initialization happens in bootstrap before routing.

**Tech Stack:** PHP 8.4, existing custom Router/Request/Response, PHP native sessions, `password_hash()`/`password_verify()`, SHA-256 CSRF tokens.

---

## File Structure

### Files to Create
- `app/Core/Session.php` — session start/config/helpers
- `app/Core/Middleware.php` — middleware interface
- `app/Services/AuthService.php` — login, verify, logout, rate limit logic
- `app/Services/CsrfService.php` — token generation and validation
- `app/Middleware/AuthMiddleware.php` — protect admin routes
- `app/Middleware/CsrfMiddleware.php` — validate CSRF on POST
- `app/Controllers/Admin/AuthController.php` — login page, login POST, logout
- `tests/php/AuthServiceTest.php` — unit test for auth logic

### Files to Modify
- `app/Core/Router.php` — add middleware pipeline support
- `app/Core/Request.php` — add `session()` helper
- `bootstrap/app.php` — initialize session, wire auth
- `routes/admin.php` — add login/logout routes, apply middleware

---

## Task 1: Add Session Management

**Files:**
- Create: `app/Core/Session.php`
- Modify: `app/Core/Request.php`

- [ ] **Step 1: Create Session class**

```php
<?php
declare(strict_types=1);
namespace App\Core;

use App\Config\Security;

final class Session
{
    private static bool $started = false;

    public static function start(): void
    {
        if (self::$started || session_status() === PHP_SESSION_ACTIVE) {
            self::$started = true;
            return;
        }

        $config = Security::config();
        session_name($config['session_name']);
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => '/',
            'domain' => '',
            'secure' => $config['session_secure'],
            'httponly' => true,
            'samesite' => $config['session_samesite'],
        ]);
        session_start();
        self::$started = true;
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        return $_SESSION[$key] ?? $default;
    }

    public static function set(string $key, mixed $value): void
    {
        $_SESSION[$key] = $value;
    }

    public static function remove(string $key): void
    {
        unset($_SESSION[$key]);
    }

    public static function has(string $key): bool
    {
        return isset($_SESSION[$key]);
    }

    public static function regenerate(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_regenerate_id(true);
        }
    }

    public static function destroy(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
        }
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }
        self::$started = false;
    }

    public static function flash(string $key, mixed $value): void
    {
        $_SESSION['_flash'][$key] = $value;
    }

    public static function getFlash(string $key, mixed $default = null): mixed
    {
        $value = $_SESSION['_flash'][$key] ?? $default;
        unset($_SESSION['_flash'][$key]);
        return $value;
    }
}
```

- [ ] **Step 2: Add session() helper to Request**

Add method to `app/Core/Request.php`:
```php
public function session(string $key, mixed $default = null): mixed
{
    return \App\Core\Session::get($key, $default);
}
```

- [ ] **Step 3: Verify PHP lint**

---

## Task 2: Add Middleware Support to Router

**Files:**
- Create: `app/Core/Middleware.php`
- Modify: `app/Core/Router.php`

- [ ] **Step 1: Create Middleware interface**

```php
<?php
declare(strict_types=1);
namespace App\Core;

interface Middleware
{
    public function handle(Request $request, Response $response, callable $next): void;
}
```

- [ ] **Step 2: Add middleware pipeline to Router**

Add `group()` method and modify `dispatch()` to support middleware:

```php
// Add to Router class:
private array $middlewareStack = [];

public function middleware(Middleware ...$middlewares): self
{
    $clone = clone $this;
    $clone->middlewareStack = array_merge($this->middlewareStack, $middlewares);
    return $clone;
}

// Modify the add() method to store middleware with routes:
private function add(string $method, string $pattern, callable $handler): void
{
    $this->routes[] = [
        'method' => $method,
        'pattern' => $this->normalizePattern($pattern),
        'handler' => $handler,
        'middleware' => $this->middlewareStack,
    ];
}
```

And modify `dispatch()` to run middleware pipeline before handler.

- [ ] **Step 3: Verify PHP lint**

---

## Task 3: Create CSRF Service

**Files:**
- Create: `app/Services/CsrfService.php`

- [ ] **Step 1: Create CsrfService**

```php
<?php
declare(strict_types=1);
namespace App\Services;

use App\Core\Session;

final class CsrfService
{
    private const TOKEN_KEY = '_csrf_token';

    public static function token(): string
    {
        if (!Session::has(self::TOKEN_KEY)) {
            Session::set(self::TOKEN_KEY, bin2hex(random_bytes(32)));
        }
        return (string) Session::get(self::TOKEN_KEY);
    }

    public static function validate(?string $token): bool
    {
        if (empty($token)) {
            return false;
        }
        $stored = Session::get(self::TOKEN_KEY);
        if (empty($stored)) {
            return false;
        }
        return hash_equals((string) $stored, $token);
    }

    public static function regenerate(): void
    {
        Session::set(self::TOKEN_KEY, bin2hex(random_bytes(32)));
    }

    public static function hiddenInput(): string
    {
        return '<input type="hidden" name="_csrf_token" value="' . htmlspecialchars(self::token(), ENT_QUOTES, 'UTF-8') . '">';
    }
}
```

- [ ] **Step 2: Verify PHP lint**

---

## Task 4: Create AuthService

**Files:**
- Create: `app/Services/AuthService.php`
- Create: `tests/php/AuthServiceTest.php`

- [ ] **Step 1: Create AuthService**

Handles: login attempt, verify session, logout, rate limiting, account locking.

- [ ] **Step 2: Create test for password verification and rate limit logic**

- [ ] **Step 3: Run test**

---

## Task 5: Create Middleware Classes

**Files:**
- Create: `app/Middleware/AuthMiddleware.php`
- Create: `app/Middleware/CsrfMiddleware.php`

- [ ] **Step 1: Create AuthMiddleware**

Checks session for authenticated user. Redirects to `/admin/login` if not authenticated.

- [ ] **Step 2: Create CsrfMiddleware**

Validates `_csrf_token` from POST body against session token. Returns 403 if invalid.

- [ ] **Step 3: Verify PHP lint**

---

## Task 6: Create AuthController

**Files:**
- Create: `app/Controllers/Admin/AuthController.php`

- [ ] **Step 1: Create AuthController**

Methods: `showLogin()`, `login()`, `logout()`.

Login page renders a simple HTML form (inline, no template needed for now).
Login POST validates credentials via AuthService.
Logout destroys session and redirects.

- [ ] **Step 2: Verify PHP lint**

---

## Task 7: Wire Routes and Bootstrap

**Files:**
- Modify: `bootstrap/app.php`
- Modify: `routes/admin.php`

- [ ] **Step 1: Initialize session in bootstrap**

Add `Session::start()` before routing.

- [ ] **Step 2: Add auth routes**

```
GET  /admin/login  -> authController->showLogin()
POST /admin/login  -> authController->login()
POST /admin/logout -> authController->logout()
```

- [ ] **Step 3: Apply AuthMiddleware to protected admin routes**

- [ ] **Step 4: Verify PHP lint**

---

## Task 8: Full Verification

- [ ] **Step 1: Run all PHP tests**
- [ ] **Step 2: Run npm test**
- [ ] **Step 3: Smoke test login page and protected routes**
- [ ] **Step 4: Update docs/PROJECT_PROGRESS.md**
- [ ] **Step 5: Create report**
- [ ] **Step 6: Notify user**
