# Backend Pagination Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Every item-listing page (public and admin) must paginate from the backend via URL query params (`?page=N`), never dump all rows into a single page.

**Architecture:** Shared `Paginator` helper parses `page`/`per_page` from the request, computes offset, and builds page-link query strings. Controllers fetch only the current slice. Views render `<a>` pagination links that work without JS. JS progressively enhances but never fetches all rows to slice client-side.

**Tech Stack:** PHP 8.2+, PDO, vanilla JS, existing ViewRenderer SSR.

---

## Pagination Contract

### URL Params
- `page` — 1-based, default `1`
- `per_page` — optional, clamped to max
- `q`, `category`, `division`, `campus`, `year`, `status` — filters preserved across pages

### Defaults

| Page | Default per_page | Max |
|---|---:|---:|
| Public news | 12 | 24 |
| Public prestasi | 12 | 24 |
| Public team | 12 | 48 |
| Admin news | 25 | 100 |
| Admin teams | 24 | 100 |
| Admin prestasi | 25 | 100 |

### API Meta Shape
```json
{
  "data": [],
  "meta": {
    "page": 1,
    "per_page": 12,
    "total": 80,
    "total_pages": 7
  }
}
```

---

## Task 1: Shared Paginator Helper

**Files:**
- Create: `app/Core/Paginator.php`
- Create: `tests/php/PaginatorTest.php`

- [ ] **Step 1: Write failing test**

Create `tests/php/PaginatorTest.php`:

```php
<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/bootstrap/app.php';
use App\Core\Paginator;

// Basic defaults
$p = Paginator::resolve([], 12, 24);
assert($p['page'] === 1);
assert($p['per_page'] === 12);
assert($p['offset'] === 0);

// Page 3
$p = Paginator::resolve(['page' => '3'], 12, 24);
assert($p['page'] === 3);
assert($p['offset'] === 24);

// Invalid page
$p = Paginator::resolve(['page' => '-5'], 12, 24);
assert($p['page'] === 1);

// per_page clamped
$p = Paginator::resolve(['per_page' => '999'], 12, 24);
assert($p['per_page'] === 24);

// per_page zero
$p = Paginator::resolve(['per_page' => '0'], 12, 24);
assert($p['per_page'] === 12);

// totalPages
assert(Paginator::totalPages(80, 12) === 7);
assert(Paginator::totalPages(0, 12) === 1);
assert(Paginator::totalPages(12, 12) === 1);
assert(Paginator::totalPages(13, 12) === 2);

// meta
$m = Paginator::meta(2, 12, 80);
assert($m['page'] === 2);
assert($m['per_page'] === 12);
assert($m['total'] === 80);
assert($m['total_pages'] === 7);

// buildQuery preserves filters
$qs = Paginator::buildQuery(3, ['q' => 'bank', 'category' => 'BI', 'empty' => '']);
assert(str_contains($qs, 'page=3'));
assert(str_contains($qs, 'q=bank'));
assert(str_contains($qs, 'category=BI'));
assert(!str_contains($qs, 'empty'));

echo "PHP paginator tests passed\n";
```

- [ ] **Step 2: Run test to verify it fails**

Run: `php -d zend.assertions=1 -d assert.exception=1 tests/php/PaginatorTest.php`
Expected: FAIL — `Paginator` class not found.

- [ ] **Step 3: Implement Paginator**

Create `app/Core/Paginator.php`:

```php
<?php
declare(strict_types=1);
namespace App\Core;

final class Paginator
{
    /** @param array<string, string|null> $params */
    public static function resolve(array $params, int $defaultPerPage = 12, int $maxPerPage = 24): array
    {
        $page = max(1, (int) ($params['page'] ?? 1));
        $perPage = (int) ($params['per_page'] ?? $defaultPerPage);
        if ($perPage < 1) $perPage = $defaultPerPage;
        if ($perPage > $maxPerPage) $perPage = $maxPerPage;
        return [
            'page' => $page,
            'per_page' => $perPage,
            'offset' => ($page - 1) * $perPage,
        ];
    }

    public static function totalPages(int $total, int $perPage): int
    {
        return $total < 1 ? 1 : (int) ceil($total / max(1, $perPage));
    }

    /** @return array{page: int, per_page: int, total: int, total_pages: int} */
    public static function meta(int $page, int $perPage, int $total): array
    {
        return [
            'page' => $page,
            'per_page' => $perPage,
            'total' => $total,
            'total_pages' => self::totalPages($total, $perPage),
        ];
    }

    /** @param array<string, string> $filters */
    public static function buildQuery(int $page, array $filters = []): string
    {
        $params = array_filter($filters, static fn($v) => $v !== '' && $v !== null);
        $params['page'] = (string) $page;
        return http_build_query($params);
    }
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `php -d zend.assertions=1 -d assert.exception=1 tests/php/PaginatorTest.php`
Expected: PASS

- [ ] **Step 5: Run full test suite**

Run: `for f in tests/php/*.php; do php -d zend.assertions=1 -d assert.exception=1 "$f" || exit 1; done && npm test`

- [ ] **Step 6: Commit**

```
git add app/Core/Paginator.php tests/php/PaginatorTest.php
git commit -m "feat: add shared Paginator helper with tests"
```

---

## Task 2: Public News Backend Pagination

**Files:**
- Modify: `app/Controllers/Public/NewsController.php`
- Modify: `app/Views/public/news/index.php`
- Modify: `public/assets/js/pages/news.js`

- [ ] **Step 1: Update NewsController SSR branch**

In `NewsController::index()`, replace the SSR branch that fetches 100 items with paginated fetch using `Paginator::resolve()`.

- [ ] **Step 2: Update news index view**

In `app/Views/public/news/index.php`, render pagination links as `<a href="/news?page=N">` that preserve `q` and `category` filters. Show "Page X of Y" and prev/next links.

- [ ] **Step 3: Update news.js**

In `public/assets/js/pages/news.js`, on SSR pages: bind search/category filter to submit via GET (page reload with `?q=...&page=1`). Do not fetch all items client-side. Pagination links already work as `<a>` tags.

- [ ] **Step 4: Verify**

Run: `php -l`, `node --check`, full test suite, smoke test `/news`, `/news?page=2`, `/news?q=bank`.

- [ ] **Step 5: Commit**

```
git commit -m "feat: paginate public news list from backend via URL"
```

---

## Task 3: Admin News URL Pagination

**Files:**
- Modify: `app/Controllers/Admin/AdminPageController.php`
- Modify: `app/Views/admin/news/index.php`
- Modify: `public/assets/js/admin/cms.js`

- [ ] **Step 1: Update AdminPageController news SSR**

Read `page`, `per_page`, `status` from request. Use `Paginator::resolve()`. Fetch only current page via `News::allForAdmin($perPage, $offset, $status)`. Count via `News::countForAdmin($status)`. Pass pagination data to view.

- [ ] **Step 2: Update admin news index view**

Add pagination controls below table. Render prev/next/page links as `<a>` tags. Show per-page selector. Show "Showing X-Y of Z".

- [ ] **Step 3: Update cms.js SSR news list**

On SSR admin news list, bind delete + pagination controls. Do not fetch all news client-side. Pagination links work as `<a>` tags.

- [ ] **Step 4: Verify and commit**

---

## Task 4: Prestasi Model countPublished + Public SSR

**Files:**
- Modify: `app/Models/Prestasi.php`
- Modify: `app/Controllers/Public/PrestasiController.php`
- Create: `app/Views/public/prestasi/index.php`
- Create: `app/Views/public/prestasi/show.php`
- Modify: `public/assets/js/pages/prestasi.js`
- Modify: `bootstrap/app.php`

- [ ] **Step 1: Add Prestasi::countPublished()**
- [ ] **Step 2: Update PrestasiController JSON to return meta**
- [ ] **Step 3: Inject ViewRenderer into PrestasiController**
- [ ] **Step 4: Create prestasi index SSR view with pagination**
- [ ] **Step 5: Create prestasi detail SSR view**
- [ ] **Step 6: Update prestasi.js for SSR detection**
- [ ] **Step 7: Verify and commit**

---

## Task 5: Public Team SSR + URL Pagination

**Files:**
- Modify: `app/Controllers/Public/TeamController.php`
- Create: `app/Views/public/team/index.php`
- Modify: `public/assets/js/pages/team.js`
- Modify: `bootstrap/app.php`

- [ ] **Step 1: Inject ViewRenderer into TeamController**
- [ ] **Step 2: Create team index SSR view with pagination**
- [ ] **Step 3: Update team.js for SSR detection + progressive hydration**
- [ ] **Step 4: Verify and commit**

---

## Task 6: Admin Team URL Pagination Sync

**Files:**
- Modify: `public/assets/js/admin/cms.js`

- [ ] **Step 1: Hydrate admin team state from URL on load**
- [ ] **Step 2: Write page/per_page/filters back to URL on change**
- [ ] **Step 3: Verify and commit**

---

## Task 7: Admin Prestasi Backend Pagination

**Files:**
- Modify: `app/Models/Prestasi.php`
- Modify: `app/Controllers/Admin/PrestasiController.php`
- Modify: `public/assets/js/admin/cms.js`

- [ ] **Step 1: Add Prestasi::countAll()**
- [ ] **Step 2: Update admin PrestasiController to return meta**
- [ ] **Step 3: Update cms.js prestasi list to fetch by page**
- [ ] **Step 4: Verify and commit**

---

## Task 8: Admin Team/Prestasi SSR Pages

**Files:**
- Create: `app/Views/admin/team/index.php`
- Create: `app/Views/admin/prestasi/index.php`
- Modify: `app/Controllers/Admin/AdminPageController.php`
- Modify: `bootstrap/app.php`

- [ ] **Step 1: Inject TeamMember and Prestasi into AdminPageController**
- [ ] **Step 2: Create admin team SSR view with pagination**
- [ ] **Step 3: Create admin prestasi SSR view with pagination**
- [ ] **Step 4: Add SSR branches in AdminPageController**
- [ ] **Step 5: Update cms.js for SSR detection on team/prestasi**
- [ ] **Step 6: Verify and commit**

---

## Task 9: Documentation and Progress Update

- [ ] **Step 1: Update docs/PROJECT_PROGRESS.md**
- [ ] **Step 2: Final full test suite run**
- [ ] **Step 3: Commit**
