# SEO/Canonical/Share Metadata + Sitemap/Feed Implementation Plan

> **For agentic workers:** Use executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add server-side SEO meta tag injection (title, description, canonical, Open Graph, Twitter Card, structured data JSON-LD), dynamic XML sitemap routes, RSS feed, and robots.txt — completing the final P2 item from the progress tracker.

**Architecture:** Extend the existing `StaticPageRenderer` with a meta injection system. Create `SeoService` for data-to-meta mapping. Add `SitemapController` and `FeedController` for XML routes. Add `xml()` response method. Keep the static HTML prototype as the page body while injecting dynamic `<head>` content server-side.

**Tech Stack:** PHP 8.4, existing custom Router/Response/Request, existing News/Prestasi models, XML generation via string templates (no external library).

---

## Design Decisions

1. **Meta injection via `StaticPageRenderer::render()` options** — The renderer already injects `noindex` and `slug` via string replacement before `</head>`. We extend this pattern with a `meta` option that injects a full meta block. This avoids creating a separate PHP view/template system for now.

2. **`SeoService` as a pure data mapper** — Takes entity data (news, prestasi, page config) and returns a structured array of meta values. No side effects, easily testable.

3. **Page-level SEO config** — Static pages (home, about, team, contact) get hardcoded meta from a config array. Dynamic pages (news detail, prestasi detail) get meta from DB data via SeoService.

4. **Sitemap/Feed as controller routes** — Simple XML string building. No external XML library needed for this scale.

---

## File Structure

### Files to Create
- `app/Services/SeoService.php` — meta data mapper
- `app/Services/SeoConfig.php` — static page meta configuration
- `app/Controllers/Public/SitemapController.php` — sitemap XML routes
- `app/Controllers/Public/FeedController.php` — RSS feed route
- `public/robots.txt` — static robots file
- `tests/php/SeoServiceTest.php` — SeoService unit test

### Files to Modify
- `app/Core/Response.php` — add `xml()` method
- `app/Core/StaticPageRenderer.php` — add meta block injection
- `app/Controllers/Public/NewsController.php` — inject SEO meta for news detail HTML
- `app/Controllers/Public/PrestasiController.php` — inject SEO meta for prestasi detail HTML
- `app/Controllers/Public/PageController.php` — inject SEO meta for static pages
- `bootstrap/app.php` — wire SeoService, SitemapController, FeedController
- `routes/web.php` — add sitemap and feed routes

---

## Task 1: Add `xml()` Response Method

**Files:**
- Modify: `app/Core/Response.php`

- [ ] **Step 1: Add xml() method**

Add after the `json()` method:
```php
public function xml(string $content, int $status = 200, array $headers = []): void
{
    http_response_code($status);
    header('Content-Type: application/xml; charset=UTF-8');
    foreach ($headers as $name => $value) {
        header($name . ': ' . $value);
    }
    echo $content;
}
```

- [ ] **Step 2: Verify PHP lint**

Run: `php -l app/Core/Response.php`
Expected: No syntax errors.

---

## Task 2: Create SeoService

**Files:**
- Create: `app/Services/SeoService.php`
- Create: `app/Services/SeoConfig.php`
- Create: `tests/php/SeoServiceTest.php`

- [ ] **Step 1: Create SeoConfig (static page meta)**

Create `app/Services/SeoConfig.php`:
```php
<?php

declare(strict_types=1);

namespace App\Services;

final class SeoConfig
{
    public const SITE_NAME = 'GenBI Provinsi Jambi';
    public const BASE_URL = 'https://genbijambi.com';
    public const DEFAULT_OG_IMAGE = '/assets/images/default-og-genbi.jpg';
    public const DEFAULT_DESCRIPTION = 'Profil, kegiatan, berita, prestasi, dan agenda GenBI Provinsi Jambi.';

    /** @return array<string, array{title: string, description: string, path: string}> */
    public static function pages(): array
    {
        return [
            'index.html' => [
                'title' => 'GenBI Provinsi Jambi | Generasi Baru Indonesia',
                'description' => 'Website resmi GenBI Provinsi Jambi. Profil organisasi, berita, prestasi, agenda, dan informasi penerima beasiswa Bank Indonesia.',
                'path' => '/',
            ],
            'about.html' => [
                'title' => 'Tentang GenBI Provinsi Jambi',
                'description' => 'Profil organisasi Generasi Baru Indonesia (GenBI) Provinsi Jambi, visi misi, dan sejarah.',
                'path' => '/about',
            ],
            'team.html' => [
                'title' => 'Pengurus dan Anggota GenBI Provinsi Jambi',
                'description' => 'Struktur kepengurusan dan anggota GenBI Provinsi Jambi dari berbagai komisariat.',
                'path' => '/team',
            ],
            'prestasi.html' => [
                'title' => 'Prestasi GenBI Provinsi Jambi',
                'description' => 'Daftar prestasi dan pencapaian anggota GenBI Provinsi Jambi di tingkat regional dan nasional.',
                'path' => '/prestasi',
            ],
            'news.html' => [
                'title' => 'Berita GenBI Provinsi Jambi',
                'description' => 'Berita terbaru seputar kegiatan dan program GenBI Provinsi Jambi.',
                'path' => '/news',
            ],
            'contact.html' => [
                'title' => 'Kontak GenBI Provinsi Jambi',
                'description' => 'Informasi kontak resmi dan alamat sekretariat GenBI Provinsi Jambi.',
                'path' => '/contact',
            ],
        ];
    }
}
```

- [ ] **Step 2: Create SeoService**

Create `app/Services/SeoService.php`:
```php
<?php

declare(strict_types=1);

namespace App\Services;

final class SeoService
{
    public static function forPage(string $file): array
    {
        $pages = SeoConfig::pages();
        $config = $pages[$file] ?? null;

        if (!$config) {
            return self::defaults('/');
        }

        return [
            'title' => $config['title'],
            'description' => $config['description'],
            'canonical' => self::absoluteUrl($config['path']),
            'robots' => 'index, follow',
            'og_type' => 'website',
            'og_title' => $config['title'],
            'og_description' => $config['description'],
            'og_url' => self::absoluteUrl($config['path']),
            'og_image' => self::absoluteUrl(SeoConfig::DEFAULT_OG_IMAGE),
            'og_image_width' => '1200',
            'og_image_height' => '630',
            'og_image_alt' => SeoConfig::SITE_NAME,
            'twitter_card' => 'summary_large_image',
            'twitter_title' => $config['title'],
            'twitter_description' => $config['description'],
            'twitter_image' => self::absoluteUrl(SeoConfig::DEFAULT_OG_IMAGE),
        ];
    }

    public static function forNews(array $news, ?string $categoryName = null): array
    {
        $title = self::pick($news, 'meta_title', 'news_title', 'title') . ' | ' . SeoConfig::SITE_NAME;
        $description = self::cleanDescription(self::pick($news, 'meta_description', 'news_content_short', 'excerpt'));
        $slug = $news['slug'] ?? '';
        $canonical = self::absoluteUrl('/news/' . $slug);
        $image = self::imageUrl(self::pick($news, 'photo', 'banner', 'image'));
        $publishedIso = self::isoDate(self::pick($news, 'published_at', 'news_date', 'date'));
        $modifiedIso = self::isoDate($news['updated_at'] ?? $news['published_at'] ?? '');
        $category = $categoryName ?? $news['category_name'] ?? $news['category'] ?? 'Berita GenBI';

        return [
            'title' => $title,
            'description' => $description,
            'canonical' => $canonical,
            'robots' => 'index, follow',
            'og_type' => 'article',
            'og_title' => $title,
            'og_description' => $description,
            'og_url' => $canonical,
            'og_image' => $image,
            'og_image_width' => '1200',
            'og_image_height' => '630',
            'og_image_alt' => self::pick($news, 'news_title', 'title'),
            'og_article_published' => $publishedIso,
            'og_article_modified' => $modifiedIso,
            'og_article_section' => $category,
            'twitter_card' => 'summary_large_image',
            'twitter_title' => $title,
            'twitter_description' => $description,
            'twitter_image' => $image,
            'twitter_image_alt' => self::pick($news, 'news_title', 'title'),
        ];
    }

    public static function forPrestasi(array $prestasi): array
    {
        $title = ($prestasi['title'] ?? 'Prestasi') . ' | ' . SeoConfig::SITE_NAME;
        $description = self::cleanDescription($prestasi['description'] ?? '');
        $slug = $prestasi['slug'] ?? '';
        $canonical = self::absoluteUrl('/prestasi/' . $slug);
        $image = self::imageUrl($prestasi['image'] ?? '');

        return [
            'title' => $title,
            'description' => $description,
            'canonical' => $canonical,
            'robots' => 'index, follow',
            'og_type' => 'article',
            'og_title' => $title,
            'og_description' => $description,
            'og_url' => $canonical,
            'og_image' => $image,
            'og_image_width' => '1200',
            'og_image_height' => '630',
            'og_image_alt' => $prestasi['title'] ?? 'Prestasi GenBI',
            'twitter_card' => 'summary_large_image',
            'twitter_title' => $title,
            'twitter_description' => $description,
            'twitter_image' => $image,
        ];
    }

    public static function absoluteUrl(string $path): string
    {
        if (str_starts_with($path, 'http://') || str_starts_with($path, 'https://')) {
            return $path;
        }

        return rtrim(SeoConfig::BASE_URL, '/') . '/' . ltrim($path, '/');
    }

    public static function imageUrl(?string $path): string
    {
        if (empty($path)) {
            return self::absoluteUrl(SeoConfig::DEFAULT_OG_IMAGE);
        }

        if (str_starts_with($path, 'http://') || str_starts_with($path, 'https://')) {
            return $path;
        }

        if (!str_starts_with($path, '/')) {
            $path = '/uploads/' . ltrim($path, '/');
        }

        return self::absoluteUrl($path);
    }

    public static function cleanDescription(?string $text, int $limit = 160): string
    {
        if (empty($text)) {
            return SeoConfig::DEFAULT_DESCRIPTION;
        }

        $text = strip_tags($text);
        $text = preg_replace('/\s+/', ' ', $text) ?? $text;
        $text = trim($text);

        if (mb_strlen($text) <= $limit) {
            return $text;
        }

        return mb_substr($text, 0, $limit - 3) . '...';
    }

    public static function isoDate(?string $date): string
    {
        if (empty($date)) {
            return '';
        }

        $ts = strtotime($date);
        if ($ts === false) {
            return '';
        }

        return date('c', $ts);
    }

    public static function renderMetaBlock(array $seo): string
    {
        $e = static fn (?string $v): string => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
        $lines = [];

        $lines[] = '<title>' . $e($seo['title'] ?? '') . '</title>';
        $lines[] = '<meta name="description" content="' . $e($seo['description'] ?? '') . '">';
        $lines[] = '<link rel="canonical" href="' . $e($seo['canonical'] ?? '') . '">';
        $lines[] = '<meta name="robots" content="' . $e($seo['robots'] ?? 'index, follow') . '">';

        // Open Graph
        $lines[] = '<meta property="og:type" content="' . $e($seo['og_type'] ?? 'website') . '">';
        $lines[] = '<meta property="og:site_name" content="' . $e(SeoConfig::SITE_NAME) . '">';
        $lines[] = '<meta property="og:title" content="' . $e($seo['og_title'] ?? '') . '">';
        $lines[] = '<meta property="og:description" content="' . $e($seo['og_description'] ?? '') . '">';
        $lines[] = '<meta property="og:url" content="' . $e($seo['og_url'] ?? '') . '">';
        $lines[] = '<meta property="og:image" content="' . $e($seo['og_image'] ?? '') . '">';
        $lines[] = '<meta property="og:image:width" content="' . $e($seo['og_image_width'] ?? '1200') . '">';
        $lines[] = '<meta property="og:image:height" content="' . $e($seo['og_image_height'] ?? '630') . '">';
        $lines[] = '<meta property="og:image:alt" content="' . $e($seo['og_image_alt'] ?? '') . '">';

        if (!empty($seo['og_article_published'])) {
            $lines[] = '<meta property="article:published_time" content="' . $e($seo['og_article_published']) . '">';
        }
        if (!empty($seo['og_article_modified'])) {
            $lines[] = '<meta property="article:modified_time" content="' . $e($seo['og_article_modified']) . '">';
        }
        if (!empty($seo['og_article_section'])) {
            $lines[] = '<meta property="article:section" content="' . $e($seo['og_article_section']) . '">';
        }

        // Twitter Card
        $lines[] = '<meta name="twitter:card" content="' . $e($seo['twitter_card'] ?? 'summary_large_image') . '">';
        $lines[] = '<meta name="twitter:title" content="' . $e($seo['twitter_title'] ?? '') . '">';
        $lines[] = '<meta name="twitter:description" content="' . $e($seo['twitter_description'] ?? '') . '">';
        $lines[] = '<meta name="twitter:image" content="' . $e($seo['twitter_image'] ?? '') . '">';
        if (!empty($seo['twitter_image_alt'])) {
            $lines[] = '<meta name="twitter:image:alt" content="' . $e($seo['twitter_image_alt']) . '">';
        }

        // RSS feed link
        $lines[] = '<link rel="alternate" type="application/rss+xml" title="Berita ' . $e(SeoConfig::SITE_NAME) . '" href="' . $e(self::absoluteUrl('/feed.xml')) . '">';

        return implode(PHP_EOL . '  ', $lines);
    }

    private static function pick(array $data, string ...$keys): string
    {
        foreach ($keys as $key) {
            if (!empty($data[$key])) {
                return (string) $data[$key];
            }
        }
        return '';
    }

    private static function defaults(string $path): array
    {
        return [
            'title' => SeoConfig::SITE_NAME,
            'description' => SeoConfig::DEFAULT_DESCRIPTION,
            'canonical' => self::absoluteUrl($path),
            'robots' => 'index, follow',
            'og_type' => 'website',
            'og_title' => SeoConfig::SITE_NAME,
            'og_description' => SeoConfig::DEFAULT_DESCRIPTION,
            'og_url' => self::absoluteUrl($path),
            'og_image' => self::absoluteUrl(SeoConfig::DEFAULT_OG_IMAGE),
            'og_image_width' => '1200',
            'og_image_height' => '630',
            'og_image_alt' => SeoConfig::SITE_NAME,
            'twitter_card' => 'summary_large_image',
            'twitter_title' => SeoConfig::SITE_NAME,
            'twitter_description' => SeoConfig::DEFAULT_DESCRIPTION,
            'twitter_image' => self::absoluteUrl(SeoConfig::DEFAULT_OG_IMAGE),
        ];
    }
}
```

- [ ] **Step 3: Create SeoService test**

Create `tests/php/SeoServiceTest.php` — tests for `forPage()`, `forNews()`, `forPrestasi()`, `cleanDescription()`, `isoDate()`, `imageUrl()`, `absoluteUrl()`, and `renderMetaBlock()`.

- [ ] **Step 4: Run test**

Run: `php -d zend.assertions=1 -d assert.exception=1 tests/php/SeoServiceTest.php`
Expected: Pass.

---

## Task 3: Extend StaticPageRenderer for Meta Injection

**Files:**
- Modify: `app/Core/StaticPageRenderer.php`

- [ ] **Step 1: Add meta injection support**

Add handling for `$options['meta']` that replaces the existing `<title>...</title>` and injects the full meta block before `</head>`:

```php
if (!empty($options['meta']) && is_string($options['meta'])) {
    // Remove existing <title>...</title> to avoid duplicate
    $html = preg_replace('/<title>[^<]*<\/title>/', '', $html, 1) ?? $html;
    // Remove existing <meta name="description"...> to avoid duplicate
    $html = preg_replace('/<meta\s+name="description"[^>]*>/', '', $html, 1) ?? $html;
    // Inject full meta block before </head>
    $html = str_replace('</head>', '  ' . $options['meta'] . PHP_EOL . '</head>', $html);
}
```

- [ ] **Step 2: Verify PHP lint**

Run: `php -l app/Core/StaticPageRenderer.php`

---

## Task 4: Update Controllers to Inject SEO Meta

**Files:**
- Modify: `app/Controllers/Public/PageController.php`
- Modify: `app/Controllers/Public/NewsController.php`
- Modify: `app/Controllers/Public/PrestasiController.php`

- [ ] **Step 1: Update PageController to inject page-level SEO**

```php
public function show(Request $request, Response $response, string $file): void
{
    $seo = \App\Services\SeoService::forPage($file);
    $meta = \App\Services\SeoService::renderMetaBlock($seo);
    $response->html($this->renderer->render($file, ['meta' => $meta]));
}
```

- [ ] **Step 2: Update NewsController::show() for HTML requests**

When not JSON, fetch news from DB (if available), generate SEO meta, and inject:

```php
// In show() for HTML rendering:
$seo = null;
$item = $this->readFromDatabase(static fn (News $news): ?array => $news->findBySlug($slug));
if (is_array($item)) {
    $seo = \App\Services\SeoService::forNews($item);
}
$meta = $seo ? \App\Services\SeoService::renderMetaBlock($seo) : \App\Services\SeoService::renderMetaBlock(\App\Services\SeoService::forPage('news.html'));
$response->html($this->renderer->render('news-detail.html', ['slug' => $slug, 'meta' => $meta]));
```

- [ ] **Step 3: Update PrestasiController::show() and index()**

Similar pattern for prestasi detail and list pages.

- [ ] **Step 4: Verify PHP lint on all modified controllers**

---

## Task 5: Create SitemapController

**Files:**
- Create: `app/Controllers/Public/SitemapController.php`

- [ ] **Step 1: Create SitemapController**

Methods: `index()` (sitemap index), `pages()`, `news()`, `prestasi()`.

Each generates XML string and calls `$response->xml(...)`.

- [ ] **Step 2: Verify PHP lint**

---

## Task 6: Create FeedController

**Files:**
- Create: `app/Controllers/Public/FeedController.php`

- [ ] **Step 1: Create FeedController**

Method: `news()` — generates RSS 2.0 XML with latest published news.

- [ ] **Step 2: Verify PHP lint**

---

## Task 7: Add robots.txt

**Files:**
- Create: `public/robots.txt`

- [ ] **Step 1: Create robots.txt**

Content per CONFIGS.md specification.

---

## Task 8: Wire Routes and Bootstrap

**Files:**
- Modify: `bootstrap/app.php`
- Modify: `routes/web.php`

- [ ] **Step 1: Wire SitemapController and FeedController in bootstrap**

- [ ] **Step 2: Add routes**

```
GET /robots.txt        -> serve static file (already handled by PHP built-in server)
GET /sitemap.xml       -> sitemapController->index()
GET /sitemap-pages.xml -> sitemapController->pages()
GET /sitemap-news.xml  -> sitemapController->news()
GET /sitemap-prestasi.xml -> sitemapController->prestasi()
GET /feed.xml          -> feedController->news()
```

- [ ] **Step 3: Verify PHP lint**

---

## Task 9: Full Verification

- [ ] **Step 1: Run all PHP tests**
- [ ] **Step 2: Run npm test**
- [ ] **Step 3: Smoke test SEO meta injection**
- [ ] **Step 4: Smoke test sitemap/feed routes**
- [ ] **Step 5: Update docs/PROJECT_PROGRESS.md**
- [ ] **Step 6: Create report**
- [ ] **Step 7: Notify user**

---

## Execution Order

1. Task 1: Add `xml()` response method
2. Task 2: Create SeoService + SeoConfig + test
3. Task 3: Extend StaticPageRenderer
4. Task 4: Update controllers
5. Task 5: Create SitemapController
6. Task 6: Create FeedController
7. Task 7: Add robots.txt
8. Task 8: Wire routes
9. Task 9: Full verification
