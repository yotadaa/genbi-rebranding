# News Detail Share/Comment Single-Column Layout Fix

> **For agentic workers:** Use executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix news detail page so share and comment sections stack vertically (single column) and share buttons use canonical slug URLs instead of `location.href`.

**Architecture:** Remove the two-column CSS grid on `.news-engagement-grid`, update share button URLs to use the canonical `/news/{slug}` format constructed from the item's slug, and update Copy Link to copy the canonical URL.

**Tech Stack:** CSS (styles.css), vanilla JS (news-detail.js, api-core.js)

---

## File Map

| File | Action | Responsibility |
|------|--------|----------------|
| `public/assets/css/styles.css:3004-3008` | Modify | Remove two-column grid media query |
| `public/assets/js/pages/news-detail.js:52-54,116` | Modify | Use canonical slug URL in share buttons and copy link |
| `public/assets/js/api-core.js` | Modify | Export a `canonicalNewsUrl(item)` helper for absolute canonical URL |
| `tests/api-core.test.js` | Modify | Add test for `canonicalNewsUrl` |

---

### Task 1: Add `canonicalNewsUrl` helper to api-core.js

**Files:**
- Modify: `public/assets/js/api-core.js:227-230`
- Test: `tests/api-core.test.js`

- [ ] **Step 1: Write the failing test**

Add to `tests/api-core.test.js`:

```javascript
test('canonicalNewsUrl returns absolute canonical slug URL', () => {
  const Core = require('../public/assets/js/api-core.js');
  // Backend-shaped item
  assert.strictEqual(
    Core.canonicalNewsUrl({ slug: 'talkshow-siginjai-fest', news_id: 5 }),
    'https://genbijambi.com/news/talkshow-siginjai-fest'
  );
  // Frontend-shaped item (already normalized)
  assert.strictEqual(
    Core.canonicalNewsUrl({ slug: 'genbi-peka-2025-3', id: 3 }),
    'https://genbijambi.com/news/genbi-peka-2025-3'
  );
  // Fallback when no slug
  assert.strictEqual(
    Core.canonicalNewsUrl({ news_title: 'Hello World', news_id: 99 }),
    'https://genbijambi.com/news/hello-world-99'
  );
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `npm test`
Expected: FAIL with "Core.canonicalNewsUrl is not a function"

- [ ] **Step 3: Implement `canonicalNewsUrl` in api-core.js**

Add after the `newsDetailUrl` function (line 230) in `public/assets/js/api-core.js`:

```javascript
  function canonicalNewsUrl(news) {
    const item = normalizeNews(news || {});
    return `https://genbijambi.com/news/${encodeURIComponent(item.slug)}`;
  }
```

And add `canonicalNewsUrl` to the return object.

- [ ] **Step 4: Run test to verify it passes**

Run: `npm test`
Expected: 18 tests PASS

- [ ] **Step 5: Commit**

```bash
git add public/assets/js/api-core.js tests/api-core.test.js
git commit -m "feat: add canonicalNewsUrl helper for share button URLs"
```

---

### Task 2: Fix share buttons to use canonical URL

**Files:**
- Modify: `public/assets/js/pages/news-detail.js:51-56,112-118`

- [ ] **Step 1: Update share button HTML generation (lines 51-56)**

Replace the share button section with canonical URL construction:

```javascript
              const shareUrl = window.GenBIAPICore.canonicalNewsUrl(item);
```

Then use `shareUrl` in the button `data-share-url` attributes:

```javascript
              <button class="share-button" data-share-url="https://wa.me/?text=${encodeURIComponent(item.title)}%20${encodeURIComponent(shareUrl)}">WhatsApp</button>
              <button class="share-button" data-share-url="https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}">Facebook</button>
              <button class="share-button" data-share-url="https://twitter.com/intent/tweet?text=${encodeURIComponent(item.title)}&url=${encodeURIComponent(shareUrl)}">X</button>
              <button class="share-button" data-copy data-canonical="${shareUrl}">Copy Link</button>
```

- [ ] **Step 2: Update Copy Link handler (line 115-118)**

Change from `location.href` to reading the canonical URL from the button's data attribute:

```javascript
  root.querySelector('[data-copy]')?.addEventListener('click', async (event) => {
    const canonical = event.currentTarget.dataset.canonical || location.href;
    try { await navigator.clipboard.writeText(canonical); showMiniToast('Link artikel disalin'); }
    catch { showMiniToast('Copy link disimulasikan'); }
  });
```

- [ ] **Step 3: Run tests**

Run: `npm test`
Expected: 18 tests PASS (no regression)

- [ ] **Step 4: Commit**

```bash
git add public/assets/js/pages/news-detail.js
git commit -m "fix: share buttons use canonical slug URL instead of location.href"
```

---

### Task 3: Fix CSS layout to single column

**Files:**
- Modify: `public/assets/css/styles.css:3004-3008`

- [ ] **Step 1: Remove the two-column grid media query**

Delete or comment out lines 3004-3008:

```css
@media (min-width: 980px) {
  .news-engagement-grid {
    grid-template-columns: 0.9fr 1.1fr;
  }
}
```

Replace with a max-width constraint to keep the single column readable:

```css
.news-engagement-grid {
  display: grid;
  gap: 1.5rem;
  max-width: 48rem;
}
```

- [ ] **Step 2: Run Tailwind build (if available) or verify CSS is valid**

Run: `npm run build:css` (may fail due to missing tailwindcss binary -- acceptable)
Alternative: visually verify the CSS is syntactically correct.

- [ ] **Step 3: Run tests**

Run: `npm test`
Expected: 18 tests PASS

- [ ] **Step 4: Commit**

```bash
git add public/assets/css/styles.css
git commit -m "fix: news detail share/comment section uses single-column layout

Removes the two-column grid (0.9fr 1.1fr) at 980px breakpoint.
Share and comment sections now stack vertically per BLUEPRINTS.md requirement.
Adds max-width constraint for readability on wide screens."
```

---

### Task 4: Final verification and combined commit (optional squash)

- [ ] **Step 1: Run full test suite**

Run: `npm test && for f in tests/php/*.php; do php -d zend.assertions=1 -d assert.exception=1 "$f"; done`
Expected: 18 JS tests + 7 PHP suites PASS

- [ ] **Step 2: Verify acceptance criteria**

Check against PROBLEMS.md lines 596-600:
- [x] Share section tampil 1 column
- [x] Comment section tampil 1 column
- [x] Copy link berfungsi (uses canonical URL)

Check against BLUEPRINTS.md line 1418:
- [x] Share dan komentar tampil dalam satu kolom, bukan grid dua kolom

Check against NEWS-SHARE.md section 9:
- [x] Share button pakai canonical slug URL
- [x] WhatsApp: `https://wa.me/?text={title} {canonical}`
- [x] Facebook: `https://www.facebook.com/sharer/sharer.php?u={canonical}`
- [x] X: `https://twitter.com/intent/tweet?url={canonical}&text={title}`
- [x] Copy Link: copies canonical URL to clipboard

---

## Summary

| Requirement | Source | Fix |
|---|---|---|
| Single-column layout | BLUEPRINTS.md:1418, PROBLEMS.md:596-597 | Remove `grid-template-columns: 0.9fr 1.1fr` |
| Canonical share URLs | NEWS-SHARE.md:459, BLUEPRINTS.md:1421 | Use `canonicalNewsUrl(item)` instead of `location.href` |
| Copy Link uses canonical | NEWS-SHARE.md:315 | Read from `data-canonical` attribute |
