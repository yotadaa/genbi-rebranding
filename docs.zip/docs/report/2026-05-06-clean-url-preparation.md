# Clean URL Preparation Report

Date: 2026-05-06

## Summary

Prepared the static prototype for professional backend URLs by generating clean public and admin paths without `.html` or `.php` when served over `http:` or `https:`.

## Implemented

- Added URL helpers in `assets/js/api-core.js`:
  - `pageUrl(page, locationLike)`
  - `newsDetailUrl(news, locationLike)`
  - `adminUrl(page, locationLike)`
- Preserved direct static-file preview behavior under `file://`:
  - Public pages still resolve to `*.html`.
  - News detail still resolves to `news-detail.html?slug=...&id=...`.
  - Admin pages still resolve to `admin/*.html`.
- Updated `assets/js/app.js` to expose URL helpers through `window.GenBIApp`.
- Updated public navigation and generated page links to prefer clean paths such as:
  - `/about`
  - `/team`
  - `/prestasi`
  - `/news`
  - `/news/{slug}`
  - `/contact`
- Updated admin navigation and generated CMS links to prefer clean paths such as:
  - `/admin/dashboard`
  - `/admin/news`
  - `/admin/news-edit?id=...`
  - `/admin/comment`
- Added regression tests for clean URL generation.

## Verification

- `npm test` passed.
- Result: 16 passing tests, 0 failures.

## Notes

- This does not add PHP routing yet. The future PHP router must serve these clean paths from `/public/index.php`.
- Static `file://` previews intentionally keep `.html` paths because browsers cannot resolve clean routes from the filesystem.
- `npm run build:css` was not required for this phase because no Tailwind classes were added and the Tailwind binary remains unavailable in `node_modules/.bin`.
