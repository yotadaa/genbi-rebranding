# SEO/Canonical/Share Metadata + Sitemap/Feed Report

Date: 2026-05-06

## Summary

Implemented the complete SEO metadata system: server-side meta tag injection (title, description, canonical, Open Graph, Twitter Card), dynamic XML sitemaps, RSS feed, and robots.txt. This completes the final P2 item from the progress tracker — all planned integration tasks are now done.

## What Was Built

### 1. SeoService (`app/Services/SeoService.php`)

Pure data mapper with static methods:
- `forPage(string $file)` — returns meta array for static pages (home, about, team, etc.)
- `forNews(array $news)` — returns article-type meta with OG timestamps, section, image fallback
- `forPrestasi(array $prestasi)` — returns article-type meta for prestasi detail
- `absoluteUrl(string $path)` — converts relative paths to `https://genbijambi.com/...`
- `imageUrl(?string $path)` — resolves image to absolute URL with default OG fallback
- `cleanDescription(?string $text, int $limit = 160)` — strips HTML, truncates with `...`
- `isoDate(?string $date)` — converts date strings to ISO 8601
- `renderMetaBlock(array $seo)` — generates full HTML meta block string

### 2. SeoConfig (`app/Services/SeoConfig.php`)

Constants and static page configuration:
- `SITE_NAME` = "GenBI Provinsi Jambi"
- `BASE_URL` = "https://genbijambi.com"
- `DEFAULT_OG_IMAGE` = "/assets/images/default-og-genbi.jpg"
- `DEFAULT_DESCRIPTION` = site-wide fallback
- `pages()` — returns title/description/path for each static page

### 3. Meta Injection in StaticPageRenderer

Extended `render()` to accept `$options['meta']`:
- Removes existing `<title>` tag to avoid duplicates
- Removes existing `<meta name="description">` to avoid duplicates
- Injects full meta block before `</head>`

### 4. Controller Updates

| Controller | Change |
|-----------|--------|
| `PageController` | Now calls `SeoService::forPage()` and injects meta for all static pages |
| `NewsController` | Fetches news from DB for HTML requests, injects article-type OG/Twitter meta |
| `PrestasiController` | Injects prestasi-specific meta for detail; `noindex` for token submission form |

Also fixed a bug in `PrestasiController` where `$this->renderer->render($response, 'prestasi.html')` was passing arguments in wrong order.

### 5. SitemapController (`app/Controllers/Public/SitemapController.php`)

| Route | Method | Content |
|-------|--------|---------|
| `/sitemap.xml` | `index()` | Sitemap index referencing pages/news/prestasi sitemaps |
| `/sitemap-pages.xml` | `pages()` | Static pages with priority and changefreq |
| `/sitemap-news.xml` | `news()` | Published news with image:image extension |
| `/sitemap-prestasi.xml` | `prestasi()` | Published prestasi entries |

### 6. FeedController (`app/Controllers/Public/FeedController.php`)

| Route | Content |
|-------|---------|
| `/feed.xml` | RSS 2.0 feed with latest published news, atom:link self-reference, enclosure for images |

### 7. robots.txt (`public/robots.txt`)

Per CONFIGS.md specification:
- Allows `/`, `/assets/`, `/uploads/`
- Disallows `/admin/`, `/api/`, `/prestasi/submit/`, search params, internal paths
- References `Sitemap: https://genbijambi.com/sitemap.xml`

### 8. Static File Serving

Added handling in `public/index.php` for `robots.txt`, `favicon.ico`, `manifest.webmanifest`, `browserconfig.xml` — files that live in `public/` but need explicit serving when using the PHP router script.

### 9. Response::xml()

Added `xml(string $content, int $status, array $headers)` method to `app/Core/Response.php` for sitemap/feed output.

## Meta Tags Injected Per Page

| Page | Title | Canonical | OG Type | Robots |
|------|-------|-----------|---------|--------|
| `/` | GenBI Provinsi Jambi \| Generasi Baru Indonesia | https://genbijambi.com/ | website | index, follow |
| `/about` | Tentang GenBI Provinsi Jambi | https://genbijambi.com/about | website | index, follow |
| `/team` | Pengurus dan Anggota GenBI Provinsi Jambi | https://genbijambi.com/team | website | index, follow |
| `/prestasi` | Prestasi GenBI Provinsi Jambi | https://genbijambi.com/prestasi | website | index, follow |
| `/news` | Berita GenBI Provinsi Jambi | https://genbijambi.com/news | website | index, follow |
| `/news/{slug}` | {news_title} \| GenBI Provinsi Jambi | https://genbijambi.com/news/{slug} | article | index, follow |
| `/prestasi/{slug}` | {title} \| GenBI Provinsi Jambi | https://genbijambi.com/prestasi/{slug} | article | index, follow |
| `/prestasi/submit/{token}` | (prestasi page) | — | — | noindex, nofollow |
| `/admin/*` | — | — | — | noindex, nofollow (via X-Robots-Tag header) |

## News Share Preview Behavior

When a news URL is shared:
- **Title:** `meta_title` if set, else `news_title`, appended with " | GenBI Provinsi Jambi"
- **Description:** `meta_description` if set, else `news_content_short`, truncated to 160 chars
- **Image:** `photo` if set, else `banner`, else default OG image — always absolute URL
- **URL:** Canonical slug URL `https://genbijambi.com/news/{slug}`
- **Type:** `article` with `published_time`, `modified_time`, and `section`

## Verification

| Check | Result |
|-------|--------|
| PHP lint (12 files) | All pass |
| `tests/php/SeoServiceTest.php` | Pass |
| `tests/php/FoundationTest.php` | Pass |
| `tests/php/MigrationRunnerTest.php` | Pass |
| `tests/php/NewsModelTest.php` | Pass |
| `tests/php/NewsCommentModelTest.php` | Pass |
| `tests/php/PrestasiModelTest.php` | Pass |
| `npm test` (17 JS tests) | All pass |
| Route `/sitemap.xml` | 200, valid XML |
| Route `/sitemap-pages.xml` | 200, valid XML |
| Route `/sitemap-news.xml` | 200, valid XML |
| Route `/sitemap-prestasi.xml` | 200, valid XML |
| Route `/feed.xml` | 200, valid RSS 2.0 |
| Route `/robots.txt` | 200, correct content |
| Homepage meta injection | title, canonical, og:title, twitter:card, feed link present |
| About page title | "Tentang GenBI Provinsi Jambi" |
| Token form noindex | `noindex, nofollow` meta present |

## Files Created

- `app/Services/SeoConfig.php`
- `app/Services/SeoService.php`
- `app/Controllers/Public/SitemapController.php`
- `app/Controllers/Public/FeedController.php`
- `public/robots.txt`
- `tests/php/SeoServiceTest.php`

## Files Modified

- `app/Core/Response.php` — added `xml()` method
- `app/Core/StaticPageRenderer.php` — added `meta` option for meta block injection
- `app/Controllers/Public/PageController.php` — injects page-level SEO
- `app/Controllers/Public/NewsController.php` — injects news article SEO
- `app/Controllers/Public/PrestasiController.php` — injects prestasi SEO + fixed render bug
- `bootstrap/app.php` — wired SitemapController and FeedController
- `routes/web.php` — added sitemap and feed routes
- `public/index.php` — added static file serving for robots.txt etc.

## Notes

- When DB is unavailable, news/prestasi detail pages fall back to the generic news/prestasi list page meta (not article-type). This is acceptable for the static prototype phase.
- The default OG image (`/assets/images/default-og-genbi.jpg`) does not physically exist yet. A 1200x630 GenBI-branded image should be created and placed there before production.
- Structured data JSON-LD (Organization, NewsArticle, BreadcrumbList schemas) is not yet implemented — this can be added as a follow-up enhancement.
- The RSS feed and sitemaps return empty content when DB is unavailable (no items). This is correct fallback behavior.

## Progress Status

**All P0, P1, and P2 items from the progress tracker are now COMPLETE.**

Remaining work for production readiness (not tracked as P2):
- Admin authentication (Phase 2 from BLUEPRINTS.md)
- CSRF protection for POST routes
- Structured data JSON-LD
- Default OG image creation
- Database migration execution on production
- Full browser/manual acceptance testing
