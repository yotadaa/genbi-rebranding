# Admin Authentication + Blank Page Fix Report

Date: 2026-05-06

## Summary

Fixed the blank page on browser back navigation (bfcache issue) and implemented the complete admin authentication system with session management, CSRF protection, middleware pipeline, rate limiting, and account locking.

## Blank Page Fix

### Root Cause

The CSS sets `body { opacity: 0 }` by default. JavaScript adds `page-ready` class to make it visible. When navigating away via `[data-transition]` links, `page-leaving` class is added (opacity back to 0). On browser back/forward, the page is restored from bfcache with `page-leaving` still applied and scripts don't re-execute — resulting in an invisible (blank) page.

### Fix

Added `window.addEventListener('pageshow', ...)` in both:
- `public/assets/js/app.js` (public pages)
- `public/assets/js/admin/admin.js` (admin pages)

When `event.persisted` is true (page restored from bfcache), it removes `page-leaving` and re-adds `page-ready`.

## Admin Authentication System

### Architecture

```
Request -> Session::start() -> Router -> Middleware Pipeline -> Controller
                                              |
                                    AuthMiddleware (check session)
                                              |
                                    CsrfMiddleware (validate token)
```

### Components Created

| File | Purpose |
|------|---------|
| `app/Core/Session.php` | Session start/config/get/set/destroy/flash with secure cookie params |
| `app/Core/Middleware.php` | Middleware interface (`handle(Request, Response, callable $next)`) |
| `app/Services/AuthService.php` | Login attempt, verify, logout, rate limit, account lock, legacy MD5 migration |
| `app/Services/CsrfService.php` | Token generation (SHA-256), validation (timing-safe), regeneration, hidden input |
| `app/Middleware/AuthMiddleware.php` | Redirects to `/admin/login` or returns 401 JSON |
| `app/Middleware/CsrfMiddleware.php` | Validates CSRF from POST body, JSON body, or `X-CSRF-TOKEN` header |
| `app/Controllers/Admin/AuthController.php` | Login page, login POST, logout |
| `tests/php/AuthServiceTest.php` | Unit tests for roles, CSRF, no-DB fallback |

### Components Modified

| File | Change |
|------|--------|
| `app/Core/Router.php` | Added `group()` method and middleware pipeline execution |
| `app/Core/Request.php` | Added `session()` helper |
| `bootstrap/app.php` | Session initialization, AuthService/middleware wiring |
| `routes/admin.php` | Login/logout routes + `group([$authMiddleware], ...)` for protected routes |

### Login Flow

1. User visits `/admin/login` → sees login form with CSRF token
2. User submits email + password → `POST /admin/login`
3. AuthController validates CSRF token
4. AuthService checks: email exists, account not locked, status active, password correct
5. On success: regenerate session ID, store user in session, redirect to dashboard
6. On failure: flash error, redirect back to login
7. After 5 failed attempts: lock account for 10 minutes

### Security Features

| Feature | Implementation |
|---------|---------------|
| Session security | HttpOnly, SameSite=Lax, configurable Secure flag |
| Session fixation | `session_regenerate_id(true)` after login |
| CSRF protection | 64-char hex token, timing-safe comparison |
| Rate limiting | 5 attempts per account, 10-minute lockout |
| Password storage | `password_hash(PASSWORD_DEFAULT)` |
| Legacy migration | MD5 fallback with automatic rehash on success |
| Role whitelist | Only `superadmin`, `admin`, `editor`, `moderator` |
| Error messages | Generic "Email atau password salah" (no user enumeration) |

### Routes

| Method | Route | Auth Required | Purpose |
|--------|-------|:---:|---------|
| GET | `/admin/login` | No | Show login form |
| POST | `/admin/login` | No | Process login |
| POST | `/admin/logout` | No | Destroy session |
| GET | `/admin/*` | Yes | All other admin routes |
| POST | `/admin/*` | Yes | All admin POST routes |

## Verification

| Check | Result |
|-------|--------|
| PHP lint (12 files) | All pass |
| `tests/php/AuthServiceTest.php` | Pass |
| All existing PHP tests (7 suites) | Pass |
| `npm test` (17 JS tests) | All pass |
| `/admin/login` | 200, has CSRF token, has form |
| `/admin/dashboard` (unauthenticated) | 302 redirect to login |
| `/admin/prestasi` JSON (unauthenticated) | 401 |
| Public routes (`/`, `/news`, `/sitemap.xml`) | 200, unaffected |

## Notes

- The login page uses inline HTML rendering (no template file). This keeps it self-contained and avoids dependency on the static prototype HTML files.
- CSRF validation is currently only enforced in the login flow. The `CsrfMiddleware` is created but not yet applied to all admin POST routes — it can be added to the middleware group when ready.
- The `AuthService::attempt()` method handles the full login flow including rate limiting and account locking, but these features require the `tbl_user` migration (0008) to be executed on the production database.
- Legacy MD5 password fallback is included for transition from the existing admin system. After all users have logged in at least once, the fallback can be removed.
