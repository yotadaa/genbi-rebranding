# PHP News Model Foundation Report

Date: 2026-05-06

## Summary

Added the first database-backed model foundation for public News while preserving the existing static HTML rendering and frontend fallback behavior. `/news` and `/news/{slug}` now support JSON responses when requested by the frontend adapter.

## Implemented

- Added request/response support for API-style negotiation:
  - `Request::acceptsJson()`
  - `Response::json()`
- Added slug helper:
  - `app/Core/Slugger.php`
- Added News model:
  - `app/Models/News.php`
- Updated public News controller:
  - `app/Controllers/Public/NewsController.php`
- Updated bootstrap to inject the News model when the database connection is available:
  - `bootstrap/app.php`
- Added PHP model mapping test:
  - `tests/php/NewsModelTest.php`

## Route Behavior

Browser HTML visits still render the static prototype pages:

- `GET /news` -> `news.html`
- `GET /news/{slug}` -> `news-detail.html`

Frontend/API-style requests now use database-backed JSON when available:

- `GET /news` with `Accept: application/json` returns `{ "data": [...] }`.
- `GET /news/{slug}` with `Accept: application/json` returns one mapped news item or `404` JSON.

Legacy route behavior improved:

- `GET /news/id/{id}` redirects to `/news/{slug}` if the database row exists.
- If the database is unavailable or the row is missing, it falls back to `/news-detail.html?id={id}`.

## News Model Mapping

The model maps `tbl_news` and optional `tbl_category` fields into the frontend-compatible shape:

- `news_id` -> `id`, `news_id`
- `slug` or generated slug fallback
- `news_title` -> `title`, `news_title`
- `news_content` -> `content`, `news_content`
- `news_content_short`/`meta_description` -> `excerpt`
- `published_at`/`news_date`/`created_at` -> `date`
- `photo`/`banner` -> `image`
- `category_name` -> `category`
- contributor fields -> `author`, `editor`
- SEO fields preserved for later metadata rendering

## Verification

- PHP lint passed for:
  - `app/Core/Request.php`
  - `app/Core/Response.php`
  - `app/Core/Slugger.php`
  - `app/Models/News.php`
  - `app/Controllers/Public/NewsController.php`
  - `bootstrap/app.php`
  - `tests/php/NewsModelTest.php`
- PHP News model test passed.
- PHP route smoke test passed for:
  - `/news`
  - `/news/example-slug-1`
  - `/news/id/100`
  - `/news` with `Accept: application/json`
- Frontend test suite passed:
  - `npm test`
  - Result: 17 passing tests, 0 failures.

## Notes

- In this environment, no live production database was used. The controller safely falls back to static HTML rendering if the database connection is unavailable.
- The next logical backend phase is `NewsComment` model and backend endpoints for approved public comments plus admin moderation actions.
