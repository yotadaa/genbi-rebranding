# PHP Assets, Git Init, and News Comments Foundation Report

Date: 2026-05-06

## Summary

Fixed missing CSS/JS when previewing through the PHP public root, initialized a Git repository with Markdown/docs ignored as requested, and added the PHP NewsComment backend foundation for public comments and admin moderation routes.

## CSS/Asset Fix

### Root Cause

The PHP built-in server was being run with `-t public`, but the actual frontend assets still live in the project root under `assets/`. Requests like `/assets/css/tailwind.css` did not map to a real file under `public/`, so the page loaded unstyled.

### Implemented

- Added an asset bridge in `public/index.php` for `/assets/*`.
- The bridge safely serves files from the project root `assets/` directory with correct content types.
- Added script:

```bash
npm run serve:php
```

which runs:

```bash
php -S 127.0.0.1:8000 -t public public/index.php
```

Use this for PHP preview so asset fallback routing goes through `public/index.php`.

## Git Init

- Initialized Git repository.
- Added `.gitignore`.
- Ignored Markdown files and docs per request:
  - `*.md`
  - `docs/`
- Also ignored:
  - `.env` and `.env.*` except `.env.example`
  - `node_modules/`
  - `vendor/`
  - runtime logs/cache/sessions except `.gitkeep`
  - editor/OS noise

## News Comments Backend Foundation

Added model and controllers:

- `app/Models/NewsComment.php`
- `app/Controllers/Public/CommentController.php`
- `app/Controllers/Admin/NewsCommentController.php`

Added routes:

- `GET /news/{slug}/comments`
- `POST /news/{slug}/comment`
- `GET /admin/news-comments`
- `POST /admin/news-comments/{id}/approve`
- `POST /admin/news-comments/{id}/reject`
- `POST /admin/news-comments/{id}/delete`

Added test:

- `tests/php/NewsCommentModelTest.php`

## Verification

- PHP lint passed for changed and new PHP files.
- PHP NewsComment model test passed.
- PHP asset smoke test passed for:
  - `/assets/css/tailwind.css`
  - `/assets/css/styles.css`
  - `/assets/js/app.js`
  - `/assets/js/api-core.js`
- PHP comment route smoke test passed for fallback behavior.
- Git ignore check confirmed Markdown/docs and `node_modules/` are ignored.
- Existing tests passed:
  - `NewsModelTest.php`
  - `MigrationRunnerTest.php`
  - `FoundationTest.php`
  - `npm test` with 17 passing tests

## Notes

- The asset bridge is a local/development convenience. For production cPanel, the cleanest setup is to deploy/copy `assets/` into `public/assets/` or configure deployment to sync it there.
- News comment routes currently fall back safely when the database is unavailable.
- Real admin auth/CSRF enforcement is still pending and must be added before production use.
