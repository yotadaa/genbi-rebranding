# Prestasi Backend Foundation and Path Fixes Report

Date: 2026-05-06

## Summary

Fixed critical broken test/tool/config paths caused by `assets/` -> `public/assets/` relocation, and added the complete PHP Prestasi backend foundation including models, controllers, routes, and token system.

## Critical Fixes

### 1. Broken `npm test` (17 tests failing)

**Root Cause:** The `assets/` directory was relocated to `public/assets/` at some point, but `tests/api-core.test.js` and `tools/static-server.js` still required modules from `../assets/js/api-core.js`.

**Fix:**
- `tests/api-core.test.js` → `require('../public/assets/js/api-core.js')`
- `tools/static-server.js` → `require('../public/assets/js/api-core.js')`

### 2. Tailwind Config Scanning Non-Existent Path

**Root Cause:** `tailwind.config.js` content array included `./assets/js/**/*.js` which no longer exists.

**Fix:** Changed to `./public/assets/js/**/*.js`.

### 3. PHP Asset Bridge Using Wrong Base Directory

**Root Cause:** `public/index.php` asset bridge used `dirname(__DIR__) . '/assets'` (project root) but assets now live at `__DIR__ . '/assets'` (inside `public/`).

**Fix:** Changed to `__DIR__ . $path` and `__DIR__ . '/assets'`.

## Prestasi Backend Foundation

### Models Created

| File | Purpose |
|------|---------|
| `app/Models/Prestasi.php` | `tbl_prestasi` CRUD: mapRow, published, findBySlug, findById, all, create, update, softDelete |
| `app/Models/PrestasiToken.php` | `tbl_prestasi_submission_token`: mapRow, generate (SHA-256 hash), validateToken, markUsed, revoke, all |

### Controllers Created

| File | Purpose |
|------|---------|
| `app/Controllers/Public/PrestasiController.php` | Public list (JSON/HTML), detail by slug, token submission form, token-authenticated submit |
| `app/Controllers/Admin/PrestasiController.php` | Admin CRUD: list all, show by ID, store, update, soft delete |
| `app/Controllers/Admin/PrestasiTokenController.php` | Admin token management: list, generate (plain shown once), revoke |

### Routes Added

**Public (`routes/web.php`):**
| Method | Route | Behavior |
|--------|-------|----------|
| GET | `/prestasi` | JSON list or HTML page |
| GET | `/prestasi/{slug}` | JSON detail or HTML page |
| GET | `/prestasi/submit/{token}` | Validate token (JSON) or render form |
| POST | `/prestasi/submit/{token}` | Submit prestasi with valid token |

**Admin (`routes/admin.php`):**
| Method | Route | Behavior |
|--------|-------|----------|
| GET | `/admin/prestasi` | JSON list (all statuses) |
| POST | `/admin/prestasi` | Create new prestasi |
| GET | `/admin/prestasi/{id}` | JSON detail by ID |
| POST | `/admin/prestasi/{id}/update` | Update prestasi |
| POST | `/admin/prestasi/{id}/delete` | Soft delete |
| GET | `/admin/prestasi-tokens` | List all tokens |
| POST | `/admin/prestasi-tokens` | Generate new token |
| POST | `/admin/prestasi-tokens/{id}/revoke` | Revoke active token |

### Token System Design

- Token generation creates 64-char hex token via `bin2hex(random_bytes(32))`
- Only `hash('sha256', $plainToken)` is stored in DB
- Plain token is shown to admin exactly once in the generation response
- Token validation hashes the submitted token and checks against stored hash
- Token is marked `used` after successful prestasi submission
- Tokens can be revoked by admin
- Expired tokens (past `expires_at`) are rejected

## Verification

| Check | Result |
|-------|--------|
| PHP lint (10 files) | All pass |
| `tests/php/FoundationTest.php` | Pass |
| `tests/php/MigrationRunnerTest.php` | Pass |
| `tests/php/NewsModelTest.php` | Pass |
| `tests/php/NewsCommentModelTest.php` | Pass |
| `tests/php/PrestasiModelTest.php` | Pass |
| `npm test` (17 JS tests) | All pass |
| Route: `/prestasi` (JSON) | 200 |
| Route: `/prestasi/{slug}` (no DB) | 404 |
| Route: `/prestasi/submit/{token}` (no DB) | 403 |
| Route: `/admin/prestasi` | 200 |
| Route: `/admin/prestasi-tokens` | 200 |
| Route: `/admin/prestasi/{id}` (no DB) | 404 |
| Route: `/assets/css/tailwind.css` | 200 |
| Route: `/assets/js/api-core.js` | 200 |
| Existing routes (`/`, `/about`, `/team`, `/contact`, `/news`) | All 200 |

## Files Modified

- `tests/api-core.test.js` — fixed require paths
- `tools/static-server.js` — fixed require path
- `tailwind.config.js` — fixed content scan path
- `public/index.php` — fixed asset bridge base directory
- `bootstrap/app.php` — added Prestasi/Token model and controller wiring
- `routes/web.php` — replaced static `/prestasi` with controller routes
- `routes/admin.php` — added Prestasi CRUD and token routes

## Files Created

- `app/Models/Prestasi.php`
- `app/Models/PrestasiToken.php`
- `app/Controllers/Public/PrestasiController.php`
- `app/Controllers/Admin/PrestasiController.php`
- `app/Controllers/Admin/PrestasiTokenController.php`
- `tests/php/PrestasiModelTest.php`

## Notes

- All routes safely fall back when DB is unavailable (return empty arrays or appropriate error codes).
- Admin auth/CSRF enforcement is still pending — must be added before production use.
- Token plain text is only returned once during generation; admin cannot retrieve it later.
- Prestasi submissions via token are created with `status = 'pending'` for admin review.
- The `assets/` -> `public/assets/` relocation means the static prototype HTML files (in project root) now require the PHP server to resolve relative `assets/...` paths correctly. Direct `file://` opening of root HTML files will not find CSS/JS unless a symlink or copy is made.
