# Local Clean Route Preview Support Report

Date: 2026-05-06

## Summary

Fixed the local preview routing problem where clean URLs such as `/news`, `/about`, `/news/{slug}`, and `/admin/comment` could render the homepage or fail before the PHP router exists.

## Root Cause

The previous `npm run serve` command used Python's simple static server. That server only serves real files and has no route table for extensionless URLs. After the frontend began generating clean backend-ready URLs, local preview routes had no reliable mapping to the existing static HTML files.

## Implemented

- Added `resolveStaticRoute(pathname)` in `assets/js/api-core.js`.
- Added local preview detection so URL helpers keep production clean URLs for real hosts but use static file URLs on `localhost`, `127.0.0.1`, and port `5173`.
- Updated `assets/js/app.js` so `getParam('slug')` can read `/news/{slug}` paths.
- Added `tools/static-server.js`, a small Node static server that maps clean preview routes to existing HTML files:
  - `/` -> `/index.html`
  - `/about` -> `/about.html`
  - `/team` -> `/team.html`
  - `/prestasi` -> `/prestasi.html`
  - `/news` -> `/news.html`
  - `/contact` -> `/contact.html`
  - `/news/{slug}` -> `/news-detail.html`
  - `/admin/{page}` -> `/admin/{page}.html`
- Updated `package.json` so `npm run serve` uses the new Node preview server.
- Added unit tests for local route fallback behavior.

## Verification

- `node --check` passed for:
  - `tools/static-server.js`
  - `assets/js/api-core.js`
  - `assets/js/app.js`
- `npm test` passed.
- Result: 17 passing tests, 0 failures.
- Local route smoke test returned HTTP 200 for:
  - `/`
  - `/news`
  - `/about`
  - `/team`
  - `/prestasi`
  - `/contact`
  - `/news/example-slug-1`
  - `/admin/comment`

## Run Command

Use:

```bash
npm run serve
```

Then open:

```txt
http://127.0.0.1:5173
```

## Notes

- This is a preview server for the static prototype only.
- The production PHP phase still needs the real route handling from `public/index.php -> Router -> Controller` as defined in `BLUEPRINTS.md`.
- `npm run build:css` was not required because this change did not modify Tailwind classes or CSS output.
