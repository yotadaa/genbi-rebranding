# PHP MVC Entry Point Skeleton Report

Date: 2026-05-06

## Summary

Added the first PHP MVC backend skeleton so cPanel can eventually point the domain web root to `/public` and route all clean URLs through `public/index.php`.

## Implemented

- Added cPanel/PHP web entry point:
  - `public/index.php`
- Added bootstrap and autoloading:
  - `bootstrap/app.php`
- Added core MVC infrastructure:
  - `app/Core/Request.php`
  - `app/Core/Response.php`
  - `app/Core/Router.php`
  - `app/Core/StaticPageRenderer.php`
- Added public controllers:
  - `app/Controllers/Public/PageController.php`
  - `app/Controllers/Public/NewsController.php`
- Added admin controller:
  - `app/Controllers/Admin/AdminPageController.php`
- Added route files:
  - `routes/web.php`
  - `routes/admin.php`
- Added Apache/cPanel rewrite config:
  - `public/.htaccess`
- Added `public/assets/.gitignore` as a placeholder because copied or symlinked public assets will be handled in a later deployment-hardening phase.

## Routes Added

Public routes:

- `GET /`
- `GET /about`
- `GET /team`
- `GET /prestasi`
- `GET /contact`
- `GET /news`
- `GET /news/{slug}`
- `GET /news/id/{id}` returning `301` to the current static detail fallback

Admin preview routes:

- `GET /admin`
- `GET /admin/dashboard`
- `GET /admin/{page}`

Admin routes render with:

- `X-Robots-Tag: noindex, nofollow`
- `<meta name="robots" content="noindex, nofollow">`

## Current Behavior

The PHP skeleton currently renders the existing static prototype HTML through clean routes. It does not connect to the database yet and does not implement auth, CSRF, models, migrations, or real CMS persistence yet.

Request flow now matches the planned shape from `BLUEPRINTS.md`:

```txt
Request -> public/index.php -> bootstrap/app.php -> Router -> Controller -> StaticPageRenderer -> Response
```

## Verification

- PHP runtime available: PHP 8.4.20.
- PHP lint passed for 11 new PHP files.
- PHP route smoke test passed for:
  - `/`
  - `/news`
  - `/about`
  - `/team`
  - `/prestasi`
  - `/contact`
  - `/news/example-slug-1`
  - `/admin`
  - `/admin/dashboard`
  - `/admin/comment`
- Legacy route check:
  - `/news/id/100` returns `301`.
- Frontend tests passed:
  - `npm test`
  - Result: 17 passing tests, 0 failures.

## How To Run PHP Preview

Use:

```bash
php -S 127.0.0.1:8000 -t public
```

Then open:

```txt
http://127.0.0.1:8000
```

## cPanel Deployment Note

Later, point the domain document root to:

```txt
/public
```

Do not point the domain to the project root, because `app/`, `bootstrap/`, `routes/`, `storage/`, and database files must not be web-accessible.

## Next Phase Recommendation

The next backend phase should add configuration and environment loading, then database connection using PDO with prepared statements and no hard-coded credentials.
