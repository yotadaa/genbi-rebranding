# Planning Resolve Isu GenBI Jambi

## Tujuan Utama

Merapikan fitur admin dan public website agar alur konten lebih stabil, aman, dan nyaman dipakai.

Fokus utama:

1. Menambah fitur **Prestasi CMS**.
2. Merapikan **share dan comment section** di news detail.
3. Memperbaiki bug **admin sidebar mobile**.
4. Memperbaiki posisi **modal team member dan prestasi**.
5. Menyiapkan form prestasi publik berbasis **one-time token**.

Untuk form token sekali pakai, pakai pola token unik yang langsung tidak valid setelah submit. OWASP menjelaskan bahwa token dapat dibuat sekali pakai untuk mencegah penyalahgunaan request berulang. ([OWASP Cheat Sheet Series][1]) Untuk modal, gunakan pendekatan modal yang benar: fokus masuk ke dialog, `Escape` menutup dialog, dan fokus tetap berada di dalam modal selama terbuka. Ini sesuai pola WAI-ARIA modal dialog. ([W3C][2])

---

# 1. Issue: Manage Prestasi di Admin

## Masalah

Saat ini belum ada modul admin lengkap untuk mengelola prestasi. Public page sudah punya daftar prestasi, tetapi belum ada flow admin untuk:

* List prestasi
* Add prestasi
* Edit prestasi
* Delete prestasi
* Detail prestasi
* Upload gambar prestasi
* Filter kategori
* Modal detail di public page

## Target Hasil

Admin punya halaman khusus untuk mengelola prestasi. Public page bisa menampilkan daftar prestasi dan modal detail dengan gambar.

## Struktur Halaman Admin

| Halaman         | File                               | Fungsi                          |
| --------------- | ---------------------------------- | ------------------------------- |
| List Prestasi   | `admin/prestasi.html`              | Menampilkan semua data prestasi |
| Add Prestasi    | `admin/prestasi-add.html`          | Menambah prestasi baru          |
| Edit Prestasi   | `admin/prestasi-edit.html`         | Mengubah data prestasi          |
| Token Form List | `admin/prestasi-token.html`        | Mengelola token input prestasi  |
| Token Detail    | `admin/prestasi-token-detail.html` | Melihat status token            |

## Field Prestasi

| Field             | Tipe                 | Keterangan                                                   |
| ----------------- | -------------------- | ------------------------------------------------------------ |
| Judul Prestasi    | Text                 | Nama prestasi                                                |
| Kategori          | Custom dropdown      | QRIS, KTI, Essay, Inovasi Desa, Kreativitas, Ekonomi Syariah |
| Tahun             | Number atau dropdown | Tahun pencapaian                                             |
| Nama Anggota      | Text                 | Nama penerima prestasi                                       |
| Komisariat        | Custom dropdown      | Universitas Jambi, UIN Sultan Thaha, Alumni                  |
| Deskripsi Singkat | Textarea             | Ringkasan untuk list                                         |
| Deskripsi Detail  | Block editor         | Detail prestasi                                              |
| Foto Prestasi     | Custom file input    | Gambar utama                                                 |
| Status Tampil     | Custom dropdown      | Publish, Draft                                               |
| Meta Title        | Text                 | SEO                                                          |
| Meta Description  | Textarea             | SEO                                                          |
| Meta Keywords     | Textarea             | SEO                                                          |

## Tampilan Admin List Prestasi

Gunakan card atau table hybrid.

Isi item:

* Nomor
* Foto kecil
* Judul prestasi
* Kategori
* Tahun
* Nama anggota
* Komisariat
* Status
* Tombol Detail
* Tombol Edit
* Tombol Delete

## Action

| Action | Perilaku                                         |
| ------ | ------------------------------------------------ |
| Add    | Buka `prestasi-add.html`                         |
| Edit   | Buka `prestasi-edit.html?id=...`                 |
| Detail | Buka modal preview                               |
| Delete | Buka custom confirmation modal                   |
| Search | Filter berdasarkan judul, nama anggota, kategori |
| Filter | Filter kategori, tahun, komisariat, status       |

## Acceptance Criteria

* Admin bisa melihat daftar prestasi.
* Admin bisa menambah prestasi baru.
* Admin bisa mengedit prestasi.
* Admin bisa menghapus prestasi memakai custom modal.
* Public page prestasi ikut membaca data dummy yang sama.
* Saat item prestasi public diklik, muncul modal detail fixed dengan gambar.
* Modal tidak turun ke bawah saat halaman discroll.

---

# 2. Issue: Form Input Prestasi Sekali Pakai dengan Token

## Masalah

Ada kebutuhan agar form input prestasi bisa dibagikan satu kali saja. Setelah submit, token harus invalid.

## Target Hasil

Admin bisa generate link form prestasi dengan token unik. Link hanya bisa dipakai satu kali. Setelah submit, token tidak bisa dipakai lagi.

## Alur Fitur

1. Admin membuka halaman `admin/prestasi-token.html`.
2. Admin klik **Generate Token**.
3. Sistem membuat token unik.
4. Sistem menampilkan link seperti:

```text
prestasi-submit.html?token=GENBI-2026-xxxx
```

5. User membuka link.
6. Sistem cek token.
7. Jika token valid, form tampil.
8. User submit data prestasi.
9. Sistem menyimpan data prestasi.
10. Token berubah status menjadi `used`.
11. Jika link dibuka lagi, tampil pesan:

```text
Token sudah digunakan atau tidak valid.
```

## Status Token

| Status  | Arti                       |
| ------- | -------------------------- |
| Active  | Token masih bisa dipakai   |
| Used    | Token sudah dipakai        |
| Expired | Token melewati batas waktu |
| Revoked | Token dibatalkan admin     |

## Data Token

| Field               | Keterangan                     |
| ------------------- | ------------------------------ |
| Token ID            | ID unik token                  |
| Token Value         | Token rahasia                  |
| Created At          | Waktu dibuat                   |
| Used At             | Waktu digunakan                |
| Expired At          | Waktu kadaluarsa               |
| Status              | Active, Used, Expired, Revoked |
| Submitted By        | Nama pengisi form              |
| Related Prestasi ID | ID prestasi setelah submit     |

## Validasi

| Kondisi               | Hasil           |
| --------------------- | --------------- |
| Token tidak ada       | Tampilkan error |
| Token tidak ditemukan | Tampilkan error |
| Token sudah used      | Tampilkan error |
| Token expired         | Tampilkan error |
| Token revoked         | Tampilkan error |
| Token active          | Tampilkan form  |

## Acceptance Criteria

* Admin bisa generate token.
* Token punya status.
* Form hanya tampil jika token valid.
* Token langsung invalid setelah submit.
* Token bekas tidak bisa dipakai ulang.
* Token expired tidak bisa dipakai.
* Admin bisa melihat riwayat token.

---

# 3. Issue: Share dan Comment Section di News Detail Menjadi 1 Column

## Masalah

Share dan comment section perlu dibuat dalam satu kolom agar lebih rapi dan mudah dibaca.

## Target Hasil

News detail punya alur baca seperti ini:

1. Artikel utama
2. Share section
3. Comment section
4. Artikel terkait

## Struktur Layout

```text
News Detail
├── Article Header
├── Featured Image
├── Article Content
├── Share Section
├── Comment Section
│   ├── Comment List
│   └── Comment Form
└── Artikel Terkait
```

## Share Section

| Elemen         | Deskripsi                   |
| -------------- | --------------------------- |
| Label          | “Bagikan artikel ini”       |
| WhatsApp       | Share ke WhatsApp           |
| Facebook       | Share ke Facebook           |
| X atau Twitter | Share ke X                  |
| Copy Link      | Menyalin URL artikel        |
| Toast feedback | Muncul pesan “Link disalin” |

## Comment Section

| Elemen        | Deskripsi                                       |
| ------------- | ----------------------------------------------- |
| Judul         | “Komentar”                                      |
| Empty state   | “Belum ada komentar.”                           |
| List komentar | Hanya tampilkan komentar approved               |
| Form nama     | Nama komentator                                 |
| Form email    | Email komentator                                |
| Form komentar | Isi komentar                                    |
| Submit button | Kirim komentar                                  |
| Info moderasi | “Komentar akan tampil setelah disetujui admin.” |

## Acceptance Criteria

* Share dan komentar tampil satu kolom.
* Comment form tidak melebar berlebihan.
* Mobile tetap nyaman.
* Artikel terkait tetap tampil setelah comment section.
* Artikel terkait punya gambar di sebelah kiri.
* Komentar pending tidak tampil di public page.

---

# 4. Issue: Admin News Comment untuk Moderasi Komentar

## Masalah

Halaman admin comment saat ini masih terasa seperti setup kode Facebook. Padahal harus menjadi halaman untuk mengelola komentar berita.

## Target Hasil

Admin Comment berubah menjadi modul moderasi komentar.

## Struktur Halaman

File:

```text
admin/comment.html
```

## Data Komentar

| Field    | Deskripsi                   |
| -------- | --------------------------- |
| Nama     | Nama komentator             |
| Email    | Email komentator            |
| Artikel  | Judul berita terkait        |
| Komentar | Isi komentar                |
| Tanggal  | Waktu komentar masuk        |
| Status   | Pending, Approved, Rejected |
| Action   | Approve, Reject, Delete     |

## Filter

| Filter   | Deskripsi                                    |
| -------- | -------------------------------------------- |
| Semua    | Semua komentar                               |
| Pending  | Komentar menunggu moderasi                   |
| Approved | Komentar yang sudah tampil                   |
| Rejected | Komentar ditolak                             |
| Search   | Cari nama, email, artikel, atau isi komentar |

## Action

| Action  | Perilaku                            |
| ------- | ----------------------------------- |
| Approve | Ubah status menjadi approved        |
| Reject  | Ubah status menjadi rejected        |
| Delete  | Hapus komentar memakai custom modal |
| Detail  | Buka modal isi komentar penuh       |

## Acceptance Criteria

* Admin bisa melihat komentar masuk.
* Admin bisa menyetujui komentar.
* Admin bisa menolak komentar.
* Admin bisa menghapus komentar.
* Comment section public hanya menampilkan komentar approved.
* Semua action memakai modal custom, bukan `confirm()` browser.

---

# 5. Issue: Bug Admin Sidebar Mobile View

## Masalah

Sidebar admin di mobile bisa terpengaruh oleh scroll halaman. Akibatnya posisi sidebar tidak stabil.

## Target Hasil

Sidebar mobile harus fixed, punya overlay, dan tidak ikut terdorong oleh scroll halaman.

## Solusi Teknis

Gunakan struktur:

```text
body
├── admin-shell
│   ├── mobile-overlay fixed
│   ├── sidebar fixed
│   └── main-content
```

## Perilaku Sidebar Mobile

| Kondisi            | Perilaku                     |
| ------------------ | ---------------------------- |
| Sidebar tertutup   | Sidebar berada di luar layar |
| Tombol menu diklik | Sidebar slide dari kiri      |
| Overlay diklik     | Sidebar tertutup             |
| Escape ditekan     | Sidebar tertutup             |
| Menu diklik        | Sidebar tertutup             |
| Body scroll        | Dikunci saat sidebar terbuka |

## CSS Prinsip

```css
.admin-sidebar {
  position: fixed;
  inset: 0 auto 0 0;
  height: 100dvh;
  overflow-y: auto;
  z-index: 50;
}

.admin-overlay {
  position: fixed;
  inset: 0;
  z-index: 40;
}
```

Gunakan `100dvh` agar lebih stabil di browser mobile modern. Jangan biarkan sidebar berada di dalam container yang ikut scroll.

## Body Scroll Lock

Saat sidebar terbuka:

```js
document.body.classList.add('overflow-hidden')
```

Saat sidebar tertutup:

```js
document.body.classList.remove('overflow-hidden')
```

## Acceptance Criteria

* Sidebar tidak ikut scroll.
* Sidebar tetap menempel di kiri.
* Overlay menutup konten utama.
* Body tidak bisa discroll saat sidebar terbuka.
* Sidebar bisa ditutup dengan overlay, tombol close, dan Escape.
* Hover dan active state tetap jelas.

---

# 6. Issue: Bug Modal Team Member dan Prestasi

## Masalah

Modal team member dan prestasi muncul di posisi bawah atau ikut dipengaruhi scroll.

## Target Hasil

Modal selalu fixed di tengah viewport. Tidak boleh ikut flow layout halaman.

## Solusi Teknis

Gunakan modal di level akhir `body`, bukan di dalam card atau section.

Struktur:

```html
<body>
  <main>
    ...
  </main>

  <div id="app-modal-root"></div>
</body>
```

Render modal ke `#app-modal-root`.

## CSS Modal

```css
.modal-overlay {
  position: fixed;
  inset: 0;
  z-index: 100;
  display: grid;
  place-items: center;
  padding: 24px;
}

.modal-panel {
  max-height: calc(100dvh - 48px);
  overflow-y: auto;
}
```

MDN menjelaskan bahwa `HTMLDialogElement.showModal()` menampilkan dialog di top layer dan membuat elemen lain di dokumen menjadi inert. Ini cocok untuk mencegah interaksi dengan halaman belakang saat modal aktif. ([MDN Web Docs][3])

## Modal Team Member

Isi modal:

* Foto anggota
* Nama
* Jabatan
* Komisariat
* Divisi
* Divisi lain
* Deskripsi singkat
* Tombol close

## Modal Prestasi

Isi modal:

* Foto prestasi
* Judul prestasi
* Kategori
* Tahun
* Nama anggota
* Komisariat
* Deskripsi detail
* Tombol close

## Acceptance Criteria

* Modal selalu muncul di tengah viewport.
* Modal tidak turun ke bawah.
* Modal tidak ikut scroll section.
* Body terkunci saat modal terbuka.
* Fokus masuk ke modal.
* Escape menutup modal.
* Klik backdrop menutup modal.
* Setelah modal ditutup, fokus kembali ke tombol pemicu.

---

# 7. Urutan Eksekusi

## Sprint 1: Stabilkan Bug UI Dasar

Prioritas tertinggi karena memengaruhi banyak halaman.

| Task                      | Output                                    |
| ------------------------- | ----------------------------------------- |
| Fix sidebar mobile        | Sidebar fixed, overlay, body scroll lock  |
| Fix modal root            | Modal team dan prestasi tidak ikut scroll |
| Buat utility modal global | Satu fungsi modal dipakai semua halaman   |
| Uji mobile                | Cek 360px, 390px, 768px                   |

## Sprint 2: News Detail dan Comment

| Task                                 | Output                           |
| ------------------------------------ | -------------------------------- |
| Ubah share dan comment jadi 1 column | Layout news detail rapi          |
| Tambah share buttons                 | WhatsApp, Facebook, X, copy link |
| Tambah comment form                  | Nama, email, komentar            |
| Tambah comment list                  | Hanya tampilkan approved         |
| Ubah admin comment                   | Jadi moderation dashboard        |

## Sprint 3: Prestasi CMS

| Task                      | Output                     |
| ------------------------- | -------------------------- |
| Buat data dummy prestasi  | Sumber data reusable       |
| Buat admin list prestasi  | Search, filter, action     |
| Buat add prestasi         | Form lengkap               |
| Buat edit prestasi        | Form isi data lama         |
| Buat modal delete         | Konfirmasi custom          |
| Hubungkan public prestasi | Modal detail dengan gambar |

## Sprint 4: One-Time Token Form

| Task                      | Output                         |
| ------------------------- | ------------------------------ |
| Buat token data model     | Active, Used, Expired, Revoked |
| Buat admin generate token | Token link sekali pakai        |
| Buat public submit form   | Form input prestasi via token  |
| Validasi token            | Token invalid setelah submit   |
| Buat token history        | Admin bisa audit token         |

## Sprint 5: Testing dan Cleanup

| Task                    | Output                           |
| ----------------------- | -------------------------------- |
| Test desktop            | Chrome, Firefox                  |
| Test mobile             | 360px, 390px, 768px              |
| Test modal              | Backdrop, Escape, focus          |
| Test sidebar            | Open, close, scroll lock         |
| Test comment moderation | Pending ke approved              |
| Test token              | Active, used, expired            |
| Refactor JS             | Pisah utility, data, page script |
| Review visual           | Pastikan biru admin konsisten    |

---

# 8. Struktur File yang Disarankan

```text
assets/
├── css/
│   └── styles.css
├── js/
│   ├── app.js
│   ├── data.js
│   ├── modal.js
│   ├── sidebar.js
│   ├── token.js
│   ├── comments.js
│   ├── prestasi.js
│   └── pages/
│       ├── home.js
│       ├── news-detail.js
│       ├── prestasi-page.js
│       ├── team-page.js
│       └── admin/
│           ├── dashboard.js
│           ├── comment.js
│           ├── prestasi.js
│           ├── prestasi-form.js
│           └── prestasi-token.js

admin/
├── dashboard.html
├── comment.html
├── prestasi.html
├── prestasi-add.html
├── prestasi-edit.html
└── prestasi-token.html

prestasi-submit.html
prestasi.html
news-detail.html
```

---

# 9. Checklist Testing

## Sidebar Mobile

* [ ] Sidebar tidak ikut scroll.
* [ ] Overlay muncul.
* [ ] Body terkunci saat sidebar aktif.
* [ ] Escape menutup sidebar.
* [ ] Klik menu menutup sidebar.
* [ ] Active menu tetap terlihat.

## Modal

* [ ] Modal team muncul di tengah.
* [ ] Modal prestasi muncul di tengah.
* [ ] Modal tidak turun ke bawah.
* [ ] Body terkunci saat modal terbuka.
* [ ] Backdrop bisa menutup modal.
* [ ] Escape bisa menutup modal.
* [ ] Fokus kembali ke tombol pemicu.

## News Detail

* [ ] Share section tampil 1 column.
* [ ] Comment section tampil 1 column.
* [ ] Copy link berfungsi.
* [ ] Komentar pending tidak tampil.
* [ ] Artikel terkait punya gambar kiri.
* [ ] Mobile tetap rapi.

## Admin Comment

* [ ] Komentar pending tampil.
* [ ] Approve mengubah status.
* [ ] Reject mengubah status.
* [ ] Delete memakai custom modal.
* [ ] Filter status berfungsi.
* [ ] Search komentar berfungsi.

## Prestasi CMS

* [ ] List prestasi tampil.
* [ ] Add prestasi berfungsi.
* [ ] Edit prestasi berfungsi.
* [ ] Delete memakai modal.
* [ ] Filter kategori berfungsi.
* [ ] Modal detail public tampil.
* [ ] Gambar prestasi tampil di modal.

## Token Form

* [ ] Admin bisa generate token.
* [ ] Token active membuka form.
* [ ] Token used menolak akses.
* [ ] Token expired menolak akses.
* [ ] Token invalid menolak akses.
* [ ] Setelah submit, token berubah used.
* [ ] Data prestasi tersimpan.

---

# 10. Prioritas Final

| Prioritas | Isu                           | Alasan                                     |
| --------- | ----------------------------- | ------------------------------------------ |
| P0        | Modal team dan prestasi       | Bug visual utama dan mengganggu UX         |
| P0        | Sidebar mobile admin          | Mengganggu navigasi admin                  |
| P1        | News detail share dan comment | Perlu untuk pengalaman baca artikel        |
| P1        | Admin comment moderation      | Dibutuhkan agar comment section aman       |
| P2        | Prestasi CMS                  | Fitur baru besar                           |
| P2        | One-time token prestasi       | Fitur lanjutan, perlu validasi lebih ketat |

Urutan paling aman: **fix modal dan sidebar dulu**, lalu **news comment**, lalu **prestasi CMS**, baru **token sekali pakai**.

[1]: https://cheatsheetseries.owasp.org/cheatsheets/Cross-Site_Request_Forgery_Prevention_Cheat_Sheet.html?utm_source=chatgpt.com "Cross-Site Request Forgery Prevention Cheat Sheet"
[2]: https://www.w3.org/WAI/ARIA/apg/patterns/dialog-modal/?utm_source=chatgpt.com "Dialog (Modal) Pattern | APG | WAI"
[3]: https://developer.mozilla.org/en-US/docs/Web/API/HTMLDialogElement/showModal?utm_source=chatgpt.com "HTMLDialogElement: showModal() method - Web APIs | MDN"
