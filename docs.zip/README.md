# GenBI Static HTML v7

Pure HTML + vanilla JavaScript + Tailwind compiled CSS prototype for GenBI Provinsi Jambi.

## Public pages
- `index.html`
- `about.html`
- `team.html`
- `prestasi.html`
- `news.html`
- `news-detail.html`
- `contact.html`

## Admin pages
- `admin/dashboard.html`
- `admin/settings.html`
- `admin/page.html`
- `admin/language.html`
- `admin/category.html`
- `admin/news.html`
- `admin/news-add.html`
- `admin/news-edit.html?id=100`
- `admin/comment.html`
- `admin/event.html`
- `admin/event-add.html`
- `admin/slider.html`
- `admin/slider-add.html`
- `admin/team-member.html`
- `admin/team-member-add.html`
- `admin/team-member-edit.html?id=4`

## Notes
- Hero landing page uses slider 1 and slider 4 as background.
- Hero glassmorphism card has been removed.
- Video modal uses the provided YouTube embed iframe.
- Admin list pages use custom confirmation modal for delete actions.
- Add and edit news use a full block level editor layout. Main writing canvas is on the left. Config fields are in the sidebar.
- Team member uses grid and list card modes. Add and edit member forms include Komisariat, Divisi, Jabatan, and Divisi Lain.

## Run

```bash
python3 -m http.server 5173
```

Open:

```txt
http://127.0.0.1:5173
```


## V8 Update

- Admin blue is softened to a cleaner, less saturated palette while keeping GenBI blue as the main accent.
- Add/Edit News now uses Editor.js block editor via CDN for a Medium-like writing experience.
- News editor supports paragraph, heading, quote, list, and image blocks. Images can be inserted from URL or local upload in preview mode.
- Hero glass summary has been removed from the hero. Hero now focuses on headline, CTA, and video.
