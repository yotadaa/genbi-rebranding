# Tambahan Issue: Dropdown Filter News Tertimpa Item News

## Masalah

Dropdown filter pada halaman news tertimpa oleh item news. Kemungkinan besar penyebabnya:

1. `z-index` dropdown terlalu rendah.
2. Parent dropdown punya `overflow: hidden`.
3. Parent card atau section membuat stacking context baru.
4. Item news punya `position` dan `z-index` lebih tinggi.
5. Dropdown dirender di dalam container yang tinggi atau overflow-nya terbatas.

## Target Hasil

Dropdown filter harus selalu tampil di atas item news saat dibuka.

Dropdown tidak boleh:

* Terpotong.
* Tertimpa card news.
* Hilang saat berada dekat item pertama.
* Membuat layout halaman bergeser.

## Solusi Teknis

### 1. Pastikan wrapper filter punya posisi dan z-index tinggi

```css
.news-filter {
  position: relative;
  z-index: 30;
}
```

### 2. Dropdown menu harus lebih tinggi dari card news

```css
.custom-dropdown-menu {
  position: absolute;
  z-index: 80;
}
```

### 3. Item news jangan memakai z-index tinggi

```css
.news-card {
  position: relative;
  z-index: 1;
}
```

### 4. Hindari overflow hidden pada parent filter

Cek container seperti:

```css
.section-news,
.news-layout,
.filter-wrapper,
.card-wrapper {
  overflow: visible;
}
```

Jika ada `overflow: hidden`, pindahkan ke elemen anak yang tidak membungkus dropdown.

### 5. Jika masih bermasalah, render dropdown ke body

Untuk solusi paling stabil, dropdown bisa dirender sebagai floating layer di akhir `body`.

Struktur:

```html
<div id="floating-root"></div>
```

Lalu posisi dropdown dihitung dari tombol trigger memakai JavaScript.

Ini mirip pola modal. Dropdown tidak lagi terpengaruh parent container.

## File yang Perlu Dicek

```text
assets/css/styles.css
assets/js/dropdown.js
assets/js/pages/news.js
news.html
```

## Acceptance Criteria

* Dropdown filter news tampil di atas semua item news.
* Dropdown tidak tertutup card.
* Dropdown tidak terpotong oleh section.
* Dropdown tetap benar di desktop dan mobile.
* Klik luar dropdown menutup menu.
* Escape menutup dropdown.
* Dropdown aktif tetap punya focus state yang jelas.

## Update Prioritas

| Prioritas | Isu                                     | Alasan                         |
| --------- | --------------------------------------- | ------------------------------ |
| P0        | Modal team dan prestasi                 | Bug visual utama               |
| P0        | Sidebar mobile admin                    | Mengganggu navigasi admin      |
| P0        | Dropdown filter news tertimpa item news | Mengganggu fungsi filter       |
| P1        | News detail share dan comment           | Penting untuk pengalaman baca  |
| P1        | Admin comment moderation                | Penting untuk kontrol komentar |
| P2        | Prestasi CMS                            | Fitur baru besar               |
| P2        | One-time token prestasi                 | Fitur lanjutan                 |

## Update Urutan Eksekusi

1. Fix modal root.
2. Fix admin sidebar mobile.
3. Fix dropdown filter news.
4. Rapikan news detail share dan comment.
5. Ubah admin comment menjadi moderation dashboard.
6. Bangun prestasi CMS.
7. Bangun one-time token form prestasi.
