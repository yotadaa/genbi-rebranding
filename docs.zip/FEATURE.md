Untuk carousel horizontal, struktur memakai pola swipe dengan CSS Scroll Snap agar tiap item berhenti rapi di posisi kartu. CSS Scroll Snap memang dipakai untuk mengatur perilaku scroll dan posisi snap pada scroll container. Kontrol prev dan next juga disiapkan sebagai tombol eksplisit sesuai pola carousel WAI-ARIA APG yang menyebut carousel membutuhkan tombol untuk slide sebelumnya dan berikutnya. ([MDN Web Docs][1])

# Dokumentasi Fitur Website GenBI Provinsi Jambi

## 1. Ringkasan Sistem

Website GenBI Provinsi Jambi adalah website profil organisasi berbasis **pure HTML, Tailwind CSS, dan JavaScript**. Website ini memiliki dua bagian utama:

| Modul          | Deskripsi                                                                                                                                                               |
| -------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Public Website | Halaman publik untuk menampilkan profil GenBI, program, pengurus, prestasi, berita, agenda, kontak, dan informasi organisasi.                                           |
| Admin CMS      | Panel admin untuk mengelola konten website seperti dashboard, setting, halaman, bahasa, berita, komentar, event, anggota, slider, galeri, fitur, FAQ, dan media sosial. |

## 2. Fitur Public Website

### 2.1 Navigasi Utama

| Subfitur                | Deskripsi                                                |
| ----------------------- | -------------------------------------------------------- |
| Header publik           | Menampilkan logo GenBI, nama organisasi, dan menu utama. |
| Menu halaman            | Berisi Home, About, Team, Prestasi, News, dan Contact.   |
| Tombol Admin Preview    | Mengarahkan pengguna ke halaman admin preview.           |
| Tombol Hubungi Kami     | Mengarahkan pengguna ke kontak resmi.                    |
| Menu mobile             | Menampilkan navigasi ringkas pada layar kecil.           |
| Active navigation state | Menu yang sedang aktif diberi penanda visual biru.       |

### 2.2 Hero Landing Page

| Subfitur                   | Deskripsi                                                                              |
| -------------------------- | -------------------------------------------------------------------------------------- |
| Background hero            | Menggunakan foto slider 1 dan slider 4 sebagai latar utama.                            |
| Overlay biru               | Memberi kontras agar teks tetap terbaca.                                               |
| Judul utama                | Menampilkan pesan utama organisasi secara editorial dan kuat.                          |
| Deskripsi hero             | Menjelaskan posisi GenBI sebagai komunitas mahasiswa penerima beasiswa Bank Indonesia. |
| Tombol Kenali GenBI        | Mengarahkan pengguna ke bagian profil.                                                 |
| Tombol Baca Berita Terbaru | Mengarahkan pengguna ke daftar berita.                                                 |
| Animasi masuk              | Elemen hero muncul halus saat halaman dibuka.                                          |
| Video embed                | Menyediakan video YouTube resmi melalui iframe.                                        |

### 2.3 Profil Organisasi

| Subfitur          | Deskripsi                                                                              |
| ----------------- | -------------------------------------------------------------------------------------- |
| Ringkasan GenBI   | Menjelaskan GenBI sebagai komunitas mahasiswa penerima beasiswa Bank Indonesia.        |
| Fokus organisasi  | Menampilkan fokus pada literasi, kepemimpinan, sosial, digital, dan dampak masyarakat. |
| Statistik ringkas | Menampilkan data seperti jumlah kampus, program, berita, atau aktivitas.               |
| CTA profil        | Mengajak pengunjung membaca informasi organisasi lebih lanjut.                         |

### 2.4 Program Utama

| Subfitur             | Deskripsi                                                                                   |
| -------------------- | ------------------------------------------------------------------------------------------- |
| Carousel horizontal  | Program tampil sebagai kartu yang bisa digeser horizontal.                                  |
| Item per kartu       | Setiap program tampil dalam satu kartu tersendiri.                                          |
| Icon program         | Tiap item memiliki icon agar mudah dikenali.                                                |
| Label singkat        | Menampilkan kode program seperti KKG, SIGINJAI, GENTALA ARASY, GGTC, dan Leadership Camp.   |
| Nama program         | Menampilkan nama lengkap program.                                                           |
| Deskripsi manfaat    | Menjelaskan fokus dan manfaat program.                                                      |
| Tag kategori         | Menampilkan kategori seperti Kampus, Literasi digital, Literasi syariah, atau Kepemimpinan. |
| Tombol prev dan next | Mengontrol perpindahan item carousel.                                                       |
| Scroll snap          | Membuat posisi kartu tetap rapi saat digeser.                                               |
| Teks section center  | Judul dan deskripsi section dibuat rata tengah.                                             |

### 2.5 BPI Provinsi Jambi

| Subfitur            | Deskripsi                                                                         |
| ------------------- | --------------------------------------------------------------------------------- |
| Daftar BPI          | Menampilkan daftar pengurus inti BPI GenBI Provinsi Jambi.                        |
| Carousel horizontal | Setiap anggota tampil sebagai kartu horizontal yang bisa digeser.                 |
| Foto anggota        | Menampilkan foto anggota jika tersedia.                                           |
| Skeleton fallback   | Jika foto gagal dimuat, sistem menampilkan skeleton placeholder.                  |
| Nama anggota        | Menampilkan nama lengkap anggota.                                                 |
| Jabatan             | Menampilkan posisi anggota di organisasi.                                         |
| Label organisasi    | Menampilkan label BPI GenBI Provinsi Jambi.                                       |
| Modal detail        | Saat anggota diklik, muncul popup detail.                                         |
| Modal fixed         | Popup tetap berada di tengah layar dan tidak ikut bergeser saat halaman discroll. |
| Tombol close        | Modal bisa ditutup melalui tombol, backdrop, atau Escape.                         |

### 2.6 Agenda Utama

| Subfitur         | Deskripsi                                                                            |
| ---------------- | ------------------------------------------------------------------------------------ |
| Carousel agenda  | Agenda tampil sebagai kartu horizontal.                                              |
| Icon agenda      | Tiap agenda memiliki icon sesuai kategori.                                           |
| Kategori agenda  | Menampilkan kategori seperti Sosial, Komunitas, Literasi UMKM, atau Kebanksentralan. |
| Tanggal agenda   | Menampilkan tanggal pelaksanaan.                                                     |
| Nama agenda      | Menampilkan judul agenda.                                                            |
| Deskripsi agenda | Menjelaskan tujuan dan konteks kegiatan.                                             |
| Card centered    | Konten dalam kartu dibuat rapi dan terpusat.                                         |
| Tombol navigasi  | Pengunjung bisa menggeser agenda dengan tombol prev dan next.                        |

### 2.7 Latest News

| Subfitur              | Deskripsi                                                                   |
| --------------------- | --------------------------------------------------------------------------- |
| Daftar berita terbaru | Menampilkan beberapa berita terbaru di landing page.                        |
| Gambar berita         | Setiap berita memiliki gambar thumbnail.                                    |
| Kategori berita       | Menampilkan kategori seperti Bank Indonesia atau GenBI Kolaborasi.          |
| Tanggal berita        | Menampilkan tanggal publikasi.                                              |
| Judul berita          | Menampilkan headline berita.                                                |
| News short content    | Menampilkan ringkasan atau caption singkat berita.                          |
| Link detail           | Membuka halaman detail berita.                                              |
| Layout editorial      | Berita tampil rapi seperti daftar publikasi, bukan grid yang terlalu ramai. |

### 2.8 News List Page

| Subfitur          | Deskripsi                                              |
| ----------------- | ------------------------------------------------------ |
| Daftar berita     | Menampilkan semua berita dalam format list editorial.  |
| Thumbnail berita  | Menampilkan gambar berita di setiap item.              |
| Kategori          | Menampilkan kategori berita.                           |
| Tanggal publikasi | Menampilkan waktu publikasi.                           |
| Judul berita      | Menampilkan headline utama.                            |
| Ringkasan berita  | Menampilkan News Short Content.                        |
| Search berita     | Membantu pengguna mencari berita tertentu.             |
| Filter kategori   | Membantu pengguna memilah berita berdasarkan kategori. |

### 2.9 News Detail Page

| Subfitur               | Deskripsi                                               |
| ---------------------- | ------------------------------------------------------- |
| Detail artikel         | Menampilkan artikel lengkap.                            |
| Featured image         | Menampilkan gambar utama artikel.                       |
| Kategori dan tanggal   | Menampilkan metadata artikel.                           |
| Konten artikel         | Menampilkan isi berita dalam layout editorial.          |
| Share section          | Menyediakan tombol berbagi artikel.                     |
| Comment section        | Menampilkan komentar pembaca.                           |
| Form komentar          | Pengunjung bisa mengisi nama, email, dan komentar.      |
| Moderasi komentar      | Komentar bisa ditampilkan sesuai status moderasi admin. |
| Artikel terkait        | Menampilkan artikel lain yang relevan.                  |
| Gambar artikel terkait | Artikel terkait memiliki gambar di sisi kiri.           |
| Link artikel terkait   | Mengarahkan pengguna ke detail artikel lain.            |

### 2.10 Team Page

| Subfitur          | Deskripsi                                                                     |
| ----------------- | ----------------------------------------------------------------------------- |
| Direktori anggota | Menampilkan anggota GenBI dalam format direktori.                             |
| Search utama      | Pengguna bisa mencari nama, jabatan, divisi, atau kampus.                     |
| Filter komisariat | Memilah anggota berdasarkan Universitas Jambi, UIN Sultan Thaha, atau Alumni. |
| Filter divisi     | Memilah anggota berdasarkan divisi.                                           |
| Filter tahun      | Memilah anggota berdasarkan periode atau tahun.                               |
| List card         | Anggota tampil sebagai list card agar mudah dibaca.                           |
| Avatar inisial    | Jika foto tidak tersedia, sistem menampilkan inisial nama.                    |
| Detail anggota    | Tombol Detail membuka popup informasi anggota.                                |
| Modal fixed       | Popup anggota tetap di tengah layar.                                          |
| Reset filter      | Mengembalikan daftar anggota ke kondisi awal.                                 |

### 2.11 Prestasi Page

| Subfitur              | Deskripsi                                                                                                          |
| --------------------- | ------------------------------------------------------------------------------------------------------------------ |
| Daftar prestasi       | Menampilkan prestasi anggota GenBI Jambi.                                                                          |
| Filter kategori       | Memilah prestasi seperti Literasi QRIS, Karya Tulis Ilmiah, Essay, Inovasi Desa, Kreativitas, dan Ekonomi Syariah. |
| Card prestasi         | Setiap prestasi tampil sebagai item editorial.                                                                     |
| Nomor urut            | Setiap item memiliki nomor urut besar.                                                                             |
| Nama prestasi         | Menampilkan judul pencapaian.                                                                                      |
| Tahun                 | Menampilkan tahun prestasi.                                                                                        |
| Nama anggota          | Menampilkan penerima prestasi.                                                                                     |
| Komisariat            | Menampilkan asal kampus atau komisariat.                                                                           |
| Modal detail prestasi | Saat item diklik, muncul popup detail.                                                                             |
| Foto prestasi         | Modal detail memiliki gambar dokumentasi.                                                                          |
| Deskripsi detail      | Menjelaskan konteks, kategori, tahun, anggota, dan dampak prestasi.                                                |

### 2.12 Contact Section

| Subfitur              | Deskripsi                                                       |
| --------------------- | --------------------------------------------------------------- |
| Contact us            | Menampilkan ajakan untuk menghubungi GenBI Jambi.               |
| Address block         | Menampilkan alamat resmi.                                       |
| Email                 | Menampilkan email organisasi.                                   |
| Nomor telepon         | Menampilkan nomor kontak.                                       |
| Social media links    | Menampilkan tautan YouTube, Instagram, dan WhatsApp.            |
| CTA WhatsApp          | Mengarahkan pengguna ke kontak WhatsApp.                        |
| Posisi sebelum footer | Section kontak ditempatkan di atas footer agar mudah ditemukan. |

### 2.13 Footer

| Subfitur             | Deskripsi                                       |
| -------------------- | ----------------------------------------------- |
| Identitas organisasi | Menampilkan logo dan nama GenBI Provinsi Jambi. |
| Deskripsi singkat    | Menjelaskan fungsi website publik.              |
| Navigasi footer      | Menampilkan link ke halaman utama.              |
| Informasi kontak     | Menampilkan email, nomor telepon, dan alamat.   |
| Copyright            | Menampilkan informasi hak cipta.                |
| Back to top          | Tombol untuk kembali ke atas halaman.           |

## 3. Fitur Admin CMS

### 3.1 Admin Layout

| Subfitur          | Deskripsi                                                                              |
| ----------------- | -------------------------------------------------------------------------------------- |
| Sidebar admin     | Menampilkan menu utama admin.                                                          |
| Header admin      | Menampilkan judul halaman dan tombol Visit Website.                                    |
| Warna biru bersih | Admin memakai biru dengan intensitas sedang agar tetap bersih dan tidak terlalu pekat. |
| Hover sidebar     | Hover dibuat lebih jelas agar tidak terlalu transparan.                                |
| Active menu       | Menu aktif diberi background biru yang lebih tegas.                                    |
| Responsive layout | Sidebar dan konten menyesuaikan layar kecil.                                           |
| Icon menu         | Setiap menu memakai icon agar mudah dikenali.                                          |

### 3.2 Dashboard

| Subfitur                     | Deskripsi                                       |
| ---------------------------- | ----------------------------------------------- |
| Summary card                 | Menampilkan ringkasan jumlah konten.            |
| Total news categories        | Menampilkan jumlah kategori berita.             |
| Total news                   | Menampilkan jumlah berita.                      |
| Total events                 | Menampilkan jumlah agenda.                      |
| Total team members           | Menampilkan jumlah anggota.                     |
| Total photos                 | Menampilkan jumlah galeri foto.                 |
| Total services atau features | Menampilkan jumlah fitur atau layanan.          |
| Quick overview               | Admin bisa melihat kondisi konten secara cepat. |

### 3.3 Settings

| Subfitur          | Deskripsi                                                               |
| ----------------- | ----------------------------------------------------------------------- |
| Logo setting      | Mengatur logo website.                                                  |
| Favicon setting   | Mengatur favicon website.                                               |
| Top bar setting   | Mengatur email dan nomor telepon di top bar.                            |
| Footer setting    | Mengatur teks footer, alamat, email, telepon, newsletter, dan CTA.      |
| Email setting     | Mengatur email pengirim dan penerima.                                   |
| Banner setting    | Mengatur banner default.                                                |
| Sidebar setting   | Mengatur konfigurasi sidebar untuk halaman tertentu.                    |
| Color setting     | Mengatur warna utama website.                                           |
| Custom file input | Input upload dibuat custom agar tidak memakai tampilan default browser. |
| Custom dropdown   | Dropdown dibuat custom agar konsisten dengan desain admin.              |

### 3.4 Page Management

| Subfitur          | Deskripsi                                                                                                                                        |
| ----------------- | ------------------------------------------------------------------------------------------------------------------------------------------------ |
| Tab halaman       | Admin bisa berpindah antar pengaturan Home, About, FAQ, Service, Testimonial, News, Event, Contact, Search, Terms, Privacy, Team, dan Portfolio. |
| Meta title        | Mengatur title SEO halaman.                                                                                                                      |
| Meta keyword      | Mengatur kata kunci halaman.                                                                                                                     |
| Meta description  | Mengatur deskripsi SEO halaman.                                                                                                                  |
| Welcome section   | Mengatur konten pembuka homepage.                                                                                                                |
| Program section   | Mengatur program utama.                                                                                                                          |
| Team section      | Mengatur judul dan subtitle team.                                                                                                                |
| Blog section      | Mengatur jumlah berita yang tampil di homepage.                                                                                                  |
| Contact page      | Mengatur alamat, email, phone, dan map embed.                                                                                                    |
| Terms page        | Mengatur konten terms and conditions.                                                                                                            |
| Privacy page      | Mengatur konten privacy policy.                                                                                                                  |
| Block editor feel | Input panjang dibuat lebih lega seperti block level editor.                                                                                      |

### 3.5 Language Editor

| Subfitur                  | Deskripsi                                                                                             |
| ------------------------- | ----------------------------------------------------------------------------------------------------- |
| Daftar teks sistem        | Mengelola label teks frontend seperti About, Address, Category, Contact, News, Read More, dan Submit. |
| Block editing layout      | Field dibuat lebih lega agar terasa seperti editor konten, bukan input sempit.                        |
| Search friendly structure | Label sistem tetap mudah dicari dan dipindai.                                                         |
| Update language           | Admin bisa menyimpan perubahan teks bahasa.                                                           |

### 3.6 News Category

| Subfitur        | Deskripsi                                         |
| --------------- | ------------------------------------------------- |
| View categories | Menampilkan daftar kategori berita.               |
| Category name   | Menampilkan nama kategori.                        |
| Category banner | Menampilkan banner kategori.                      |
| Add category    | Menambah kategori baru.                           |
| Edit category   | Mengubah kategori yang ada.                       |
| Delete category | Menghapus kategori dengan confirmation modal.     |
| Search category | Mencari kategori tertentu.                        |
| Pagination      | Membagi data kategori agar tidak terlalu panjang. |

### 3.7 News Management

| Subfitur           | Deskripsi                                             |
| ------------------ | ----------------------------------------------------- |
| View news          | Menampilkan daftar berita.                            |
| News title         | Menampilkan judul utama berita.                       |
| News short content | Menampilkan caption atau ringkasan berita untuk list. |
| Photo              | Menampilkan thumbnail berita.                         |
| Banner             | Menampilkan banner berita.                            |
| Category           | Menampilkan kategori berita.                          |
| Add news           | Membuat berita baru.                                  |
| Edit news          | Mengubah berita yang sudah ada.                       |
| Delete news        | Menghapus berita dengan custom confirmation modal.    |
| Search news        | Mencari berita tertentu.                              |
| Pagination         | Menampilkan data secara bertahap.                     |

### 3.8 Add dan Edit News

| Subfitur              | Deskripsi                                                                                               |
| --------------------- | ------------------------------------------------------------------------------------------------------- |
| Medium-style editor   | Konten berita ditulis memakai block level editor.                                                       |
| Judul berita          | News title berdiri sebagai field terpisah.                                                              |
| Short content         | News Short Content berdiri sebagai field terpisah dari judul.                                           |
| Rich paragraph        | Admin bisa menulis paragraf panjang dengan nyaman.                                                      |
| Insert image          | Admin bisa menyisipkan gambar di tengah paragraf.                                                       |
| Content blocks        | Konten disusun sebagai blok, seperti heading, paragraph, quote, image, dan list.                        |
| Sidebar configuration | Pengaturan meta, kategori, tanggal, featured photo, banner, dan status komentar ditempatkan di sidebar. |
| Publish date          | Mengatur tanggal publikasi berita.                                                                      |
| Category selector     | Memilih kategori berita melalui custom dropdown.                                                        |
| Comment status        | Mengatur apakah komentar aktif atau nonaktif.                                                           |
| Featured photo        | Mengatur foto utama berita.                                                                             |
| Banner upload         | Mengatur banner berita.                                                                                 |
| SEO meta title        | Mengatur judul SEO berita.                                                                              |
| SEO meta keywords     | Mengatur kata kunci SEO.                                                                                |
| SEO meta description  | Mengatur deskripsi SEO.                                                                                 |
| Responsive editor     | Pada mobile, editor dan sidebar config tersusun secara vertikal.                                        |

### 3.9 Admin News Comment

| Subfitur           | Deskripsi                                              |
| ------------------ | ------------------------------------------------------ |
| Comment moderation | Mengelola komentar pada berita.                        |
| List komentar      | Menampilkan komentar yang masuk.                       |
| Nama komentator    | Menampilkan nama pengirim komentar.                    |
| Email komentator   | Menampilkan email pengirim.                            |
| Artikel terkait    | Menampilkan berita tempat komentar dikirim.            |
| Isi komentar       | Menampilkan teks komentar.                             |
| Status komentar    | Menampilkan Pending, Approved, Rejected, atau Flagged. |
| Approve comment    | Menyetujui komentar agar tampil di website.            |
| Hold comment       | Menahan komentar agar tidak tampil dulu.               |
| Reject comment     | Menolak komentar.                                      |
| Delete comment     | Menghapus komentar dengan confirmation modal.          |
| Filter status      | Memilah komentar berdasarkan status moderasi.          |
| Search comment     | Mencari komentar tertentu.                             |

### 3.10 Event Management

| Subfitur            | Deskripsi                                          |
| ------------------- | -------------------------------------------------- |
| View event          | Menampilkan daftar agenda.                         |
| Event title         | Menampilkan nama event.                            |
| Event short content | Menampilkan ringkasan event.                       |
| Event content       | Mengelola isi lengkap event.                       |
| Start date          | Menampilkan tanggal mulai.                         |
| End date            | Menampilkan tanggal selesai.                       |
| Status event        | Menampilkan status past event atau upcoming event. |
| Event location      | Mengatur lokasi kegiatan.                          |
| Event map           | Mengatur embed map kegiatan.                       |
| Featured photo      | Mengatur foto utama event.                         |
| Banner              | Mengatur banner event.                             |
| Add event           | Menambah event baru.                               |
| Edit event          | Mengubah event.                                    |
| Delete event        | Menghapus event dengan confirmation modal.         |

### 3.11 Team Member Management

| Subfitur           | Deskripsi                                                             |
| ------------------ | --------------------------------------------------------------------- |
| View team members  | Menampilkan daftar anggota dalam mode card.                           |
| Grid mode          | Menampilkan anggota dalam bentuk grid card.                           |
| List mode          | Menampilkan anggota dalam bentuk list card.                           |
| Foto anggota       | Menampilkan foto profil anggota.                                      |
| Nama anggota       | Menampilkan nama lengkap.                                             |
| Komisariat         | Pilihan terdiri dari Universitas Jambi, UIN Sultan Thaha, dan Alumni. |
| Divisi             | Menampilkan divisi utama anggota.                                     |
| Jabatan            | Menampilkan jabatan anggota.                                          |
| Divisi lain        | Menampilkan divisi tambahan jika anggota punya peran lintas divisi.   |
| Add team member    | Menambah anggota baru.                                                |
| Edit team member   | Mengubah data anggota.                                                |
| Delete team member | Menghapus anggota dengan confirmation modal.                          |
| Filter komisariat  | Memilah anggota berdasarkan komisariat.                               |
| Filter divisi      | Memilah anggota berdasarkan divisi.                                   |
| Search anggota     | Mencari anggota berdasarkan nama atau jabatan.                        |
| Form konsisten     | Add dan edit memakai struktur form yang sama.                         |

### 3.12 Slider Management

| Subfitur      | Deskripsi                                   |
| ------------- | ------------------------------------------- |
| View sliders  | Menampilkan daftar slider homepage.         |
| Photo         | Menampilkan gambar slider.                  |
| Heading       | Menampilkan teks utama slider.              |
| Content       | Menampilkan deskripsi slider.               |
| Button 1 text | Mengatur teks tombol pertama.               |
| Button 1 URL  | Mengatur link tombol pertama.               |
| Button 2 text | Mengatur teks tombol kedua.                 |
| Button 2 URL  | Mengatur link tombol kedua.                 |
| Position      | Mengatur posisi teks slider.                |
| Add slider    | Menambah slider baru.                       |
| Edit slider   | Mengubah slider.                            |
| Delete slider | Menghapus slider dengan confirmation modal. |

### 3.13 Photo Gallery

| Subfitur            | Deskripsi                                 |
| ------------------- | ----------------------------------------- |
| View photos         | Menampilkan daftar foto galeri.           |
| Photo preview       | Menampilkan thumbnail foto.               |
| Add photo           | Mengunggah foto baru.                     |
| Edit photo          | Mengganti foto.                           |
| Delete photo        | Menghapus foto dengan confirmation modal. |
| Custom upload input | Input file dibuat custom.                 |
| Pagination          | Membagi daftar foto agar tetap ringan.    |

### 3.14 Feature Management

| Subfitur       | Deskripsi                                  |
| -------------- | ------------------------------------------ |
| View features  | Menampilkan daftar fitur atau program.     |
| Name           | Menampilkan nama fitur.                    |
| Content        | Menampilkan deskripsi fitur.               |
| Icon           | Menampilkan icon fitur.                    |
| Add feature    | Menambah fitur baru.                       |
| Edit feature   | Mengubah fitur.                            |
| Delete feature | Menghapus fitur dengan confirmation modal. |
| Icon input     | Admin bisa mengatur icon fitur.            |

### 3.15 Why Choose Us

| Subfitur           | Deskripsi                                          |
| ------------------ | -------------------------------------------------- |
| View why choose us | Menampilkan daftar alasan atau informasi edukatif. |
| Name               | Menampilkan judul item.                            |
| Content            | Menampilkan deskripsi.                             |
| Icon               | Menampilkan icon.                                  |
| Photo              | Menampilkan gambar pendukung.                      |
| Add item           | Menambah item baru.                                |
| Edit item          | Mengubah item.                                     |
| Delete item        | Menghapus item dengan confirmation modal.          |

### 3.16 FAQ Management

| Subfitur     | Deskripsi                                  |
| ------------ | ------------------------------------------ |
| View FAQs    | Menampilkan daftar pertanyaan.             |
| FAQ title    | Menampilkan judul pertanyaan.              |
| FAQ content  | Menampilkan jawaban.                       |
| Show on home | Mengatur apakah FAQ tampil di homepage.    |
| Add FAQ      | Menambah pertanyaan baru.                  |
| Edit FAQ     | Mengubah FAQ.                              |
| Delete FAQ   | Menghapus FAQ dengan confirmation modal.   |
| Block editor | Konten FAQ ditulis dalam editor yang lega. |

### 3.17 Social Media

| Subfitur            | Deskripsi                                              |
| ------------------- | ------------------------------------------------------ |
| YouTube link        | Mengatur tautan YouTube.                               |
| Instagram link      | Mengatur tautan Instagram.                             |
| WhatsApp link       | Mengatur tautan WhatsApp.                              |
| Empty state logic   | Jika field kosong, link tidak ditampilkan di frontend. |
| Submit social media | Menyimpan perubahan media sosial.                      |

## 4. Fitur Interaksi dan UX

| Fitur        | Subfitur             | Deskripsi                                                      |
| ------------ | -------------------- | -------------------------------------------------------------- |
| Custom modal | Delete confirmation  | Mengganti confirm browser default dengan modal desain sendiri. |
| Custom modal | Approve confirmation | Dipakai saat admin menyetujui komentar.                        |
| Custom modal | Reject confirmation  | Dipakai saat admin menolak komentar.                           |
| Custom modal | Prestasi detail      | Menampilkan detail prestasi lengkap dengan gambar.             |
| Custom modal | Team detail          | Menampilkan detail anggota dengan posisi fixed.                |
| Custom input | File upload          | Tombol upload dibuat konsisten dengan desain admin.            |
| Custom input | Dropdown             | Select native diganti dengan dropdown custom.                  |
| Custom input | Search field         | Field pencarian dibuat lebih bersih.                           |
| Custom input | Focus state          | Input punya ring biru saat aktif.                              |
| Hover effect | Sidebar hover        | Hover dibuat jelas dan tetap halus.                            |
| Hover effect | Card hover           | Card naik sedikit atau berubah border saat diarahkan kursor.   |
| Animation    | Fade in              | Section muncul halus saat masuk viewport.                      |
| Animation    | Slide up             | Card muncul dari bawah dengan transisi lembut.                 |
| Animation    | Modal transition     | Popup muncul dengan animasi scale dan fade.                    |
| Animation    | Skeleton loading     | Placeholder muncul saat gambar gagal atau belum termuat.       |

## 5. Fitur Responsive

| Area          | Deskripsi                                                      |
| ------------- | -------------------------------------------------------------- |
| Public navbar | Menu berubah menjadi tombol mobile pada layar kecil.           |
| Hero          | Teks dan tombol tersusun vertikal di mobile.                   |
| Carousel      | Item tetap bisa digeser horizontal dengan sentuhan.            |
| Program utama | Card tampil satu per satu pada layar kecil.                    |
| Agenda utama  | Card agenda tetap readable pada mobile.                        |
| BPI member    | Foto dan konten anggota tetap proporsional.                    |
| Team page     | Filter tersusun vertikal di mobile.                            |
| Admin sidebar | Sidebar bisa disesuaikan agar tidak menutupi konten.           |
| Admin forms   | Field dan sidebar config berubah menjadi satu kolom di mobile. |
| News editor   | Block editor tetap nyaman dipakai di layar kecil.              |
| Tables        | Data admin bisa discroll horizontal atau diubah menjadi card.  |

## 6. Struktur Halaman Public Website

| Halaman     | File               | Deskripsi                                                                       |
| ----------- | ------------------ | ------------------------------------------------------------------------------- |
| Home        | `index.html`       | Landing page utama berisi hero, program, BPI, agenda, news, kontak, dan footer. |
| About       | `about.html`       | Halaman profil organisasi.                                                      |
| Team        | `team.html`        | Direktori anggota dengan search dan filter.                                     |
| Prestasi    | `prestasi.html`    | Daftar prestasi dengan filter dan modal detail.                                 |
| News        | `news.html`        | Daftar berita.                                                                  |
| News Detail | `news-detail.html` | Detail artikel, share, komentar, dan artikel terkait.                           |
| Contact     | `contact.html`     | Informasi kontak dan alamat.                                                    |

## 7. Struktur Halaman Admin CMS

| Halaman         | File                         | Deskripsi                                                                     |
| --------------- | ---------------------------- | ----------------------------------------------------------------------------- |
| Dashboard       | `admin/dashboard.html`       | Ringkasan data website.                                                       |
| Settings        | `admin/setting.html`         | Pengaturan logo, favicon, top bar, footer, email, banner, sidebar, dan warna. |
| Page            | `admin/page.html`            | Pengaturan konten halaman publik.                                             |
| Language        | `admin/language.html`        | Pengaturan teks bahasa website.                                               |
| Category        | `admin/category.html`        | Manajemen kategori berita.                                                    |
| News            | `admin/news.html`            | Manajemen daftar berita.                                                      |
| Add News        | `admin/news-add.html`        | Form tambah berita dengan block editor.                                       |
| Edit News       | `admin/news-edit.html`       | Form edit berita dengan block editor.                                         |
| Comment         | `admin/comment.html`         | Moderasi komentar berita.                                                     |
| Event           | `admin/event.html`           | Manajemen agenda.                                                             |
| Add Event       | `admin/event-add.html`       | Form tambah agenda.                                                           |
| Team Member     | `admin/team-member.html`     | Manajemen anggota.                                                            |
| Add Team Member | `admin/team-member-add.html` | Form tambah anggota.                                                          |
| Slider          | `admin/slider.html`          | Manajemen slider homepage.                                                    |
| Add Slider      | `admin/slider-add.html`      | Form tambah slider.                                                           |
| Photo Gallery   | `admin/photo.html`           | Manajemen galeri foto.                                                        |
| Add Photo       | `admin/photo-add.html`       | Form tambah foto.                                                             |
| Feature         | `admin/feature.html`         | Manajemen fitur atau program.                                                 |
| Why Choose Us   | `admin/why-choose.html`      | Manajemen informasi edukatif.                                                 |
| FAQ             | `admin/faq.html`             | Manajemen FAQ.                                                                |
| Social Media    | `admin/social-media.html`    | Pengaturan tautan media sosial.                                               |

## 8. Data Dummy Utama

| Data               | Deskripsi                                                                                         |
| ------------------ | ------------------------------------------------------------------------------------------------- |
| Program utama      | Berisi KKG, SIGINJAI, GENTALA ARASY, GGTC, Leadership Camp, dan GenBI Sertifikasi.                |
| BPI Provinsi Jambi | Berisi daftar pengurus inti seperti Ketua Umum, Sekretaris Umum, Bendahara Umum, dan koordinator. |
| Agenda utama       | Berisi agenda seperti GenBI PEKA, GenBI Ceria, GenBI for UMKM, PTBI 2024, dan pelatihan literasi. |
| Berita             | Berisi berita GenBI Jambi dengan title, short content, category, date, photo, dan content.        |
| Prestasi           | Berisi data prestasi anggota dengan kategori, tahun, nama anggota, kampus, gambar, dan deskripsi. |
| Komentar           | Berisi komentar dummy dengan status Pending, Approved, Rejected, dan Flagged.                     |

## 9. Standar Visual

| Elemen           | Deskripsi                                                                |
| ---------------- | ------------------------------------------------------------------------ |
| Warna utama      | Biru GenBI dengan intensitas sedang.                                     |
| Background       | Warm neutral agar halaman terasa tenang.                                 |
| Typography       | Heading serif untuk nuansa editorial, body sans-serif untuk keterbacaan. |
| Card             | Rounded besar, border halus, shadow ringan.                              |
| Button primary   | Biru dengan kontras jelas.                                               |
| Button secondary | Putih dengan border netral.                                              |
| Admin interface  | Bersih, rapi, dominan biru, dan tidak terlalu gelap.                     |
| Landing page     | Editorial, tenang, dan berbasis alur baca.                               |
| Data list        | Menghindari tampilan terlalu ramai.                                      |

## 10. Standar Teknis

| Komponen                 | Deskripsi                                                                             |
| ------------------------ | ------------------------------------------------------------------------------------- |
| HTML                     | Struktur halaman dibuat sebagai file terpisah.                                        |
| Tailwind CSS             | Digunakan untuk styling utama.                                                        |
| JavaScript               | Digunakan untuk routing ringan, carousel, modal, filter, search, dan interaksi admin. |
| Pure static              | Tidak memakai React.                                                                  |
| Page routing             | Halaman dipisah berdasarkan file, bukan semua konten di satu halaman.                 |
| Component-like structure | Partial UI diatur lewat pola JavaScript reusable.                                     |
| Carousel                 | Menggunakan horizontal scroll, button navigation, dan scroll snap.                    |
| Modal                    | Menggunakan fixed overlay dan bisa ditutup dengan Escape.                             |
| Editor                   | News memakai block level editor dengan dukungan gambar di paragraf.                   |
| Responsive               | Semua halaman disiapkan untuk desktop, tablet, dan mobile.                            |

[1]: https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Scroll_snap?utm_source=chatgpt.com "CSS scroll snap - MDN Web Docs"

